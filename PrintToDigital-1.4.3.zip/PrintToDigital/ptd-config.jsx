/**
 * @description Configuration file for creation and export to Ptd
 *
 * Collection: Grandes Autores
 * Discipline: Matemática Bianchini
 * Version: v1b0
 *
 * @copyright WoodWing Software B.V. All rights reserved.
 */
$.global.ptdConfig = {

	// Filter text based on paragraph style name. For now the only option.
	textFilter: 'paragraphStyleName',
	// Object with all digital article component types. Each type has an array of style names that will be used
	// to define the type. Style names can be either strings or regular expressions (in string form)
	// By default the text is placed in the text field of the component, to override this behavior add "." and the field name, for example subtitle.title
	// To use a specfic digitalComponentStyleOptions add a "#" and the name of the digitalComponentStyleOptions, for example title#option1_red or subtitle.title#option2_blue	

	//This is print to digital configuration script for Grandes Autores - Matemática Bianchini

	textFilterList: {
		"titleh1": [
			
		],
		"titleh1#Option1": [
			
		],
		"titleh1#Option2": [
			
		],
		"titleh1#Option3": [
			"04-capitulo-numero_G_MP"
		],
		"titleh2": [
			"10-secao-Aval-peso1"
		],
		"titleh2#Option1": [
			"10-secao-peso1-diversificando"
		],
		"titleh2#Option2": [
			"10-secao-peso1-trabalhando"
		],
		"titleh2#Option3": [
			"10-secao-ParaSaber-peso1"
		],
		"titleh3": [
			"01-apresentacao-vinheta_G_MP"
		],
		"titleh4": [
			"10-secao-Aval-peso2"
		],
		"titleh4#Option1": [
			"05-geral-peso1",
			"05-geral-peso1-numero"
		],
		"titleh4#Option2": [
			"04-capitulo_G_MP"
		],
		"titleh5": [
			"05-geral-peso3"
		],
		"titleh5#Option1": [
			
		],
		"titleh5#Option2": [
			"10-secao-peso2"
		],
		"titleh5#Option3": [
			"05-geral-peso1_MP"
		],
		"titleh5#Option4": [
			"05-geral-peso1_G_MP"
		],
		"titleh5#Option5": [
			"05-geral-peso2_G_MP"
		],
		"titleh5#Option6": [
			"05-geral-peso2"
		],
		"titleh5#Option7": [
			"00-fixos-peso1_G_MP"
		],
		"titleh5#Option8": [
			
		],
		"titleh5#Option9": [
			
		],
		"titleh5#Option10": [
			"04-capitulo-titulo_G_MP"
		],
		"titleh6": [
			"10-secao-Diversificando-peso2",
			"10-secao-ParaSaber-peso2",
			"10-secao-Trabalhando-peso2"
		],
		"titleh6#Option1": [
			"05-geral-peso3_G_MP"
		],
		"titleh6#Option2": [
			"05-geral-peso4_G_MP"
		],
		"titleh6#Option3": [
			"12-infografia-peso2"
		],
		"titleh6#Option4": [
			
		],
		"titleh6#Option5": [
			
		],
		"titleh6#Option6": [
			"09-atividade-cont-intro_G_MP"
		],
		"titleh6#Option7": [
			"05-geral-3os-titulo_G_MP"
		],
		"titleh6#Option8": [
			"06-box-Observacao-titulo"
		],
		"collapsiblebox": [
			"answers"
		],
		"image.caption": [
			"05-geral-fonte",
			"05-geral-legenda",
			"05-geral-legenda_G_MP",
			"05-geral-legenda_MP"
		],
		"picturecredit": [
			"00-fixos-credito",
			"00-fixos-credito_MP",
			"00-fixos-credito_G_MP"
		],
		"body": [
			"05-geral-glossario-texto",
			"05-geral-texto",
			"06-box-texto",
			"10-secao-Diversificando-texto",
			"12-infografia-cota",
			"12-infografia-texto",
			"05-geral-texto-habilidades_MP",
			"05-geral-nota-rodape_G_MP",
			"05-geral-nota-rodape-linha_G_MP",
			"05-geral-texto-bibliografia_G_MP",
			"16-respostas-capitulo-entrelinha",
			"16-respostas-texto",
			"16-respostas-vinheta-entrelinha",
			"16-bibliografia",
			"16-siglas",
			"16-respostas-comando-1",
			"16-respostas-comando-texto",
			"16-respostas-alternativa-3col",
			"16-respostas-alternativa-4col",
			"16-respostas-a)",
			"16-respostas-comando-1_a)",
			"16-respostas-comando-1_a)-3col",
			"16-respostas-comando-1_a)-4col",
			"05-geral-texto-bullet_cont_G_MP",
			"05-geral-texto-bibliografia_comet_G_MP",
			"01-apresentacao-texto",
			"01-organizacao-texto",
			"01-organizacao-texto-icones-TCT",
			"08-tabela-gravata",
			"08-tabela-texto",
			"07-tabela-peso1_G_MP",
			"07-tabela-texto_G_MP",
			"05-geral-3os-texto",
			"09-atividade-cont_G_MP",
			"04-capitulo-boxe-questoes",
			"06-box-atividade-texto",
			"06-box-PenseMais-texto",
			"09-atividade-1-Complementar",
			"09-atividade-1-Proposto",
			"10-secao-Aval-atividade-1",
			"10-secao-Diversificando-atividade-1",
			"10-secao-ParaSaber-atividade-1",
			"10-secao-Trabalhando-atividade-1",
			"10-secao-Trabalhando-atividade-texto",
			"05-geral-3os-fonte_G_MP",
			"05-geral-3os-texto-entre_G_MP",
			//Compose Image
			"05-geral-texto-sem recuo",
			"05-geral-cota_MP",
			"00-quadro",
			"05-geral-balao",
			"05-geral-cota",
			"05-geral-texto-semrecuo_MP",
			"07-tabela-espaço_MP",
			"07-tabela-gravata_MP",
			"07-tabela-texto",
			//Not pointed
			"10-secao-ParaSaber-atividade-texto",
			"07-tabela-texto_MP",
			//Missing in google sheet
			"Math_DISPLAY Equation w/ tabs"
		],
		"body#Option1": [
			"00-fixos-resposta"
		],
		"body#Option2": [
			"05-geral-texto-item",
			"06-box-Observacao-texto",
			"10-secao-ParaSaber-texto",
			"10-secao-Trabalhando-texto",
			"05-geral-texto_MP",
			"05-geral-texto_G_MP",
			"16-bibliografia comentario",
			"05-geral-3os-texto_MP",
			"01-organizacao-texto-olho",
			"09-atividade-texto",
			"10-secao-Aval-atividade-1-cont",
			"10-secao-Aval-atividade-texto",
			"05-geral-3os-texto_G_MP",
			"09-atividade-numero-paragrafo_G_MP"
		],
		"body#Option3": [
			"05-geral-3os-fonte",
			"05-geral-nota-rodape-cont_G_MP",
			"16-bibliografia-sugestoes",
			"05-geral-3os-fonte_MP",
			"05-geral-fonte_G_MP"
		],
		"body#Option4": [
			"14-mapa-titulo"
		],
		"body#Option5": [
			"06-box-PenseMais-titulo"
		],
		"body#Option6": [
			"09-atividade-peso1-exercicios-propostos"
		],
		"body#Option7": [
			"09-atividade-peso1-exercicios-complementares"
		],
		"body#Option8": [
			"00-fixos-balao"
		],
		"body#Option9": [
			"02-sumario-capitulo"
		],
		"body#Option10": [
			"05-geral-vinheta-situacao"
		],
		"body#Option11": [
			"05-geral-vinheta-educacao-financeira"
		],
		"body#Option12": [
			"05-geral-vinheta-tecnologia"
		],
		"body#Option13": [
			"06-Sugestoes-de-leitura-titulo_MP",
			"05-GERAL-peso5_G_MP",
			"05-GERAL-peso6_G_MP",
			"05-geral-peso2_MP",
			"05-geral-3os-titulo",
			"00-fixos-marcacao-bimestre_MP",
			"05-geral-texto-habilidades",
			"06-Sugestoes-de-leitura-titulo",
			"04-capitulo-boxe-comando"
		],
		"body#Option14": [
			"06-Sugestoes-de-leitura-texto_MP",
			"05-geral-fonte_MP",
			"06-Sugestoes-de-leitura-texto"
		],
		"body#Option15": [
			"05-geral-texto-1-cont_MP"
		],
		"body#Option16": [
			"10-secao-Aval-atividade-1_romanos",
			"09-atividade-1+a)_G_MP", //Custom Bullet 1 s/s Alegreya Sans
			"09-atividade-1_G_MP", //Custom Bullet 1 s/s Alegreya Sans
			"06-box-PenseMais-atividade-1" //Custom Bullet 1 s/s Alegreya Sans
		],
		"body#Option17": [
			"09-atividade_iten_cont_G_MP"
		],
		"body#Option18": [
			"01-apresentacao-texto-Autor"
		],
		"body#Option19": [
			"01-organizacao-titulo",
			"02-sumario-secao-menor",
			"02-sumario-peso1" //Custom Bullet 2 s/s Asap Bold
		],
		"body#Option20": [
			"02-sumario-peso-secao"
		],
		"body#Option21": [
			"02-sumario-peso2"
		],
		"body#Option22": [
			"00-fixos-faca-atividades-caderno"
		],
		"body#Option23": [
			"00-RECADO",
			"00-RECADO_MP"
		],
		"body#Option24": [
			"16-respostas-secao"
		],
		"body#Option25": [
			"05-geral-orientacoes-box_MP"
		],
		"body#Option26": [
			//Use for list item
		],
		"body#Option27": [
			"09-atividade-resposta_G_MP"
		],
		"body#Option28": [
			"observacoes_G_MP"
		],
		"footer": [
			"numero_de_pagina",
			"00-fixos-paginacao-dir_G_MP",
			"00-fixos-paginacao-esq_G_MP",
			"00-fixos-paginacao-dir",
			"00-fixos-paginacao-esq",
			"16-respostas-pagina",
			"00-fixos-paginacao-esq_MP",
			"00-fixos-paginacao-dir_MP"
		],
		"footer#Option1": [
			"00-fixos-paginacao"
		],
		"crosshead": [
			"01-apresentacao-peso1",
			"02-sumario-capitulo-tema",
			"02-sumario-secao"
		],
		"crosshead#Option1": [
			"01-apresentacao-texto-CaroEstudante"
		],
		"crosshead#Option2": [
			"02-sumario-capitulo-vinheta"
		],
		"crosshead#Option3": [
			"16-respostas-capitulo"
		],
		"unmaptext": [
			"/^.*/",
			"[Basic Paragraph]",
			"[No Paragraph Style]"
		],
		"list-item": [
			"numbered-list-style",
			"bulleted-list-style",
			"lowerletters-list-style",
			"upperletters-list-style",
			"upperroman-list-style",
		],
		"titlewih1": [

		],
		"titlewih2": [

		],
		"titlewih3": [
			"00-fixos-peso1",
			"00-fixos-peso2"
		],
		"titlewih4": [
			
		],
		"titlewih5": [

		],
		"titlewih6": [
			
		],
		"titlewithimage": [
			"04-capitulo",
			"04-capitulo-numero"
		],
		"titlewithimage#Option1": [
			"04-capitulo-titulo"
		]
	},

	//optional, title settings
	appendTitle: {
		"titleh1": [
		],
		"titleh2": [
		],
		"titleh3": [
		],
		"titleh4": [
		],
		"titleh5": [
		],
		"titleh6": [
		]
	},

	//Optional digital component style definitions 
	digitalComponentStyles: {
		"Option1": {
			"styles": {
				"style": "_option1"
			}
		},
		"Option2": {
			"styles": {
				"style": "_option2"
			}
		},
		"Option3": {
			"styles": {
				"style": "_option3"
			}
		},
		"Option4": {
			"styles": {
				"style": "_option4"
			}
		},
		"Option5": {
			"styles": {
				"style": "_option5"
			}
		},
		"Option6": {
			"styles": {
				"style": "_option6"
			}
		},
		"Option7": {
			"styles": {
				"style": "_option7"
			}
		},
		"Option8": {
			"styles": {
				"style": "_option8"
			}
		},
		"Option9": {
			"styles": {
				"style": "_option9"
			}
		},
		"Option10": {
			"styles": {
				"style": "_option10"
			}
		},
		"Option11": {
			"styles": {
				"style": "_option11"
			}
		},
		"Option12": {
			"styles": {
				"style": "_option12"
			}
		},
		"Option13": {
			"styles": {
				"style": "_option13"
			}
		},
		"Option14": {
			"styles": {
				"style": "_option14"
			}
		},
		"Option15": {
			"styles": {
				"style": "_option15"
			}
		},
		"Option16": {
			"styles": {
				"style": "_option16"
			}
		},
		"Option17": {
			"styles": {
				"style": "_option17"
			}
		},
		"Option18": {
			"styles": {
				"style": "_option18"
			}
		},
		"Option19": {
			"styles": {
				"style": "_option19"
			}
		},
		"Option20": {
			"styles": {
				"style": "_option20"
			}
		},
		"Option21": {
			"styles": {
				"style": "_option21"
			}
		},
		"Option22": {
			"styles": {
				"style": "_option22"
			}
		},
		"Option23": {
			"styles": {
				"style": "_option23"
			}
		},
		"Option24": {
			"styles": {
				"style": "_option24"
			}
		},
		"Option25": {
			"styles": {
				"style": "_option25"
			}
		},
		"Option26": {
			"styles": {
				"style": "_option26"
			}
		},
		"Option27": {
			"styles": {
				"style": "_option27"
			}
		},
		"Option28": {
			"styles": {
				"style": "_option28"
			}
		},
		"Option29": {
			"styles": {
				"style": "_option29"
			}
		},
		"Option30": {
			"styles": {
				"style": "_option30"
			}
		},
		"Option31": {
			"styles": {
				"style": "_option31"
			}
		},
		"Option32": {
			"styles": {
				"style": "_option32"
			}
		},
		"Option33": {
			"styles": {
				"style": "_option33"
			}
		},
		"Option34": {
			"styles": {
				"style": "_option34"
			}
		},
		"Option35": {
			"styles": {
				"style": "_option35"
			}
		},
		"Option36": {
			"styles": {
				"style": "_option36"
			}
		},
		"Option37": {
			"styles": {
				"style": "_option37"
			}
		},
		"Option38": {
			"styles": {
				"style": "_option38"
			}
		},
		"Option39": {
			"styles": {
				"style": "_option39"
			}
		},
		"Option40": {
			"styles": {
				"style": "_option40"
			}
		},
		"Option41": {
			"styles": {
				"style": "_option41"
			}
		},
		"Option42": {
			"styles": {
				"style": "_option42"
			}
		},
		"Option43": {
			"styles": {
				"style": "_option43"
			}
		},
		"Option44": {
			"styles": {
				"style": "_option44"
			}
		},
		"Option45": {
			"styles": {
				"style": "_option45"
			}
		},
		"Option46": {
			"styles": {
				"style": "_option46"
			}
		},
		"Option47": {
			"styles": {
				"style": "_option47"
			}
		},
		"Option48": {
			"styles": {
				"style": "_option48"
			}
		},
		"Option49": {
			"styles": {
				"style": "_option49"
			}
		},
		"Option50": {
			"styles": {
				"style": "_option50"
			}
		}
	},

	imageComponent: {
		//Base json of the image component
		definition: {
			"content": {
				"image": {
					"id": "",
					"focuspoint": {
						"x": 0.5,
						"y": 0.5
					},
					"cropper": false
				},
				"caption": [],
				"picture credit": []
			},
			"id": "",
			"identifier": "image",
			"styles": {
				"fitting": "_fit-frame-height-to-content"
			}
		},

		//List of the text filters of the image component as configured in textFilterList
		textFilters: [
			"image.caption"
		]
	},
	
	ptdimageComponent: {
		definition: {
			"content": {
				"ptdimage": {
					"id": "",
					"focuspoint": {
						"x": 0.5,
						"y": 0.5
					},
					"cropper": false
				},
				"caption": [],
				"picture credit": []
			},
			"id": "",
			"identifier": "ptdimage",
			"styles": {
				"ptdimage-fitting": "_fitting",
				"ptdimage-style": ""
			},
			"inlineStyles": {
				"width": ""
			}
		},
		//List of the text filters of the image component as configured in textFilterList
		textFilters: [
			"image.caption"
		]
	},

	mathComponent: {
		definition: {
			"content": {
				"mathml": {
					"options": {
						"mathML": ""
					}
				}
			},
			"id": "",
			"data": {
				"mathml-html-data": ""
			},
			"identifier": "mathml",
			"styles": {}
		}
	},

	//collapsiblebox
	collapsible: {
		"answers": {
			definition: {
				"content": {
					"headerwithline": [
						{
							"insert": "Respostas e comentários"
						}
					]
				},
				"id": "",
				"identifier": "collapsiblebox",
				"styles": {},
				"containers": {
					"main": [
					]
				}
			}
		},
		"guidelines": {
			definition: {
				"content": {
					"headerwithline": [
						{
							"insert": "Orientações e sugestões didáticas"
						}
					]
				},
				"id": "",
				"identifier": "collapsiblebox",
				"styles": {},
				"containers": {
					"main": [
					]
				}
			}
		}
	},

	//Icon and Image Header definitions
	header: {
		"00-fixos-peso1": { //Paragraph style name
			definition: {
				"content": {
					"titlewih3": [		//title with icon example
					],
					"imageicon": {
						"id": "",
						"focuspoint": {
							"x": 0.5,
							"y": 0.5
						},
						"cropper": false
					}
				},
				"id": "",
				"identifier": "titlewithiconh3",
				"styles": {},
				"inlineStyles": {
				}
			}
		},
		"00-fixos-peso2": { //Paragraph style name
			definition: {
				"content": {
					"titlewih3": [		//title with icon example
					],
					"imageicon": {
						"id": "",
						"focuspoint": {
							"x": 0.5,
							"y": 0.5
						},
						"cropper": false
					}
				},
				"id": "",
				"identifier": "titlewithiconh3",
				"styles": {},
				"inlineStyles": {
				}
			}
		},
		"04-capitulo": { //Paragraph style name
			definition: {
				"content": {
					"imageicon": {
						"id": "",
						"focuspoint": {
							"x": 0.5,
							"y": 0.5
						},
						"cropper": false
					}
				},
				"id": "doc-1g5k3djco0",
				"identifier": "titlewithimage",
				"styles": {},
				"containers": {
					"main": []
				},
				"inlineStyles": {
				}
			},
			contentType: "titleh1"
		},
		"04-capitulo-numero": { //Paragraph style name
			definition: {
				"content": {
					"imageicon": {
						"id": "",
						"focuspoint": {
							"x": 0.5,
							"y": 0.5
						},
						"cropper": false
					}
				},
				"id": "doc-1g5k3djco0",
				"identifier": "titlewithimage",
				"styles": {},
				"containers": {
					"main": []
				},
				"inlineStyles": {
				}
			},
			contentType: "titleh1"
		},
		"04-capitulo-titulo": { //Paragraph style name
			definition: {
				"content": {
					"imageicon": {
						"id": "",
						"focuspoint": {
							"x": 0.5,
							"y": 0.5
						},
						"cropper": false
					}
				},
				"id": "doc-1g5k3djco0",
				"identifier": "titlewithimage",
				"styles": {},
				"containers": {
					"main": []
				},
				"inlineStyles": {
				}
			},
			contentType: "titleh1"
		}
	},

	//Place components in a container based on their paragraph style
	containers: {
		"bulleted-list-style": { //Paragraph style
			definition: { // Container definition 
				"content": {},
				"id": "",
				"identifier": "bulleted-list",
				"styles": {},
				"containers": {
					"main": []
				},
				"data":{
					"start":""
				}
			},
			containerName: "main", //Container field in the container definition
		},
		"numbered-list-style": { //Paragraph style
			definition: { // Container definition 
				"content": {},
				"id": "",
				"identifier": "numbered-list",
				"styles": {},
				"containers": {
					"main": []
				},
				"data":{
					"start":""
				}
			},
			containerName: "main", //Container field in the container definition
		},
		"lowerletters-list-style": { //Paragraph style
			definition: { // Container definition 
				"content": {},
				"id": "",
				"identifier": "lowerletters-list",
				"styles": {},
				"containers": {
					"main": []
				},
				"data":{
					"start":""
				}
			},
			containerName: "main", //Container field in the container definition
		},
		"upperletters-list-style": { //Paragraph style
			definition: { // Container definition 
				"content": {},
				"id": "",
				"identifier": "upperletters-list",
				"styles": {},
				"containers": {
					"main": []
				},
				"data":{
					"start":""
				}
			},
			containerName: "main", //Container field in the container definition
		},
		"upperroman-list-style": { //Paragraph style
			definition: { // Container definition 
				"content": {},
				"id": "",
				"identifier": "upperroman-list",
				"styles": {},
				"containers": {
					"main": []
				},
				"data":{
					"start":""
				}
			},
			containerName: "main", //Container field in the container definition
		}
	},

	// The 'styles' section provides the export details about what styling should result in bold and italic
	// overrides in the output.
	styles: {
		// Mark character styles as bold or italic. Matching is on full character style name. Most commonly used.
		character: {
			"Bold": { bold: true },
			"Bold Italic": { bold: true, italic: true },
			"Italic": { italic: true },
			"Subscript": { subscript: true },
			"Superscript": { superscript: true },
			"Underline": { underline: true },
			"Strikethrough": { strikethrough: true },
			"Uppercase": { uppercase: true },
			"Lowercase": { lowercase: true },
			"Titlecase": { titlecase: true },
			"00-fixo-resposta-bold": { characterstyle: "cs-00-fixo-resposta-bold" },
			"00-fixo-resposta-italic": { characterstyle: "cs-00-fixo-resposta-italic" },
			"00-mathematical-pi-1": { characterstyle: "cs-00-mathematical-pi-1" },
			"00-mathematical-pi-4": { characterstyle: "cs-00-mathematical-pi-4" },
			"00-mathematical-pi-6": { characterstyle: "cs-00-mathematical-pi-6" },
			"00-myriad-bold": { characterstyle: "cs-00-myriad-bold" },
			"00-myriad-italic": { characterstyle: "cs-00-myriad-italic" },
			"00-sobrescrito-sublinhado": { characterstyle: "cs-00-sobrescrito-sublinhado" },
			"00-symbol":{characterstyle:"cs-00-symbol"},
            "00-texto-bco":{characterstyle:"cs-00-texto-bco"},
            "05-cota-bold-bco":{characterstyle:"cs-05-cota-bold-bco"},
            "05-geral-3os-bold":{characterstyle:"cs-05-geral-3os-bold"},
            "05-geral-3os-italic":{characterstyle:"cs-05-geral-3os-italic"},
            "05-geral-glossario-destaque":{characterstyle:"cs-05-geral-glossario-destaque"},
            "05-geral-glossario-destaque-3os":{characterstyle:"cs-05-geral-glossario-destaque-3os"},
            "05-geral-glossario-peso":{characterstyle:"cs-05-geral-glossario-peso"},
            "05-geral-texto-bold":{characterstyle:"cs-05-geral-texto-bold"},
            "05-geral-texto-bold-italic":{characterstyle:"cs-05-geral-texto-bold-italic"},
            "05-geral-texto-italic":{characterstyle:"cs-05-geral-texto-italic"},
            "06-box-Observacao-seta":{characterstyle:"cs-06-box-Observacao-seta"},
            "09-atividade-alternativa":{characterstyle:"cs-09-atividade-alternativa"},
            "09-atividade-bold":{characterstyle:"cs-09-atividade-bold"},
            "09-atividade-bold-italico":{characterstyle:"cs-09-atividade-bold-italico"},
            "09-atividade-Complementar-comando-numero":{characterstyle:"cs-09-atividade-Complementar-comando-numero"},
            "09-atividade-italic":{characterstyle:"cs-09-atividade-italic"},
            "09-atividade-Para-Saber-comando-numero":{characterstyle:"cs-09-atividade-Para-Saber-comando-numero"},
            "09-atividade-Proposto-comando-numero":{characterstyle:"cs-09-atividade-Proposto-comando-numero"},
            "10-secao-comando-numero":{characterstyle:"cs-10-secao-comando-numero"},
            "10-secao-Diversificando-comando-numero":{characterstyle:"cs-10-secao-Diversificando-comando-numero"},
            "10-secao-Trabalhando-comando-numero":{characterstyle:"cs-10-secao-Trabalhando-comando-numero"},
            "05-geral-bullet_MP":{characterstyle:"cs-05-geral-bullet_MP"},
            "bold-italic_MP":{characterstyle:"cs-bold-italic_MP"},
            "bold_MP":{characterstyle:"cs-bold_MP"},
            "italic_MP":{characterstyle:"cs-italic_MP"},
            "05-3os-bold_MP":{characterstyle:"cs-05-3os-bold_MP"},
            "05-3os-italic_MP":{characterstyle:"cs-05-3os-italic_MP"},
            "05-geral-peso2-bullet_MP":{characterstyle:"cs-05-geral-peso2-bullet_MP"},
            "05-peso3-1pg_MP":{characterstyle:"cs-05-peso3-1pg_MP"},
            "medium_MP":{characterstyle:"cs-medium_MP"},
            "ordinal_MP":{characterstyle:"cs-ordinal_MP"},
            "sobrescrito_MP":{characterstyle:"cs-sobrescrito_MP"},
            "symbol_MP":{characterstyle:"cs-symbol_MP"},
			"txt_C100":{characterstyle:"cs-txt_C100"},
			"00-sobrescrito":{characterstyle:"cs-00-sobrescrito"},
			"00-subscrito":{characterstyle:"cs-00-subscrito"},
			"00-fixo-resposta-bold-italic":{characterstyle:"cs-00-fixo-resposta-bold-italic"},
			"00-roboto-bold-italic":{characterstyle:"cs-00-roboto-bold-italic"},
			"05-geral-3os-bold-italic":{characterstyle:"cs-05-geral-3os-bold-italic"},
			"06-box-Pense-Mais-atividade-comando-numero":{characterstyle:"cs-06-box-Pense-Mais-atividade-comando-numero"},
			"00-mathematical-pi-3":{characterstyle:"cs-00-mathematical-pi-3"},
			"00-mathematical-pi-5":{characterstyle:"cs-00-mathematical-pi-5"},
			"00-fixos-balao-italic":{characterstyle:"cs-00-fixos-balao-italic"},
			"00-fixos-balao-bold":{characterstyle:"cs-00-fixos-balao-bold"},
			"00-fixos-balao-bold-italic":{characterstyle:"cs-00-fixos-balao-bold-italic"},
			"00-mathematical-pi-2":{characterstyle:"cs-00-mathematical-pi-2"},
			"00-Beaba Moderna Regular":{characterstyle:"cs-00-Beaba-Moderna-Regular"},
			"CIFRAO_ROBOTO_BOLD":{characterstyle:"cs-CIFRAO_ROBOTO_BOLD"},
			"CIFRAO_ROBOTO":{characterstyle:"cs-CIFRAO_ROBOTO"},
			"CIFRAO Roboto_MP":{characterstyle:"cs-CIFRAO_Roboto_MP"},
			"00-mathematical-pi-1_MP":{characterstyle:"cs-00-mathematical-pi-1_MP"},
			"00-sobrescrito-sublinhado_MP":{characterstyle:"cs-00-sobrescrito-sublinhado_MP"},
			"00-Mathematical Pi 1":{characterstyle:"cs-00-Mathematical-Pi-1"},
			"00-bold":{characterstyle:"cs-00-bold"},
			"00-italic":{characterstyle:"cs-00-italic"},
			"02-sumario-pagina":{characterstyle:"cs-02-sumario-pagina"},
			"02-sumario-pagina-secao":{characterstyle:"cs-02-sumario-pagina-secao"},
			"02-sumario-pontilhado":{characterstyle:"cs-02-sumario-pontilhado"},
			"02-sumario-secao-nome":{characterstyle:"cs-02-sumario-secao-nome"},
			"00-Acessibilidade-Siglas":{characterstyle:"cs-00-Acessibilidade-Siglas"},
			"00-Acessibilidade-Siglas-Bold":{characterstyle:"cs-00-Acessibilidade-Siglas-Bold"},
			"00-Acessibilidade-Siglas-Bold-Italic":{characterstyle:"cs-00-Acessibilidade-Siglas-Bold-Italic"},
			"00-Acessibilidade-Siglas-Italic":{characterstyle:"cs-00-Acessibilidade-Siglas-Italic"},
			"00-Acessibilidade-Fonetica":{characterstyle:"cs-00-Acessibilidade-Fonetica"},
			"00-Acessibilidade-Fonetica-Bold":{characterstyle:"cs-00-Acessibilidade-Fonetica-Bold"},
			"00-Acessibilidade-Fonetica-Bold-Italic":{characterstyle:"cs-00-Acessibilidade-Fonetica-Bold-Italic"},
			"00-Acessibilidade-Fonetica-Italic":{characterstyle:"cs-00-Acessibilidade-Fonetica-Italic"},
			"00-Acessibilidade-Idioma":{characterstyle:"cs-00-Acessibilidade-Idioma"},
			"00-Acessibilidade-Idioma-Bold":{characterstyle:"cs-00-Acessibilidade-Idioma-Bold"},
			"00-Acessibilidade-Idioma-Bold-Italic":{characterstyle:"cs-00-Acessibilidade-Idioma-Bold-Italic"},
			"00-Acessibilidade-Idioma-Italic":{characterstyle:"cs-00-Acessibilidade-Idioma-Italic"},
			"Math_Variable":{characterstyle:"cs-Math_Variable"},
			"00-Emmascript":{characterstyle:"cs-00-Emmascript"},
			"05-geral-texto-bold-C100":{characterstyle:"cs-05-geral-texto-bold-C100"},
			"05-geral-texto-C100":{characterstyle:"cs-05-geral-texto-C100"},
			"05-geral-texto-bold-italico-C100":{characterstyle:"cs-05-geral-texto-bold-italico-C100"},
			"Caflisch Script Pro":{characterstyle:"cs-Caflisch-Script-Pro"},
			"Emmascript MVB Std":{characterstyle:"cs-Emmascript-MVB-Std"},
			"00-bold-italic":{characterstyle:"cs-00-bold-italic"},
			"16-resposta-comando-1":{characterstyle:"cs-16-resposta-comando-1"},
			"16-sigla-destaque":{characterstyle:"cs-16-sigla-destaque"},
			"00-ponto_invisivel_MP":{characterstyle:"cs-00-ponto_invisivel_MP"},
			"00-sobrescrito_MP":{characterstyle:"cs-00-sobrescrito_MP"},
			"05-geral-3os-texto":{characterstyle:"cs-05-geral-3os-texto"},
			"CIFRAO Roboto":{characterstyle:"cs-CIFRAO-Roboto"},
			"bold italic_MP":{characterstyle:"cs-bold_italic_MP"},
			"00-subscrito-italic_MP":{characterstyle:"cs-00-subscrito-italic_MP"},
			"bold":{characterstyle:"cs-bold"},
			"CIFRAO Asap":{characterstyle:"cs-CIFRAO_Asap"},
			"fonte-bold":{characterstyle:"cs-fonte-bold"},
			"00-STIX":{characterstyle:"cs-00-STIX"},
			"STIX general":{characterstyle:"cs-STIX-general"},
			"STIX general bold":{characterstyle:"cs-STIX-general-bold"},
			"STIX general bold C100":{characterstyle:"cs-STIX-general-bold-C100"},
			"STIX general C100":{characterstyle:"cs-STIX-general-C100"},
			"STIX general italic":{characterstyle:"cs-STIX-general-italic"},
			"lacuna bolinha":{characterstyle:"cs-lacuna-bolinha"},
			"Lacuna_quadrada":{characterstyle:"cs-Lacuna_quadrada"},
			"05-geral-bullet-U_MP":{characterstyle:"cs-05-geral-bullet-U_MP"},
			"bold-italic-U_MP":{characterstyle:"cs-bold-italic-U_MP"},
			"bold-U_MP":{characterstyle:"cs-bold-U_MP"},
			"italic-U_MP":{characterstyle:"cs-italic-U_MP"}
		},
	
		// Mark use of certain font styles as bold or italic in the output. Be aware that this will match for all
		// font families used with the specified font style
		font: {
		},
		// Mark entire paragraphs as bold or italic. Not commonly used.
		paragraph: {
		}
	},

	// The 'output' section defines how bold and italic overrides will be output to Ptd. In addition it offers
	// the opportunity to remove and/or replace characters in the output. Html special characters will automatically be
	// escaped in the output.
	output: {
		htmlTags: {
			bold: {
				tag: "b"
			},
			italic: {
				tag: "i"
			},
			superscript: {
				tag: "sup"
			},
			subscript: {
				tag: "sub"
			},
			uppercase: {
				tag: "up"
			}
		},
		htmlEncode: [
		]
	},

	// Using the 'charConvert' section certain characters can be replaced by other characters 
	charConvert: [
		//Thin space to space
		['\u2009', ' ']
	],

	// The directory used as base directory for logging
	exportDirectory: '~/Desktop/ptd-indesign-logs',

	// Logging settings. Log files will be put in the document's output directory.
	logging: {
		level: 'INFO',
		wipe: false
	},

	//Content Station URL relative to index.php, default assumes that Content Station is installed in the same folder as index.php
	contentStationURL: "../app/",

	//If set to true, each set of grouped frames on a layout is added as a Container component.
	//Each frame of the group will be a separate component in the Container.
	//Note: The default Container component is used; custom Container components are not supported.
	createContainerForGroup: true,

	//If set to true, images will be scaled by percentage in conversion, respecting the scaling (percentage) of frame width and print page width
	//Else set image width to 100% in conversion, so that the image is sized by CSS styling or scaled to fit full width of digital article
	scalePTDImages: true
};
