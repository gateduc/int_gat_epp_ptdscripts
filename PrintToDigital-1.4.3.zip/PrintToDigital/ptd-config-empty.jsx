﻿/**
 * @description Configuration file for creation and export to Ptd
 *
 * @copyright WoodWing Software B.V. All rights reserved.
 */
$.global.ptdConfig = {

	// Filter text based on paragraph style name. For now the only option.
	textFilter: 'paragraphStyleName',
	// Object with all digtal article component types. Each type has an array of style names that will be used
	// to define the type. Style names can be either strings or regular expressions (in string form)
	// By default the text is placed in the text field of the component, to override this behavior add "." and the field name, for example subtitle.title
	// To apply an optional digitalComponentStyle add a "#" and the name of the digitalComponentStyle, for example title#option1_red or subtitle.title#option2_blue
	textFilterList: {
		"title": [
		],
		"subtitle.title": [
		],
        "image.caption":[
        ],
		"author.name": [
		],
		"intro": [
		],
		"quote": [
		],
		"body": [
		],
		"footer": [
		]
	},

	//Optional digital component style definitions 
	digitalComponentStyles: {
		"Name": {
			"styles":{				
			 },
			 "inlineStyles":{				
			 }
		}
	},


	// Define how specific text should be styled and which styling method is used.
	// See below for information about the styles that are supported.
	styles: {
		// Mark character styles as bold, italic, subscript or superscript. Matching is on full character style name. Most commonly used.
		character: {
		},
		// Mark use of certain font styles as bold or italic in the output. Be aware that this will match for all
		// font families used with the specified font style
		font: {
		},
		// Mark entire paragraphs as bold or italic. Not commonly used.
		paragraph: {
		}
	},

	// The 'output' section defines how bold, italic, subscript and superscript overrides will be output to Ptd. In addition it offers
	// the opportunity to remove and/or replace characters in the output. Html special characters will automatically be
	// escaped in the output.
	output: {
		htmlTags: {
			bold: {
				tag: "b"
			},
			italic: {
				tag: "i"
			},
			superscript: {
				tag: "sup"
			},
			subscript: {
				tag: "sub"
			},
			underline: {
				tag: "span style = 'text-decoration: underline;'"
			},
			uppercase: {
				tag: "span style = 'text-transform: uppercase;'"
			},
			lowercase: {
				tag: "span style = 'text-transform: lowercase;'"
			},
			strikethrough: {
				tag: "span style = 'text-decoration: line-through;'"
			},
			titlecase: {
				tag: "span style = 'text-transform: capitalize;'"
			}
		},
		htmlEncode: [
		]
	},		
	imageComponent: {
		//Base json of the image component
		definition: {
			"content": {
				"image": {
					"id": "",
					"focuspoint": {
						"x": 0.5,
						"y": 0.5
					},
					"cropper": false
				},
				"caption": []
			},
			"id": "",
			"identifier": "image",
			"styles": {
			}
		},

		//List of the text filters of the image component as configured in textFilterList
		textFilters: [
			"image.caption"
		]
	},		

	mathComponent: {
		definition: {
			"content": {
				"mathml": {
					"options": {
						"mathML": ""
					}
				}
			},
			"id": "",
			"identifier": "mathml",
			"styles": {}
		}
	},	

	// The directory used as base directory for the export. The script will create directories with the document name
	// inside the base folder to separate the export of different documents. Consecutive exports of the same document
	// will overwrite existing files. Orphaned files will not be removed.
	exportDirectory: '~/Desktop/ptd-indesign-export',

	// Logging settings. Log files will be put in the document's output directory.
	logging: {
		level: 'INFO',
		wipe: false
	},

	//Content Station URL relative to index.php, default assumes that Content Station is installed in the same folder as index.php
	contentStationURL: "contentstation/",

	//If set to true, each set of grouped frames on a layout is added as a Container component. 
	//Each frame of the group will be a separate component in the Container.
	//Note: The default Container component is used; custom Container components are not supported.
	createContainerForGroup: false

};
