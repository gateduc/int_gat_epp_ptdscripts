﻿/**
 * @description Entry point for creation of the InDesign article for use in Ptd
 *
 * @copyright WoodWing Software B.V. All rights reserved.
 */

#targetengine 'ptd'

var forceInit = false;

#include "modules/_.jsx"
#include "modules/err.jsx"
#include "modules/config-service.jsx"
#include "modules/ptd-create-service.jsx"
#include "modules/logging.jsx"
#include "modules/json2.js"

// Force reload the configuration
ConfigService.loadConfig();

log.init(ConfigService.getConfig().logging, ConfigService.getConfig().exportDirectory+"/"+File.prototype.basename(app.activeDocument.name),"indesign-create.log");
log.info('{}, config: \n{}', $.fileName, JSON.stringify(ConfigService.getConfig(), null, 4));

_.wrapInUndo('Create Ptd Article', function wrapper(){
	(function createArticleScope(PtdCreateService, Err){
		/**
		 * MAIN
		 */
		try {

			$.hiresTimer;
			PtdCreateService.createArticle();
			var t = $.hiresTimer;

			log.warning('Create Ptd Article timing: {} s', t/1e6);
		}
		catch(e if e.is(Err.ConfigurationError)) {
			alert("Configuration file is missing or incomplete");
		}
		catch(e if e.is(Err.ArticleExistsError)) {
			e.alert();
		}
		// Just catch all expected errors
		//	catch(e) {
		//		alert(e);
		//	}
	})(PtdCreateService, Err);
});

$.gc();
log.warning('Footprint:\n\tArray:\t\t\t{Array}\n\tFunction:\t\t{Function}\n\t(workspace):\t{(workspace)}\n\tObject:\t\t\t{Object}', _.memArray());
