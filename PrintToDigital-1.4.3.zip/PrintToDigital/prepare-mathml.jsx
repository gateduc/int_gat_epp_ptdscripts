/**
 * @description Entry point for preparation of the InDesign article for use in Ptd
 *
 * @copyright WoodWing Software B.V. All rights reserved.
 */

#targetengine 'ptd'

var forceInit = false;

#include "modules/_.jsx"
#include "modules/err.jsx"
#include "modules/config-service.jsx"
#include "modules/ptd-prepare-service.jsx"
#include "modules/logging.jsx"
#include "modules/json2.js"

// Force reload the configuration
ConfigService.loadConfig();

log.init(ConfigService.getConfig().logging, ConfigService.getConfig().exportDirectory+"/"+File.prototype.basename(app.activeDocument.name),"indesign-create.log");
log.info('{}, config: \n{}', $.fileName, JSON.stringify(ConfigService.getConfig(), null, 4));

_.wrapInUndo('Prepare Ptd Article', function wrapper(){
	(function prepareMathMLScope(PtdPrepareService, Err){
		/**
		 * MAIN
		 */
		try {

			$.hiresTimer;
			PtdPrepareService.prepareMathML();
			var t = $.hiresTimer;

			log.warning('Prepare Ptd Article timing: {} s', t/1e6);
		}
		catch(e if e.is(Err.ConfigurationError)) {
			alert("Configuration file is missing or incomplete");
		}
		catch(e if e.is(Err.ArticleExistsError)) {
			e.alert();
		}
		// Just catch all expected errors
			catch(e) {
				alert(e);
			}
	})(PtdPrepareService, Err);
});

$.gc();
log.warning('Footprint:\n\tArray:\t\t\t{Array}\n\tFunction:\t\t{Function}\n\t(workspace):\t{(workspace)}\n\tObject:\t\t\t{Object}', _.memArray());
