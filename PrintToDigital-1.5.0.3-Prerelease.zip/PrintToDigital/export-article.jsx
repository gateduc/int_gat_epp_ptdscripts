/**
 * @description Entry point for export of the InDesign article for use in Ptd
 *
 * @copyright WoodWing Software B.V. All rights reserved.
 */

#targetengine 'ptd'

var forceInit = false;

#include "modules/err.jsx"
#include "modules/logging.jsx"
#include "modules/ptd-export-service.jsx"

// Force reload the configuration
ConfigService.loadConfig();

log.init(ConfigService.getConfig().logging, ConfigService.getConfig().exportDirectory+"/"+File.prototype.basename(app.activeDocument.name),"indesign-export.log");
log.info('{}, config: \n{}', $.fileName, JSON.stringify(ConfigService.getConfig(), null, 4));

(function(PtdExportService, Err){
	'use strict';

	try {
		$.hiresTimer;
		PtdExportService.exportArticle(ConfigService.getConfig().exportDirectory+"/"+File.prototype.basename(app.activeDocument.name));
		var t = $.hiresTimer;

		log.warning('Export Ptd Article timing: {} s', t/1e6);

	} catch(error if error.is(Err.ArticleDoesNotExistError)) {
		error.alert();
	}

})(PtdExportService, Err);

$.gc();
log.warning('Footprint:\n\tArray:\t\t\t{Array}\n\tFunction:\t\t{Function}\n\t(workspace):\t{(workspace)}\n\tObject:\t\t\t{Object}', _.memArray());
