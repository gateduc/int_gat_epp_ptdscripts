/**
 * @description Configuration file for creation and export to Ptd
 *
 * Collection: Grandes Autores
 * Discipline: Matemática Bianchini
 * Version: v1b0
 *
 * @copyright WoodWing Software B.V. All rights reserved.
 */
$.global.ptdConfig = {

	// Filter text based on paragraph style name. For now the only option.
	textFilter: 'paragraphStyleName',
	// Object with all digital article component types. Each type has an array of style names that will be used
	// to define the type. Style names can be either strings or regular expressions (in string form)
	// By default the text is placed in the text field of the component, to override this behavior add "." and the field name, for example subtitle.title
	// To use a specfic digitalComponentStyleOptions add a "#" and the name of the digitalComponentStyleOptions, for example title#option1_red or subtitle.title#option2_blue	

	//This is print to digital configuration script for Grandes Autores - Matemática Bianchini

	textFilterList: {
		"titleh1": [
			
		],
		"titleh1#Option1": [
			
		],
		"titleh1#Option2": [
			
		],
		"titleh1#Option3": [
		],
		"titleh2": [
		],
		"titleh2#Option1": [
		],
		"titleh2#Option2": [
		],
		"titleh2#Option3": [
		],
		"titleh3": [
		],
		"titleh4": [
		],
		"titleh4#Option1": [
		],
		"titleh4#Option2": [
		],
		"titleh5": [
		],
		"titleh5#Option1": [
		],
		"titleh5#Option2": [
		],
		"titleh5#Option3": [
		],
		"titleh5#Option4": [
		],
		"titleh5#Option5": [
		],
		"titleh5#Option6": [
		],
		"titleh5#Option7": [
		],
		"titleh5#Option8": [
		],
		"titleh5#Option9": [
		],
		"titleh5#Option10": [
		],
		"titleh6": [
		],
		"titleh6#Option1": [
		],
		"titleh6#Option2": [
		],
		"titleh6#Option3": [
		],
		"titleh6#Option4": [
		],
		"titleh6#Option5": [
		],
		"titleh6#Option6": [
		],
		"titleh6#Option7": [
		],
		"titleh6#Option8": [
		],
		"collapsiblebox": [
		],
		"image.caption": [
		],
		"picturecredit": [
		],
		"body": [
		],
		"body#Option1": [
		],
		"body#Option2": [
		],
		"body#Option3": [
		],
		"body#Option4": [
		],
		"body#Option5": [
		],
		"body#Option6": [
		],
		"body#Option7": [
		],
		"body#Option8": [
		],
		"body#Option9": [
		],
		"body#Option10": [
		],
		"body#Option11": [
		],
		"body#Option12": [
		],
		"body#Option13": [
		],
		"body#Option14": [
		],
		"body#Option15": [
		],
		"body#Option16": [
		],
		"body#Option17": [
		],
		"body#Option18": [
		],
		"body#Option19": [
		],
		"body#Option20": [
		],
		"body#Option21": [
		],
		"body#Option22": [
		],
		"body#Option23": [
		],
		"body#Option24": [
		],
		"body#Option25": [
		],
		"body#Option26": [
		],
		"body#Option27": [
		],
		"body#Option28": [
		],
		"footer": [
		],
		"footer#Option1": [
		],
		"crosshead": [
		],
		"crosshead#Option1": [
		],
		"crosshead#Option2": [
		],
		"crosshead#Option3": [
		],
		"unmaptext": [
		],
		"list-item": [
		],
		"titlewih1": [
		],
		"titlewih2": [
		],
		"titlewih3": [
		],
		"titlewih4": [
		],
		"titlewih5": [
		],
		"titlewih6": [	
		],
		"titlewithimage": [
		],
		"titlewithimage#Option1": [
		],
		"subtitle": [
		],
		"subtitle#Option8": [
		],
		"subtitle#Option30": [
		],
		"subtitle#Option32": [
		]
	},

	//if subtitle paragraph style, we always put the text in a container, and set it to a configured option
	summaryContainers: {
	},

	//optional, title settings
	appendTitle: {
		"titleh1": [
		],
		"titleh2": [
		],
		"titleh3": [
		],
		"titleh4": [
		],
		"titleh5": [
		],
		"titleh6": [
		]
	},

	//Optional digital component style definitions 
	digitalComponentStyles: {
		"Option1": {
			"styles": {
				"style": "_option1"
			}
		},
		"Option2": {
			"styles": {
				"style": "_option2"
			}
		},
		"Option3": {
			"styles": {
				"style": "_option3"
			}
		},
		"Option4": {
			"styles": {
				"style": "_option4"
			}
		},
		"Option5": {
			"styles": {
				"style": "_option5"
			}
		},
		"Option6": {
			"styles": {
				"style": "_option6"
			}
		},
		"Option7": {
			"styles": {
				"style": "_option7"
			}
		},
		"Option8": {
			"styles": {
				"style": "_option8"
			}
		},
		"Option9": {
			"styles": {
				"style": "_option9"
			}
		},
		"Option10": {
			"styles": {
				"style": "_option10"
			}
		},
		"Option11": {
			"styles": {
				"style": "_option11"
			}
		},
		"Option12": {
			"styles": {
				"style": "_option12"
			}
		},
		"Option13": {
			"styles": {
				"style": "_option13"
			}
		},
		"Option14": {
			"styles": {
				"style": "_option14"
			}
		},
		"Option15": {
			"styles": {
				"style": "_option15"
			}
		},
		"Option16": {
			"styles": {
				"style": "_option16"
			}
		},
		"Option17": {
			"styles": {
				"style": "_option17"
			}
		},
		"Option18": {
			"styles": {
				"style": "_option18"
			}
		},
		"Option19": {
			"styles": {
				"style": "_option19"
			}
		},
		"Option20": {
			"styles": {
				"style": "_option20"
			}
		},
		"Option21": {
			"styles": {
				"style": "_option21"
			}
		},
		"Option22": {
			"styles": {
				"style": "_option22"
			}
		},
		"Option23": {
			"styles": {
				"style": "_option23"
			}
		},
		"Option24": {
			"styles": {
				"style": "_option24"
			}
		},
		"Option25": {
			"styles": {
				"style": "_option25"
			}
		},
		"Option26": {
			"styles": {
				"style": "_option26"
			}
		},
		"Option27": {
			"styles": {
				"style": "_option27"
			}
		},
		"Option28": {
			"styles": {
				"style": "_option28"
			}
		},
		"Option29": {
			"styles": {
				"style": "_option29"
			}
		},
		"Option30": {
			"styles": {
				"style": "_option30"
			}
		},
		"Option31": {
			"styles": {
				"style": "_option31"
			}
		},
		"Option32": {
			"styles": {
				"style": "_option32"
			}
		},
		"Option33": {
			"styles": {
				"style": "_option33"
			}
		},
		"Option34": {
			"styles": {
				"style": "_option34"
			}
		},
		"Option35": {
			"styles": {
				"style": "_option35"
			}
		},
		"Option36": {
			"styles": {
				"style": "_option36"
			}
		},
		"Option37": {
			"styles": {
				"style": "_option37"
			}
		},
		"Option38": {
			"styles": {
				"style": "_option38"
			}
		},
		"Option39": {
			"styles": {
				"style": "_option39"
			}
		},
		"Option40": {
			"styles": {
				"style": "_option40"
			}
		},
		"Option41": {
			"styles": {
				"style": "_option41"
			}
		},
		"Option42": {
			"styles": {
				"style": "_option42"
			}
		},
		"Option43": {
			"styles": {
				"style": "_option43"
			}
		},
		"Option44": {
			"styles": {
				"style": "_option44"
			}
		},
		"Option45": {
			"styles": {
				"style": "_option45"
			}
		},
		"Option46": {
			"styles": {
				"style": "_option46"
			}
		},
		"Option47": {
			"styles": {
				"style": "_option47"
			}
		},
		"Option48": {
			"styles": {
				"style": "_option48"
			}
		},
		"Option49": {
			"styles": {
				"style": "_option49"
			}
		},
		"Option50": {
			"styles": {
				"style": "_option50"
			}
		}
	},

	imageComponent: {
		//Base json of the image component
		definition: {
			"content": {
				"image": {
					"id": "",
					"focuspoint": {
						"x": 0.5,
						"y": 0.5
					},
					"cropper": false
				},
				"caption": [],
				"picture credit": []
			},
			"id": "",
			"identifier": "image",
			"styles": {
				"fitting": "_fit-frame-height-to-content"
			}
		},

		//List of the text filters of the image component as configured in textFilterList
		textFilters: [
			"image.caption"
		]
	},
	
	ptdimageComponent: {
		definition: {
			"content": {
				"ptdimage": {
					"id": "",
					"focuspoint": {
						"x": 0.5,
						"y": 0.5
					},
					"cropper": false
				},
				"caption": [],
				"picture credit": []
			},
			"id": "",
			"identifier": "ptdimage",
			"styles": {
				"ptdimage-fitting": "_fitting",
				"ptdimage-style": ""
			},
			"inlineStyles": {
				"width": ""
			}
		},
		//List of the text filters of the image component as configured in textFilterList
		textFilters: [
			"image.caption"
		]
	},

	mathComponent: {
		definition: {
			"content": {
				"mathml": {
					"options": {
						"mathML": ""
					}
				}
			},
			"id": "",
			"data": {
				"mathml-html-data": ""
			},
			"identifier": "mathml",
			"styles": {}
		}
	},

	//collapsiblebox
	collapsible: {
		"answers": {
			definition: {
				"content": {
					"headerwithline": [
						{
							"insert": "Respostas e comentários"
						}
					]
				},
				"id": "",
				"identifier": "collapsiblebox",
				"styles": {},
				"containers": {
					"main": [
					]
				}
			}
		},
		"guidelines": {
			definition: {
				"content": {
					"headerwithline": [
						{
							"insert": "Orientações e sugestões didáticas"
						}
					]
				},
				"id": "",
				"identifier": "collapsiblebox",
				"styles": {},
				"containers": {
					"main": [
					]
				}
			}
		}
	},

	//Icon and Image Header definitions
	header: {
		"00-fixos-peso1": { //Paragraph style name
			definition: {
				"content": {
					"titlewih3": [		//title with icon example
					],
					"imageicon": {
						"id": "",
						"focuspoint": {
							"x": 0.5,
							"y": 0.5
						},
						"cropper": false
					}
				},
				"id": "",
				"identifier": "titlewithiconh3",
				"styles": {},
				"inlineStyles": {
				}
			}
		},
		"00-fixos-peso2": { //Paragraph style name
			definition: {
				"content": {
					"titlewih3": [		//title with icon example
					],
					"imageicon": {
						"id": "",
						"focuspoint": {
							"x": 0.5,
							"y": 0.5
						},
						"cropper": false
					}
				},
				"id": "",
				"identifier": "titlewithiconh3",
				"styles": {},
				"inlineStyles": {
				}
			}
		},
		"04-capitulo": { //Paragraph style name
			definition: {
				"content": {
					"imageicon": {
						"id": "",
						"focuspoint": {
							"x": 0.5,
							"y": 0.5
						},
						"cropper": false
					}
				},
				"id": "doc-1g5k3djco0",
				"identifier": "titlewithimage",
				"styles": {},
				"containers": {
					"main": []
				},
				"inlineStyles": {
				}
			},
			contentType: "titleh1"
		},
		"04-capitulo-numero": { //Paragraph style name
			definition: {
				"content": {
					"imageicon": {
						"id": "",
						"focuspoint": {
							"x": 0.5,
							"y": 0.5
						},
						"cropper": false
					}
				},
				"id": "doc-1g5k3djco0",
				"identifier": "titlewithimage",
				"styles": {},
				"containers": {
					"main": []
				},
				"inlineStyles": {
				}
			},
			contentType: "titleh1"
		},
		"04-capitulo-titulo": { //Paragraph style name
			definition: {
				"content": {
					"imageicon": {
						"id": "",
						"focuspoint": {
							"x": 0.5,
							"y": 0.5
						},
						"cropper": false
					}
				},
				"id": "doc-1g5k3djco0",
				"identifier": "titlewithimage",
				"styles": {},
				"containers": {
					"main": []
				},
				"inlineStyles": {
				}
			},
			contentType: "titleh1"
		}
	},

	//Place components in a container based on their paragraph style
	containers: {
		"bulleted-list-style": { //Paragraph style
			definition: { // Container definition 
				"content": {},
				"id": "",
				"identifier": "bulleted-list",
				"styles": {},
				"containers": {
					"main": []
				},
				"data":{
					"start":""
				}
			},
			containerName: "main", //Container field in the container definition
		},
		"numbered-list-style": { //Paragraph style
			definition: { // Container definition 
				"content": {},
				"id": "",
				"identifier": "numbered-list",
				"styles": {},
				"containers": {
					"main": []
				},
				"data":{
					"start":""
				}
			},
			containerName: "main", //Container field in the container definition
		},
		"lowerletters-list-style": { //Paragraph style
			definition: { // Container definition 
				"content": {},
				"id": "",
				"identifier": "lowerletters-list",
				"styles": {},
				"containers": {
					"main": []
				},
				"data":{
					"start":""
				}
			},
			containerName: "main", //Container field in the container definition
		},
		"upperletters-list-style": { //Paragraph style
			definition: { // Container definition 
				"content": {},
				"id": "",
				"identifier": "upperletters-list",
				"styles": {},
				"containers": {
					"main": []
				},
				"data":{
					"start":""
				}
			},
			containerName: "main", //Container field in the container definition
		},
		"upperroman-list-style": { //Paragraph style
			definition: { // Container definition 
				"content": {},
				"id": "",
				"identifier": "upperroman-list",
				"styles": {},
				"containers": {
					"main": []
				},
				"data":{
					"start":""
				}
			},
			containerName: "main", //Container field in the container definition
		}
	},

	// The 'styles' section provides the export details about what styling should result in bold and italic
	// overrides in the output.
	styles: {
		// Mark character styles as bold or italic. Matching is on full character style name. Most commonly used.
		character: {
			"Bold": { bold: true },
			"Bold Italic": { bold: true, italic: true },
			"Italic": { italic: true },
			"Subscript": { subscript: true },
			"Superscript": { superscript: true },
			"Underline": { underline: true },
			"Strikethrough": { strikethrough: true },
			"Uppercase": { uppercase: true },
			"Lowercase": { lowercase: true },
			"Titlecase": { titlecase: true }
		},
	
		// Mark use of certain font styles as bold or italic in the output. Be aware that this will match for all
		// font families used with the specified font style
		font: {
		},
		// Mark entire paragraphs as bold or italic. Not commonly used.
		paragraph: {
		}
	},

	// The 'output' section defines how bold and italic overrides will be output to Ptd. In addition it offers
	// the opportunity to remove and/or replace characters in the output. Html special characters will automatically be
	// escaped in the output.
	output: {
		htmlTags: {
			bold: {
				tag: "b"
			},
			italic: {
				tag: "i"
			},
			superscript: {
				tag: "sup"
			},
			subscript: {
				tag: "sub"
			},
			uppercase: {
				tag: "up"
			}
		},
		htmlEncode: [
		]
	},

	// Using the 'charConvert' section certain characters can be replaced by other characters 
	charConvert: [
		//Thin space to space
		['\u2009', ' ']
	],

	// The directory used as base directory for logging
	exportDirectory: '~/Desktop/ptd-indesign-logs',

	// Logging settings. Log files will be put in the document's output directory.
	logging: {
		level: 'INFO',
		wipe: false
	},

	//Content Station URL relative to index.php, default assumes that Content Station is installed in the same folder as index.php
	contentStationURL: "../app/",

	//If set to true, each set of grouped frames on a layout is added as a Container component.
	//Each frame of the group will be a separate component in the Container.
	//Note: The default Container component is used; custom Container components are not supported.
	createContainerForGroup: true,

	//If set to true, images will be scaled by percentage in conversion, respecting the scaling (percentage) of frame width and print page width
	//Else set image width to 100% in conversion, so that the image is sized by CSS styling or scaled to fit full width of digital article
	scalePTDImages: true,

	//image scaling amount for table images
	imageScaling: 2.5
};