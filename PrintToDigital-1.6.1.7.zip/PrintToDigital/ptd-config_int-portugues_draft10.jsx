/**
 * @description Configuration file for creation and export to Ptd
 * 
 * Collection: Interacao
 * Discipline: Portugues
 * 
 * PTD Config Version: Draft 10
 * Look n Feel Version: Draft 10
 * PTD Script Version: 1.6.1.2
 * Component Set Version: 1.6.0
 * 
 * @copyright WoodWing Software B.V. All rights reserved.
 */
 $.global.ptdConfig = {

	// Filter text based on paragraph style name. For now the only option.
	textFilter: 'paragraphStyleName',
	// Object with all digital article component types. Each type has an array of style names that will be used
	// to define the type. Style names can be either strings or regular expressions (in string form)
	// By default the text is placed in the text field of the component, to override this behavior add "." and the field name, for example subtitle.title
	// To use a specfic digitalComponentStyleOptions add a "#" and the name of the digitalComponentStyleOptions, for example title#option1_red or subtitle.title#option2_blue	

	//This is print to digital configuration script for Interacao Portugues

	textFilterList: {
		"titleh1": [
			"03_TITLEH1_referencias",
		],
		"titleh1#Option1": [
			"10_TITLEH1_finais_secao_titulo",
		],
		"titleh1#Option2": [
			"03_TITLEH1_finais_linha_tempo",
		],
		"titleh1#Option3": [
			"03_TITLEH1_unid_titulo_abre",
		],
		"titleh1#Option4": [
			"03_TITLEWICONH1_unid_titulo_abre",
		],
		"titleh1#Option5": [
			"04_TITLEH1_partes",
		],
		"titleh2": [
			"04_TITLEH2_cap_p2",
		],
		"titleh2#Option1": [
			"05_TITLEH2_secao_eu_voce",
		],
		"titleh2#Option2": [
			"05_TITLEH2_secao_pensamento",
		],
		"titleh2#Option3": [
			"03_TITLEWICONH2_cap_titulo_abre",
		],
		"titleh2#Option4": [
			"03_TITLEH2_unid_titulo_abre_LM",
		],
		"titleh2#Option5": [
			"03_TITLEH2_titulo_LM",
		],
		"titleh3": [
			"04_TITLEH3_cap_p2_eu_voce",
			"04_TITLEH3_cap_p2_fundocor",
		],
		"titleh3#Option1": [
			"04_TITLEH3_texto",
		],
		"titleh3#Option2": [
			"04_TITLEH3_cap_p1",
		],
		"titleh3#Option3": [
			"03_TITLEH3_propostas",
		],
		"titleh3#Option4": [
			"04_TITLEH3_cap_p2",
			"04_TITLEH3_cap_p2_pensamento",
		],
		"titleh3#Option5": [
			"04_TITLEH3_cap_p2_LM",
		],
		"titleh3#Option6": [
			"04_TITLEH3_titulo_LM",
		],
		"titleh4": [
			"04_TITLEH4_titulo_texto",
		],
		"titleh4#Option1": [
			"04_TITLEH4_cap_p1",
		],
		"titleh4#Option2": [
			"04_TITLEH4_titulo_tema_epoca",
		],
		"titleh4#Option3": [
			"04_TITLEH4_cap_p3_LM",
		],
		"titleh4#Option4": [
			"04_TITLEH4_cap_p2_LM",
		],
		"titleh5": [
			"04_TITLEH5_cap_p2",
		],
		"titleh5#Option1": [
			"04_TITLEH5_cap_p4_LM",
		],
		"titleh5#Option2": [
		],
		"titleh5#Option3": [
		],
		"titleh5#Option4": [
		],
		"titleh5#Option5": [
		],
		"titleh5#Option6": [
		],
		"titleh5#Option7": [
		],
		"titleh5#Option8": [
		],
		"titleh5#Option9": [
		],
		"titleh5#Option10": [
		],
		"titleh6": [
		],
		"titleh6#Option1": [
		],
		"titleh6#Option2": [
		],
		"titleh6#Option3": [
		],
		"titleh6#Option4": [
		],
		"titleh6#Option5": [
		],
		"titleh6#Option6": [
		],
		"titleh6#Option7": [
		],
		"titleh6#Option8": [
		],
		"subtitle": [
			"04_CROSS_icone_txt",
			"02_CROSS_sum_unid_titulo_lp_p1_numeracao",
		],
		"subtitle#Option1": [
			"02_CROSS_sum_unid_titulo_lp_p2_estudos",
		],
		"subtitle#Option2": [
			"02_CROSS_sum_unid_titulo_lp_p2_recuo",
			"02_CROSS_sum_unid_titulo_lp_p3_recuo",
		],
		"subtitle#Option3": [
			"05_BOXCROSS_cap_titulo_p5",
		],
		"subtitle#Option4": [
			"04_CROSS_cap_titulo_p6",
			"05_BOXCROSS_boxe_atencao_marcador"
			,"02_CROSS_sum_titulo_finais_p1",
			"02_CROSS_sum_unid_titulo_p1",
		],
		"subtitle#Option5": [
			"05_BOXCROSS_boxe_titulo_p1_ampliando",
			"05_BOXCROSS_boxe_titulo_p1_ampliando_lateral",
		],
		"subtitle#Option6": [
			"04_CROSS_cap_titulo_p5_lp",
		],
		"subtitle#Option7": [
			"02_CROSS_sum_titulo_finais_lp",
		],
		"subtitle#Option8": [
			"02_CROSS_sum_unid_titulo_lp_p1",
		],
		"subtitle#Option9": [
			"05_BOXCROSS_boxe_t2_voce_em_acao",
		],
		"subtitle#Option10": [
			"05_BOXCROSS_boxe_titulo_lateral_conexoes",
			"05_BOXCROSS_boxe_titulo_destaque",
			"05_BOXCROSS_boxe_t2_titulo_sintese",
			"05_BOXCROSS_boxe_t2_titulo",
			"05_BOXCROSS_boxe_conceito_p1",
			"05_BOXCROSS_boxe_trilha_do_enem_p1",
		],
		"subtitle#Option11": [
			"05_BOXCROSS_boxe_marcador_dica",
		],
		"subtitle#Option12": [
			"05_BOXCROSS_boxe_simples_p2",
		],
		"subtitle#Option13": [
			"05_BOXCROSS_boxe_titulo_enem",
			"05_BOXCROSS_boxe_t2_conexoes_marcador",
		],
		"subtitle#Option14": [
			"05_BOXCROSS_boxe_unid_titulo_l2",
			"02_CROSS_sum",
		],
		"subtitle#Option15": [
			"05_BOXCROSS_boxe_marcador_ampliando",
			"05_BOXCROSS_boxe_marcador_ampliando_lateral",
		],
		"subtitle#Option16": [
			"05_BOXCROSS_boxe_t2_esteticas_literarias",
		],
		"subtitle#Option17": [
			"06_CROSS_enem_vestibulares",
		],
		"subtitle#Option18": [
			"05_BOXCROSS_boxe_ficadica_lp_marcador",
		],
		"subtitle#Option19": [
			"04_CROSS_cap_titulo_p4",
		],
		"subtitle#Option20": [
			"05_BOXCROSS_boxe_de_olho_marcador",
		],
		"subtitle#Option21": [
			
		],
		"subtitle#Option22": [
			"01_CROSS_iniciais_titulo_p3",
		],
		"subtitle#Option23": [
			"04_CROSS_cap_titulo_p2",
			"01_CROSS_iniciais_titulo_p2",
		],
		"subtitle#Option24": [
			"01_CROSS_iniciais_comeco",
		],
		"subtitle#Option25": [
			"03_CROSS_unid_lp_titulo_p2",
		],
		"subtitle#Option26": [
			"01_CROSS_iniciais_titulo_p1",
		],
		"subtitle#Option27": [
			"01_CROSS_iniciais",
		],
		"subtitle#Option28": [
			"03_CROSS_unid_lp_titulo_p1",
		],
		"subtitle#Option29": [
			"02_CROSS_sum_unid_titulo_lp_p2_epoca",
		],
		"subtitle#Option30": [
			"02_CROSS_sum_unid_titulo_lp",
		],
		"subtitle#Option31": [
			"02_CROSS_sum_unid_titulo_lp_p2",
		],
		"subtitle#Option32": [
			"11_BOXCROSS_marcador_revista_impressa",
		],
		"subtitle#Option33": [
			"11_BOXCROSS_marcador_revista_online",
		],
		"subtitle#Option34": [
			"07_CROSS_numero_letra_imagem",
		],
		"subtitle#Option35": [
			"07_CROSS_gravata_mapa_grafico",
		],
		"subtitle#Option36": [
			"01_CROSS_conheca_titulo_p1",
		],
		"subtitle#Option37": [
			"11_BOXCROSS_revista_online",
		],
		"subtitle#Option38": [
			"11_BOXCROSS_revista_impressa",
		],
		"subtitle#Option39": [
			"01_CROSS_conheca_titulo_p2",
		],
		"subtitle#Option40": [
			"02_CROSS_sum_cap_p2",
		],
		"subtitle#Option41": [
			"02_CROSS_sum_cap_p3",
			"02_CROSS_sum_secao_titulo_p1",
			"02_CROSS_sum_unid_titulo_lp_p4",
		],
		"subtitle#Option42": [
			"02_CROSS_sum_cap_titulo_p1",
		],
		"subtitle#Option43": [
			"11_BOXCROSS_marcador_jornal",
		],
		"subtitle#Option44": [
			"11_BOXCROSS_web_jornal",
		],
		"subtitle#Option45": [
			"05_BOXCROSS_boxe_titulo_lateral",
		],
		"subtitle#Option46": [
			
		],
		"subtitle#Option47": [
			"05_BOXCROSS_boxe_unid_titulo_l1",
		],
		"subtitle#Option48": [
			
		],
		"subtitle#Option49": [
			"04_CROSS_titulo_p3_eu_voce",
		],
		"subtitle#Option50": [
			"05_BOXCROSS_boxe_titulo_dica",
		],
		"subtitle#Option51": [
			"05_BOXCROSS_boxe_simples_p1",
		],
		"subtitle#Option52": [
			"04_QUOTE_terc_subtitulo",
		],
		"subtitle#Option53": [
			"04_BOXQUOTE_terc_subtitulo_boxe_dica",
			"04_BOXQUOTE_terc_subtitulo_boxe_estetica",
			"04_BOXQUOTE_terc_subtitulo_boxe_trilha_do_enem",
		],
		"subtitle#Option54": [
			"04_CROSS_cap_titulo_p5",
		],
		"subtitle#Option55": [
			"05_BOXCROSS_boxe_bncc_lp_titulo",
		],
		"subtitle#Option56": [
			"05_BOXCROSS_glossario_lp_titulo",
		],
		"subtitle#Option57": [
			"04_CROSS_cap_titulo_p3_pensamento",
			"05_BOXCROSS_boxe_voce_em_acao_p1",
		],
		"subtitle#Option58": [
			"05_BOXCROSS_boxe_voce_em_acao_p2",
		],
		"subtitle#Option59": [
			"04_QUOTE_terc_subtitulo_eu_voce",
			"04_BOXQUOTE_terc_subtitulo_voce_em_acao",
			"04_BOXQUOTE_terc_subtitulo_boxe_simples",
			"04_BOXQUOTE_terc_subtitulo_boxe_ampliando",
			"04_BOXQUOTE_terc_subtitulo_boxe_conceito",
		],
		"subtitle#Option60": [
			"05_BOXCROSS_boxe_trilha_do_enem_p2",
			"05_BOXCROSS_boxe_dica_p2",
			"05_BOXCROSS_boxe_estetica_p2",
		],
		"subtitle#Option61": [
			"05_BOXCROSS_boxe_estetica_p1",
		],
		"subtitle#Option62": [
			"04_CROSS_cap_titulo_p3",
		],
		"subtitle#Option63": [
			"05_BOXCROSS_boxe_ampliando_p2",
			"05_BOXCROSS_boxe_conceito_p2",
		],
		"subtitle#Option64": [
			"05_BOXCROSS_secao_titulo_l2_LM",
			"04_CROSS_cap_titulo_p5_LM",
			"04_CROSS_cap_titulo_p6_LM",
			"05_BOXCROSS_secao_titulo_l2_LM",
		],
		"subtitle#Option65": [
			"02_CROSS_sum_cap_titulo_p1_LM",
		],
		"subtitle#Option66": [
			"07_CROSS_gravata_mapa_grafico_LM",
		],
		"subtitle#Option67": [
			"05_BOXCROSS_secao_titulo_LM",
		],
		"subtitle#Option68": [
			"02_CROSS_sum_parte_LM",
		],
		"subtitle#Option69": [
			"04_CROSS_cap_titulo_p4_LM",
		],
		"subtitle#Option70": [
			"01_CROSS_titulo_pagina_iniciais_LM",
		],
		"subtitle#Option71": [
			"05_BOXCROSS_boxe_ficadica_marcador_LM",
		],
		"subtitle#Option72": [
			"05_BOXCROSS_boxe_na_BNCC_LM",
		],
		"subtitle#Option73": [
			"05_BOXCROSS_boxe_objetivos_da_unidade_LM",
		],
		"subtitle#Option74": [
			"05_BOXCROSS_boxe_BNCC_nesta_unidade_LM",
		],
		"subtitle#Option75": [
			"05_BOXCROSS_boxe_para_ampliar_LM",
		],
		"subtitle#Option76": [
			"04_CROSS_cap_titulo_p3_LM",
		],
		"subtitle#Option77": [
			"02_CROSS_cap_titulo_abre",
		],
		"subtitle#Option78": [
			"01_CROSS_titulo_iniciais_LM",
		],
		"subtitle#Option79": [
			"01_CROSS_titulo_sumario_LM",
		],
		"subtitle#Option80": [
			"02_CROSS_sum_cap_titulo_p2_LM",
		],
		"subtitle#Option81": [
			"02_CROSS_sum_cap_titulo_p3_LM",
		],
		"subtitle#Option82": [
			"02_CROSS_sum_cap_titulo_p4_LM",
		],
		"subtitle#Option83": [
			"07_CROSS_numero_letra_imagem_LM",
		],
		"subtitle#Option84": [
			"04_QUOTE_terc_subtitulo_LM",
		],
		"subtitle#Option85": [
			"04_CROSS_cap_titulo_p2_LM",
		],
		"subtitle#Option86": [
			"05_BOXCROSS_boxe_matriz_ref_enem_LM",
		],
		"image.caption": [
			"07_BOXCAPTION_legenda_direita",
			"07_BOXCAPTION_legenda_esquerda",
			"07_CAPTION_legenda_branca",
			"07_CAPTION_legenda_direita",
			"07_CAPTION_legenda_esquerda",
			"07_CAPTION_legenda_direita_esteticas",
			"07_CAPTION_legenda_esquerda_eu_voce",
			"07_CAPTION_legenda_esquerda_pensamento",
			"11_BOXCAPTION_generos_legenda",
			"11_BOXCAPTION_legenda_revista_impressa",
			"07_CAPTION_legenda_LM",
		],
		"picturecredit": [
			"07_CREDIT_credito",
		],
		"picturecredit#Option1": [
			"07_CREDIT_credito_LM",
		],
		"body": [
			"05_BOXBODY_boxe_atencao",
			"04_BODY_text_sem_recuo",
			"05_BOXBODY_boxe_txt_lateral_na_bncc",
			"11_BOXBODY_email_cabecalho",
			"05_BOXBODY_boxe_txt_lateral_dados_biograficos",
			"05_BOXBODY_boxe_txt_lateral",
			"04_BODY_mapa_conceitual_2",
			"04_BODY_txt_filme_site_livro",
			"07_BODY_cota",
			"07_BODY_cota_branca",
			"07_LISTNUM_cota",
			"08_TABLE_txt",
			"08_TABLE_txt_centralizado",
			"08_TABLELISTBULLET_txt_bullet_level1",
			"08_TABLELISTBULLET_txt_bullet_level2",
			"08_TABLELISTBULLET_txt_bullet_level3",
			"08_TABLELISTNUM_txt_numerado",
			"05_BOXBODY_txt_geral_conceito",
			"04_BODY_resposta",
			"05_BOXBODY_boxe_txt_lateral_ampliando",
		],
		"body#Option1": [
			"05_BOXBODY_txt_geral_voce_em_acao",
			"05_BOXBODY_txt_geral_dica",
			"04_BODY_txt_eu_voce",
			"05_BOXBODY_txt_geral_destaque",
			"04_BODY_txt_geral_pensamento",
			"05_BOXBODY_txt_geral_simples",
			"05_BOXBODY_txt_geral_estetica",
			"04_BODY_txt_geral",
			"05_BOXBODY_txt_geral_de_olho",
			"05_BOXBODY_txt_geral",
			"09_BODY_exerc_resolucao",
			"05_BOXBODY_txt_geral_enem",
			"05_BOXBODY_txt_geral_ampliando",
		],
		"body#Option2": [
			"04_BOXBODY_txt_filme_site_livro",
			"05_BOXBODY_txt_filme_site_livro_hum",
			"03_BOXBODY_un_conexoes_resenha",
			"10_BODY_txt_referencias",
		],
		"body#Option3": [
			"04_BODY_txt_geral_centralizado",
			"05_BOXBODY_txt_conceito_centralizado",
			"05_BOXBODY_txt_geral_centralizado",
			"04_BODY_icone_titulo",
		],
		"body#Option4": [
			
		],
		"body#Option5": [
			"03_BODY_unid_enunciado_sem_num",
		],
		"body#Option6": [
			"09_BOXBODY_T2_exerc_contin",
		],
		"body#Option7": [
			"09_LIST_exerc_item_abc_contin",
		],
		"body#Option8": [
			
		],
		"body#Option9": [
			"07_BODY_lembretes",
		],
		"body#Option10": [
			"11_BOXBODY_intertitulo_revista_impressa",
			"04_BODY_mapa_conceitual_1",
			"10_BODY_indice_remis_txt_l1",
			"10_BODY_indice_remis_txt_l2",
			"08_TABLE_peso1",
			"08_TABLE_peso2",
		],
		"body#Option11": [
			"04_BODY_olho",
			"04_BODY_olho1",
		],
		"body#Option12": [
			"10_BODY_indice_remis_letra",
			"04_BODY_txt_destaque_lp",
		],
		"body#Option13": [
			"11_BOXBODY_subtitulo_revista_impressa",
		],
		"body#Option14": [
			"11_BOXBODY_subtitulo_revista_online",
		],
		"body#Option15": [
			"11_BOXBODY_web_jornal",
			"11_BOXBODY_TEXT_generos",
			"11_BOXBODY_TEXT_revista_impressa",
			"04_QUOTE_terc_txt_pensamento",
			"04_BOXQUOTE_terc_txt_boxe_trilha_do_enem",
			"04_BOXQUOTE_terc_txt_boxe_conceito",
			"04_BOXQUOTE_terc_txt_boxe_estetica",
			"04_BOXQUOTE_terc_txt_boxe_dica",
		],
		"body#Option16": [
		],
		"body#Option17": [
			"11_BOXBODY_generos_sem_recuo",
		],
		"body#Option18": [
			"11_BOXBODY_generos_intertitulo",
			"11_BOXBODY_jornal_intertitulo",
			"11_BOXBODY_revista_comentario_nome",
			"11_BOXBODY_revista_comentario",
		],
		"body#Option19": [
			"11_BOXBODY_jornal_subtitulo",
		],
		"body#Option20": [
			"10_BODY_referencias_comentarios",
			"09_BOXBODY_exerc_contin_destaque",
		],
		"body#Option21": [
			
		],
		"body#Option22": [
			"07_BOXCAPTION_legenda_esquerda_de_olho",
		],
		"body#Option23": [
			"01_BODY_txt_conheca",
		],
		"body#Option24": [
			"00_COLLAPBODY_transcricao",
		],
		"body#Option25": [
			"05_BOXQUOTE_terc_txt",
			"04_QUOTE_terc_txt_poesia",
		],
		"body#Option26": [
			"04_QUOTE_terc_chamada",
		],
		"body#Option27": [
		],
		"body#Option28": [
			"04_QUOTE_terc_txt_eu_voce",
			"04_BOXQUOTE_terc_txt_voce_em_acao",
			"04_BOXQUOTE_terc_txt_boxe_simples",
			"04_BOXQUOTE_terc_txt_boxe_ampliando",
		],
		"body#Option29": [
			"05_BOXBODY_boxe_txt_lateral_simples",
			"00_BODY_expediente",
		],
		"body#Option30": [
			"09_BOXBODY_T2_exerc_contin_destaque",
		],
		"body#Option31": [
			"07_BOXBODY_lembretes",
		],
		"body#Option32": [
			"04_QUOTE_terc_txt",
		],
		"body#Option33": [
			"09_BODY_exerc_lp_contin",
		],
		"body#Option34": [
			"04_BODY_icone_txt",
		],
		"body#Option35": [
			"08_BOXTABLE_peso2",
		],
		"body#Option36": [
			"04_BODY_mapa_conceitual_1_LM",
			"04_BODY_mapa_conceitual_2_LM",
			"04_BODY_text_sem_recuo_LM",
			"04_BODY_txt_quimica_LM",
			"05_BOXBODY_txt_competencias_LM",
			"05_BOXBODY_txt_sem_recuo_LM",
			"07_BODY_cota_LM",
			"07_BODY_lembretes_LM",
			"08_TABLE_txt_LM",
			"10_BODY_txt_referencias_LM",
		],
		"body#Option37": [
			"04_BODY_resposta_LM",
			"01_CROSS_txt_iniciais_LM",
			"04_BODY_txt_geral_LM",
			"05_BOXBODY_boxe_txt_para_ampliar_LM",
			"05_BOXBODY_txt_boxe_destaque_LM",
		],
		"body#Option38": [
			"10_BODY_referencias_comentarios_LM",
		],
		"body#Option39": [
			"04_BODY_txt_geral_centralizado_LM",
			"05_BOXBODY_txt_centralizado_boxe_destaque_LM",
			"08_TABLE_txt_centralizado_LM",
		],
		"body#Option40": [
			"07_BODY_cota_branca_LM",
		],
		"body#Option41": [
			"08_TABLE_peso1_LM",
			"08_TABLE_peso2_LM",
		],
		"body#Option42": [
			"04_QUOTE_terc_txt_LM",
		],
		"body#Option43": [
			"04_QUOTE_terc_txt_com_recuo_LM",
			"04_QUOTE_terc_txt_sem_recuo_LM",
			"04_QUOTE_terc_txt_resposta_LM",
		],
		"body#Option44": [
			"07_BOXBODY_fonte_dica",
			"07_BODY_fonte",
		],
		"body#Option45": [
			"04_BODY_resposta_numerada_cont_LM",
			"04_BODY_resposta_abc_cont_LM",
		],
		"body#Option46": [
			"05_BOXBODY_fonte_LM",
			"07_BODY_fonte_LM",
		],
		"body#Option47": [
			"05_BOXBODY_boxe_txt_objetivos_LM",
		],
		"body#Option48": [
			"04_BODY_genero_textual_fonte",
		],
		"body#Footnote": [
			"07_BODY_rodape",
			"07_BODY_rodape_fio",
			"04_BODY_txt_rodape_LM"
		],
		"body#Glossary": [
			"05_BOXBODY_glossario_verbete",
		],
		"bodylist": [
			"09_BOXLISTNUM_voce_em_acao_exerc_cor3",
			"09_BOXLISTNUM_secao_exerc_cor3",
			"09_LISTNUM_secao_pensamento_exerc_cor2",
			"05_BOXLISTBULL_boxe_simples_bullet",
			"05_BOXLISTBULL_boxe_bncc_bullet",
			"09_LISTNUM_box_exerc_pensar_123",
			"05_BOXLISTBULL_boxe_lateral_bullet",
			"03_LISTNUM_unid_enunciado_123",
			"04_LISTBULLET_txt_geral_l1",
			"09_LISTNUM_exerc_lp",
			"09_LISTNUM_secao_exerc_cor1_lp",
			"09_LISTNUM_secao_exerc_cor2",
			"09_LISTABC_gabarito_exercicio_abc",
			"05_BOXLISTABC_boxe_lateral_exercicio_abc_l1",
			"05_BOXLISTBULL_txt_bullet_l1",
			"05_BOXLISTNUM_boxe_exerc_lateral",
			"09_BOXLISTNUM_boxe_t2_exerc_lp",
			"00_COLLAPBODY_enunciado_atv_adaptada",
		],
		"bodylist#Option1": [
			"09_BOXBODY_bullet_voce_em_acao_l1",
			"09_BOXLISTBULL_bullet_voce_em_acao_l1",
			"09_BOXLISTABC_exerc_abc_destaque_l1_de_olho",
			"09_BOXLISTABC_secao_pensamento_t2_exerc_l1",
			"09_BODY_secao_pensamento_t2_exerc_l1",
			"09_LISTABC_exerc_item_abc_l1",
			"09_BOXLISTABC_boxe_t2_exerc_abc_l1",
			"09_BOXLISTBULL_T2_exerc_bullet_l1",
			"09_LIST_exerc_abc_cxa_lp",
			"09_LISTROMAN_exerc_item_romano",
			"05_BOXLISTABC_boxe_lateral_exercicio_abc_l2",
			"09_BOXLISTABC_exerc_abc_destaque_l1",
			"09_BOXBODY_bullet_boxe_conceito",
			"09_BOXBODY_bullet_boxe_estetica",
			"00_COLLAPBODY_abc_atv_adaptada",
			"00_COLLAPBODY_bullet_atv_adaptada",
		],
		"bodylist#Option2": [
			"04_LISTBULLET_txt_geral_l3",
			"09_LISTBULL_exerc_item_abc_bullet",
			"09_LISTBULLET_exerc_resolucao_l1",
			"04_BODY_bullet_secao_pensamento_l3",
			"04_BOXBODY_bullet_boxe_trilha_do_enem_l3",
			"04_BOXBODY_bullet_boxe_conceito_l3",
			"04_BOXBODY_bullet_boxe_estetica_l3",
			"04_BOXBODY_bullet_boxe_dica_l3",
		],
		"bodylist#Option3": [
			"04_QUOTELISTBULL_terc_bullet_l1",
		],
		"bodylist#Option4": [
			"04_QUOTE_terc_txt_numerado",
			"04_QUOTELISTBULL_terc_bullet_l2",
		],
		"bodylist#Option5": [
			"04_QUOTELISTBULL_terc_bullet_l3",
		],
		"bodylist#Option6": [
			"09_BODY_exerc_eu_voce",
			"04_BODY_txt_geral_numerado",
		],
		"bodylist#Option7": [
			"09_BOXBODY_bullet_boxe_ampliando",
		],
		"bodylist#Option8": [
			"04_BOXBODY_bullet_voce_em_acao_l3",
			"04_BOXBODY_bullet_boxe_simples_l3",
			"04_BOXBODY_bullet_boxe_ampliando_l3",
		],
		"bodylist#Option9": [
			"05_BOXLISTBULL_txt_bullet_l1_conexoes",
			"09_BOXLISTNUM_boxe_destaque_123",
			"05_BOXLISTBULL_txt_bullet_l1_enem",
			"09_BOXLISTNUM_boxe_de_olho_123",
			"09_BOXBODY_exerc_boxe_trilha_do_enem",
			"09_BOXBODY_exerc_boxe_conceito",
			"09_BOXBODY_exerc_boxe_estetica",
			"09_BOXBODY_exerc_boxe_dica",
			"03_BOXLISTBULLET_nesta_unidade_l1",
		],
		"bodylist#Option10": [
			"09_BOXBODY_exerc_item_abc_l1_boxe_conceito",
			"04_LISTBULLET_txt_geral_l2",
			"09_BODY_exerc_item_abc_l1",
			"04_LISTBULLET_eu_voce_l2",
			"09_BOXBODY_exerc_item_abc_l1_boxe_estetica",
			"09_BOXBODY_exerc_item_abc_l1_boxe_dica",
			"09_BOXBODY_bullet_boxe_dica",
			"09_BODY_bullet_secao_pensamento_l2",
			"09_BOXBODY_exerc_item_abc_l1_boxe_trilha_do_enem",
		],
		"bodylist#Option11": [
		],
		"bodylist#Option12": [
			"09_BOXBODY_exerc_boxe_simples",
			"09_BOXBODY_exerc_boxe_ampliando",
		],
		"bodylist#Option13": [
			"09_BODY_exerc_item_abc_l1_eu_voce",
			"09_BOXBODY_exerc_item_abc_l1_voce_em_acao",
			"09_BOXBODY_bullet_boxe_simples_l2",
			"09_BOXBODY_exerc_item_abc_l1_boxe_simples",
			"09_BOXBODY_exerc_item_abc_l1_boxe_ampliando",
		],
		"bodylist#Option14": [
			"04_BODY_BULLET_eu_voce_l3",
		],
		"bodylist#Option15": [
		],
		"bodylist#Option16": [
		],
		"bodylist#Option17": [
			"09_BODY_exerc_item_abc_bullet",
		],
		"bodylist#Option18": [
			"09_BODY_secao_pensamento_exerc_cor2",
			"04_LISTNUM_txt_geral_numerado",
			"09_BOXBODY_voce_em_acao_exerc_cor3",
			"09_BODY_exerc_lp",
			"09_BODY_secao_exerc_cor1_lp",
			"04_LISTNUM_txt_eu_voce_numerado",
		],
		"bodylist#Option19": [
		],
		"bodylist#Option20": [
		],
		"bodylist#Option21": [
			"04_BODY_bullet_unico_txt_geral_l1_LM",
			"04_LISTBULLET_txt_geral_l1_LM",
			"04_LISTNUM_txt_geral_numerado_LM",
			"05_BODY_bullet_unico_box_objetivos_LM",
			"05_BODY_bullet_unico_box_para_ampliar_LM",
			"05_BOXLISTBULL_boxe_bullet_objetivos_LM",
			"05_BOXLISTBULL_boxe_bullet_para_ampliar_LM",
			"08_BODY_txt_tabela_bullet_unico_level1_LM",
			"08_BODY_txt_tabela_numerado_LM",
			"08_TABLELISTBULLET_txt_bullet_level1_LM",
			"08_TABLELISTNUM_txt_abc_tabela_LM",
			"04_BODY_txt_geral_numerado_LM",
			"04_LISTBULLET_resposta_bullet_l1_LM",
			"04_BODY_resposta_bullet_unico_l1_LM",
			"04_BODY_resposta_numerada_LM",
		],
		"bodylist#Option22": [
			"04_LISTBULLET_txt_geral_l2_LM",
			"04_LISTNUM_txt_geral_abc_LM",
			"09_LISTABC_exerc_item_abc_l1_LM",
			"04_BODY_resposta_abc_LM",
			"04_BODY_resposta_recuo_abc_LM",
			"04_LISTBULLET_resposta_abc_bullet_l1_LM",
			"04_BODY_resposta_abc_bullet_unico_l1_LM",
			"04_LISTBULLET_resposta_numerada_bullet_l1_LM",
			"04_LISTROMAN_resposta_romano_LM",
		],
		"bodylist#Option23": [
		],
		"bodylist#Option24": [
			"04_QUOTE_terc_bullet_unico_l1_LM",
			"04_QUOTELISTBULL_terc_bullet_l1_LM",
			"04_QUOTELISTNUM_terc_txt_numerado_123_LM",
		],
		"bodylist#Option25": [
		],
		"bodylist#Option26": [
		],
		"footer": [
			
		],
		"footer#Option1": [
			
		],
		"crosshead": [
		],
		"crosshead#Option1": [
		],
		"crosshead#Option2": [
		],
		"crosshead#Option3": [
		],
		"unmaptext": [
			"/^.*/",
			"[Basic Paragraph]",
			"[No Paragraph Style]"
		],
		"list-item": [
		],
		"list-item#Option13": [
		],
		"list-item#Option16": [
		],
		"list-item#Option26": [
		],
		"titlewi": [
			"05_BOXBODY_txt_conceito",
		],
		"titlewi#Option1": [
			"02_CROSS_subsecao_marcador",
		],
		"titlewi#Option2": [
		],
		"titlewi#Option3": [
			"04_BODYWICON_cap_titulo_p1_LM",
		],
		"titlewih1": [
		],
		"titlewih2": [
			"05_TITLEWICONH2_secao_pensamento",
		],
		"titlewih2#Option1": [
			"05_TITLEWICONH2_secao_eu_voce",
		],
		"titlewih2#Option2": [
			"05_TITLEWICONH2_secao_titulo_hora_IA", 
			"04_TITLEWICONH2_secao_producao", 
			"05_TITLEWICONH2_secao_analise", 
			"05_TITLEWICONH2_secao_pensar",
		],
		"titlewih2#Option3": [
			"05_TITLEWICONH2_literatura_titulo"
		],
		"titlewih2#Option4": [
			"04_TITLEWICONH2_secao_passos"
		],
		"titlewih2#Option5": [
			"05_TITLEWICONH2_secao_titulo_leitura",
		],
		"titlewih2#Option6": [
			"04_TITLEWICONH2_cap_p1_LM",
		],
		"titlewih2#Option7": [
			"05_TITLEWICONH2_secao_titulo",
		],
		"titlewih3": [
			"04_TITLEWICONH3_epoca",
			"04_TITLEH3_epoca",
		],
		"titlewih3#Option1": [
			"05_TITLEWICONH3_secao_oficina",
		],
		"titlewih3#Option2": [
			"05_TITLEWICONH3_dialogos_titulo",
		],
		"titlewih3#Option3": [
			"05_TITLEWICONH3_secao_titulo_hora_mundodigital",
		],
		"titlewih3#Option4": [
			"04_TITLEWICONH3_cap_p1_LM",
		],
		"titlewih3#Option5": [
			"03_TITLEWICONH3_cap_titulo_abre_LM",
		],
		"titlewih4": [
		],
		"titlewih4#Option1": [
			"04_TITLEWICONH4_secao_temas",
		],
		"quotewithheader.header": [
			"04_QUOTE_terc_titulo",
			"04_QUOTE_terc_titulo_fundocor",
			"04_QUOTE_terc_titulo_pensamento",
		],
		"quotewithheader.header#Option1": [
			"05_BOXQUOTE_terc_titulo",
		],
		"quotewithheader.header#Option2": [
			"04_QUOTE_terc_titulo_eu_voce",
			"04_BOXQUOTE_terc_titulo_voce_em_acao",
			"04_BOXQUOTE_terc_titulo_boxe_simples",
			"04_BOXQUOTE_terc_titulo_boxe_ampliando",
		],
		"quotewithheader.header#Option3": [
			"04_BOXQUOTE_terc_titulo_boxe_dica",
			"04_BOXQUOTE_terc_titulo_boxe_conceito",
			"04_BOXQUOTE_terc_titulo_boxe_estetica",
			"04_BOXQUOTE_terc_titulo_boxe_trilha_do_enem",
		],
		"quotewithheader.header#Option4": [
			"04_QUOTE_terc_titulo_LM",
		],
		"quote.author": [
			"05_BOXQUOTE_terc_fonte_pensamento",
			"04_QUOTE_terc_fonte",
		],
		"quote.author#Option1": [
			"05_BOXQUOTE_terc_fonte_abertura",
			"05_BOXQUOTE_terc_fonte",
		],
		"quote.author#Option2": [
			"05_QUOTE_terc_fonte_eu_voce",
			"05_BOXQUOTE_terc_fonte_voce_em_acao",
			"05_BOXQUOTE_terc_fonte_boxe_simples",
			"05_BOXQUOTE_terc_fonte_boxe_ampliando",
		],
		"quote.author#Option3": [
			"05_BOXQUOTE_terc_fonte_boxe_dica",
			"05_BOXQUOTE_terc_fonte_boxe_conceito",
			"05_BOXQUOTE_terc_fonte_boxe_estetica",
			"05_BOXQUOTE_terc_fonte_boxe_trilha_do_enem",
		],
		"quote.author#Option4": [
			"04_QUOTE_terc_fonte_LM",
		],
	},

	styledBox: {
		"05_BOXLISTABC_boxe_lateral_exercicio_abc_l1": {
			style: "_default"
		},
		"05_BOXLISTBULL_txt_bullet_l1": {
			style: "_default"
		},
		"05_BOXLISTNUM_boxe_exerc_lateral": {
			style: "_default"
		},
		"09_BOXLISTNUM_boxe_t2_exerc_lp": {
			style: "_default"
		},
		"05_BOXLISTABC_boxe_lateral_exercicio_abc_l2": {
			style: "_default"
		},
		"09_BOXLISTABC_exerc_abc_destaque_l1": {
			style: "_default"
		},
		"05_BOXCROSS_cap_titulo_p5": {
			style: "_default"
		},
		"05_BOXCROSS_boxe_t2_titulo": {
			style: "_default"
		},
		"07_BOXBODY_lembretes": {
			style: "_option2"
		},
		"04_BODY_txt_geral_centralizado": {
			style: "_option7"
		},
		"05_BOXBODY_boxe_atencao": {
			style: "_option7"
		},
		"05_BOXBODY_txt_geral_conceito": {
			style: "_option7"
		},
		"05_BOXBODY_txt_conceito_centralizado": {
			style: "_option7"
		},
		"05_BOXBODY_txt_conceito": {
			style: "_option7"
		},
		"05_BOXCROSS_boxe_atencao_marcador": {
			style: "_option7"
		},
		"09_BOXBODY_exerc_boxe_conceito": {
			style: "_option7"
		},
		"09_BOXBODY_bullet_boxe_conceito": {
			style: "_option7"
		},
		"09_BOXBODY_exerc_item_abc_l1_boxe_conceito": {
			style: "_option7"
		},
		"04_BOXBODY_bullet_boxe_conceito_l3": {
			style: "_option7"
		},
		"05_BOXQUOTE_terc_fonte_boxe_conceito": {
			style: "_option7"
		},
		"04_BOXQUOTE_terc_subtitulo_boxe_conceito": {
			style: "_option7"
		},
		"04_BOXQUOTE_terc_txt_boxe_conceito": {
			style: "_option7"
		},
		"04_BOXQUOTE_terc_titulo_boxe_conceito": {
			style: "_option7"
		},
		"05_BOXCROSS_boxe_conceito_p2": {
			style: "_option7"
		},
		"05_BOXQUOTE_terc_fonte_voce_em_acao": {
			style: "_option8"
		},
		"04_BOXQUOTE_terc_subtitulo_voce_em_acao": {
			style: "_option8"
		},
		"04_BOXQUOTE_terc_txt_voce_em_acao": {
			style: "_option8"
		},
		"04_BOXQUOTE_terc_titulo_voce_em_acao": {
			style: "_option8"
		},
		"05_BOXBODY_txt_geral_voce_em_acao": {
			style: "_option8"
		},
		"09_BOXBODY_voce_em_acao_exerc_cor3": {
			style: "_option8"
		},
		"09_BOXLISTNUM_voce_em_acao_exerc_cor3": {
			style: "_option8"
		},
		"05_BOXLISTBULL_txt_bullet_l1_conexoes": {
			style: "_option8"
		},
		"09_BOXLISTNUM_secao_exerc_cor3": {
			style: "_option8"
		},
		"09_BOXBODY_bullet_voce_em_acao_l1": {
			style: "_option8"
		},
		"09_BOXLISTBULL_bullet_voce_em_acao_l1": {
			style: "_option8"
		},
		"05_BOXCROSS_boxe_t2_voce_em_acao": {
			style: "_option8"
		},
		"05_BOXCROSS_boxe_titulo_lateral_conexoes": {
			style: "_option8"
		},
		"09_BOXBODY_exerc_item_abc_l1_voce_em_acao": {
			style: "_option8"
		},
		"04_BOXBODY_bullet_voce_em_acao_l3": {
			style: "_option8"
		},
		"05_BOXCROSS_boxe_voce_em_acao_p2": {
			style: "_option8"
		},
		"05_BOXCROSS_boxe_voce_em_acao_p1": {
			style: "_option8"
		},
		"05_BOXQUOTE_terc_fonte_boxe_dica": {
			style: "_option9"
		},
		"09_BOXBODY_exerc_boxe_dica": {
			style: "_option9"
		},
		"09_BOXBODY_exerc_item_abc_l1_boxe_dica": {
			style: "_option9"
		},
		"09_BOXBODY_bullet_boxe_dica": {
			style: "_option9"
		},
		"04_BOXBODY_bullet_boxe_dica_l3": {
			style: "_option9"
		},
		"04_BOXQUOTE_terc_subtitulo_boxe_dica": {
			style: "_option9"
		},
		"04_BOXQUOTE_terc_txt_boxe_dica": {
			style: "_option9"
		},
		"04_BOXQUOTE_terc_titulo_boxe_dica": {
			style: "_option9"
		},
		"05_BOXCROSS_boxe_dica_p2": {
			style: "_option9"
		},
		"05_BOXBODY_txt_geral_dica": {
			style: "_option9"
		},
		"07_BOXBODY_fonte_dica": {
			style: "_option9"
		},
		"05_BOXCROSS_boxe_titulo_dica": {
			style: "_option9"
		},
		"05_BOXCROSS_boxe_marcador_dica": {
			style: "_option9"
		},
		"04_BOXBODY_txt_filme_site_livro": {
			style: "_option10"
		},
		"05_BOXBODY_txt_filme_site_livro_hum": {
			style: "_option10"
		},
		
		"09_BOXBODY_T2_exerc_contin_destaque": {
			style: "_option11"
		},
		"09_BOXLISTNUM_boxe_destaque_123": {
			style: "_option11"
		},
		"04_TITLEH3_cap_p2_fundocor": {
			style: "_option11"
		},
		"05_BOXCROSS_boxe_titulo_destaque": {
			style: "_option11"
		},
		"05_BOXBODY_txt_geral_destaque": {
			style: "_option12"
		},
		"05_BOXBODY_txt_geral_centralizado": {
			style: "_option12"
		},
		"09_BOXBODY_exerc_boxe_trilha_do_enem": {
			style: "_option13"
		},
		"09_BOXBODY_exerc_item_abc_l1_boxe_trilha_do_enem": {
			style: "_option13"
		},
		"04_BOXBODY_bullet_boxe_trilha_do_enem_l3": {
			style: "_option13"
		},
		"04_BOXQUOTE_terc_subtitulo_boxe_trilha_do_enem": {
			style: "_option13"
		},
		"04_BOXQUOTE_terc_txt_boxe_trilha_do_enem": {
			style: "_option13"
		},
		"04_BOXQUOTE_terc_titulo_boxe_trilha_do_enem": {
			style: "_option13"
		},
		"05_BOXCROSS_boxe_trilha_do_enem_p2": {
			style: "_option13"
		},
		"05_BOXCROSS_boxe_trilha_do_enem_p1": {
			style: "_option13"
		},
		"05_BOXBODY_txt_geral_enem": {
			style: "_option13"
		},
		"05_BOXLISTBULL_txt_bullet_l1_enem": {
			style: "_option13"
		},
		"09_BOXLISTNUM_boxe_de_olho_123": {
			style: "_option13"
		},
		"05_BOXBODY_txt_geral_de_olho": {
			style: "_option13"
		},
		"09_BOXLISTABC_exerc_abc_destaque_l1_de_olho": {
			style: "_option13"
		},
		"05_BOXCROSS_boxe_titulo_enem": {
			style: "_option13"
		},
		"03_BOXBODY_un_conexoes_resenha": {
			style: "_option14"
		},
		"05_BOXCROSS_boxe_t2_conexoes_marcador": {
			style: "_option14"
		},
		"05_BOXCROSS_boxe_estetica_p1": {
			style: "_option16"
		},
		"09_BOXBODY_exerc_boxe_estetica": {
			style: "_option16"
		},
		"09_BOXBODY_bullet_boxe_estetica": {
			style: "_option16"
		},
		"09_BOXBODY_exerc_item_abc_l1_boxe_estetica": {
			style: "_option16"
		},
		"04_BOXBODY_bullet_boxe_estetica_l3": {
			style: "_option16"
		},
		"05_BOXQUOTE_terc_fonte_boxe_estetica": {
			style: "_option16"
		},
		"04_BOXQUOTE_terc_subtitulo_boxe_estetica": {
			style: "_option16"
		},
		"04_BOXQUOTE_terc_txt_boxe_estetica": {
			style: "_option16"
		},
		"04_BOXQUOTE_terc_titulo_boxe_estetica": {
			style: "_option16"
		},
		"05_BOXCROSS_boxe_estetica_p2": {
			style: "_option16"
		},
		"05_BOXBODY_txt_geral_estetica": {
			style: "_option16"
		},
		"05_BOXCROSS_boxe_t2_titulo_sintese": {
			style: "_option16"
		},
		"05_BOXCROSS_boxe_t2_esteticas_literarias": {
			style: "_option16"
		},
		"05_BOXLISTBULL_boxe_simples_bullet": {
			style: "_option26"
		},
		"05_BOXBODY_boxe_txt_lateral_simples": {
			style: "_option17"
		},
		"05_BOXBODY_txt_geral_simples": {
			style: "_option17"
		},
		"05_BOXBODY_glossario_verbete": {
			style: "_option17"
		},
		"05_BOXBODY_boxe_txt_lateral": {
			style: "_option17"
		},
		"05_BOXBODY_txt_geral": {
			style: "_option17"
		},
		"005_BOXLISTBULL_boxe_lateral_bullet": {
			style: "_option17"
		},
		"05_BOXCROSS_glossario_lp_titulo": {
			style: "_option17"
		},
		"05_BOXCROSS_boxe_titulo_lateral": {
			style: "_option17"
		},
		"09_BOXBODY_exerc_boxe_simples": {
			style: "_option17"
		},
		"09_BOXBODY_bullet_boxe_simples_l2": {
			style: "_option17"
		},
		"09_BOXBODY_exerc_item_abc_l1_boxe_simples": {
			style: "_option17"
		},
		"04_BOXBODY_bullet_boxe_simples_l3": {
			style: "_option17"
		},
		"05_BOXQUOTE_terc_fonte_boxe_simples": {
			style: "_option17"
		},
		"04_BOXQUOTE_terc_subtitulo_boxe_simples": {
			style: "_option17"
		},
		"04_BOXQUOTE_terc_txt_boxe_simples": {
			style: "_option17"
		},
		"04_BOXQUOTE_terc_titulo_boxe_simples": {
			style: "_option17"
		},
		"05_BOXCROSS_boxe_simples_p2": {
			style: "_option17"
		},
		"05_BOXCROSS_boxe_simples_p1": {
			style: "_option17"
		},
		"05_BOXBODY_boxe_txt_lateral_na_bncc": {
			style: "_option18"
		},
		"05_BOXLISTBULL_boxe_bncc_bullet": {
			style: "_option18"
		},
		"05_BOXCROSS_boxe_bncc_lp_titulo": {
			style: "_option18"
		},
		"11_BOXBODY_TEXT_revista_impressa": {
			style: "_option21"
		},
		"11_BOXBODY_web_jornal": {
			style: "_option19"
		},
		"04_QUOTE_terc_txt_pensamento": {
			style: "_option28"
		},
		"11_BOXBODY_subtitulo_revista_online": {
			style: "_option19"
		},
		"11_BOXBODY_email_cabecalho": {
			style: "_option19"
		},
		"11_BOXBODY_jornal_subtitulo": {
			style: "_option19"
		},
		"11_BOXBODY_generos_intertitulo": {
			style: "_option19"
		},
		"11_BOXBODY_jornal_intertitulo": {
			style: "_option19"
		},
		"11_BOXBODY_revista_comentario_nome": {
			style: "_option19"
		},
		"11_BOXBODY_revista_comentario": {
			style: "_option19"
		},
		"11_BOXBODY_generos_sem_recuo": {
			style: "_option19"
		},
		"11_BOXBODY_TEXT_generos": {
			style: "_option19"
		},
		"11_BOXCROSS_marcador_revista_online": {
			style: "_option19"
		},
		"11_BOXCROSS_revista_online": {
			style: "_option19"
		},
		"11_BOXCROSS_marcador_jornal": {
			style: "_option19"
		},
		"11_BOXCROSS_web_jornal": {
			style: "_option19"
		},
		"05_BOXBODY_boxe_txt_lateral_dados_biograficos": {
			style: "_option20"
		},
		"11_BOXBODY_subtitulo_revista_impressa": {
			style: "_option21"
		},
		"11_BOXBODY_intertitulo_revista_impressa": {
			style: "_option21"
		},
		"11_BOXCROSS_marcador_revista_impressa": {
			style: "_option21"
		},
		"11_BOXCROSS_revista_impressa": {
			style: "_option21"
		},
		"03_BOXLISTBULLET_nesta_unidade_l1": {
			style: "_option22"
		},
		"05_BOXCROSS_boxe_unid_titulo_l2": {
			style: "_option22"
		},
		"05_BOXQUOTE_terc_titulo": {
			style: "_option24"
		},
		"05_BOXQUOTE_terc_fonte_abertura": {
			style: "_option24"
		},
		"05_BOXQUOTE_terc_txt": {
			style: "_option24"
		},
		"05_BOXBODY_boxe_txt_lateral_ampliando": {
			style: "_option27"
		},
		"05_BOXCROSS_boxe_titulo_p1_ampliando": {
			style: "_option27"
		},
		"05_BOXCROSS_boxe_titulo_p1_ampliando_lateral": {
			style: "_option27"
		},
		"04_LISTNUM_txt_eu_voce_numerado": {
			style: "_option27"
		},
		"04_LISTBULLET_eu_voce_l2": {
			style: "_option27"
		},
		"04_TITLEH3_cap_p2_eu_voce": {
			style: "_option27"
		},
		"04_BODY_txt_eu_voce": {
			style: "_option27"
		},
		"05_BOXBODY_txt_geral_ampliando": {
			style: "_option27"
		},
		"09_BODY_exerc_eu_voce": {
			style: "_option27"
		},
		"09_BOXBODY_exerc_boxe_ampliando": {
			style: "_option27"
		},
		"09_BODY_exerc_item_abc_l1_eu_voce": {
			style: "_option27"
		},
		"09_BOXBODY_bullet_boxe_ampliando": {
			style: "_option27"
		},
		"09_BOXBODY_exerc_item_abc_l1_boxe_ampliando": {
			style: "_option27"
		},
		"04_BODY_BULLET_eu_voce_l3": {
			style: "_option27"
		},
		"04_BOXBODY_bullet_boxe_ampliando_l3": {
			style: "_option27"
		},
		"05_QUOTE_terc_fonte_eu_voce": {
			style: "_option27"
		},
		"05_BOXQUOTE_terc_fonte_boxe_ampliando": {
			style: "_option27"
		},
		"04_QUOTE_terc_subtitulo_eu_voce": {
			style: "_option27"
		},
		"04_BOXQUOTE_terc_subtitulo_boxe_ampliando": {
			style: "_option27"
		},
		"04_QUOTE_terc_txt_eu_voce": {
			style: "_option27"
		},
		"04_BOXQUOTE_terc_txt_boxe_ampliando": {
			style: "_option27"
		},
		"04_QUOTE_terc_titulo_eu_voce": {
			style: "_option27"
		},
		"04_BOXQUOTE_terc_titulo_boxe_ampliando": {
			style: "_option27"
		},
		"05_BOXCROSS_boxe_ampliando_p2": {
			style: "_option27"
		},
		"04_CROSS_titulo_p3_eu_voce": {
			style: "_option27"
		},
		"04_BODY_txt_geral_pensamento": {
			style: "_option28"
		},
		"09_LISTNUM_secao_pensamento_exerc_cor2": {
			style: "_option28"
		},
		"09_BODY_secao_pensamento_exerc_cor2": {
			style: "_option28"
		},
		"09_BOXLISTABC_secao_pensamento_t2_exerc_l1": {
			style: "_option28"
		},
		"09_BODY_secao_pensamento_t2_exerc_l1": {
			style: "_option28"
		},
		"05_BOXQUOTE_terc_fonte_pensamento": {
			style: "_option28"
		},
		"04_QUOTE_terc_titulo_pensamento": {
			style: "_option28"
		},
		"04_CROSS_cap_titulo_p3_pensamento": {
			style: "_option28"
		},
		"04_TITLEH3_cap_p2_pensamento": {
			style: "_option28"
		},
		"09_BODY_bullet_secao_pensamento_l2": {
			style: "_option28"
		},
		"04_BODY_bullet_secao_pensamento_l3": {
			style: "_option28"
		},
		"05_BOXBODY_boxe_txt_objetivos_LM": {
			style: "_option31"
		},
		"05_BODY_bullet_unico_box_objetivos_LM": {
			style: "_option31"
		},
		"05_BOXLISTBULL_boxe_bullet_objetivos_LM": {
			style: "_option31"
		},
		"05_BOXBODY_boxe_txt_para_ampliar_LM": {
			style: "_option32"
		},
		"05_BODY_bullet_unico_box_para_ampliar_LM": {
			style: "_option32"
		},
		"05_BOXLISTBULL_boxe_bullet_para_ampliar_LM": {
			style: "_option32"
		},
		"05_BOXCROSS_boxe_para_ampliar_LM": {
			style: "_option32"
		},
		"05_BOXBODY_txt_boxe_destaque_LM": {
			style: "_option33"
		},
		"05_BOXBODY_txt_centralizado_boxe_destaque_LM": {
			style: "_option33"
		},
		"07_BODY_cota_branca_LM": {
			style: "_option34"
		},
		"05_BOXBODY_txt_competencias_LM": {
			style: "_option35"
		},
		"05_BOXBODY_txt_sem_recuo_LM": {
			style: "_option36"
		},
		"05_BOXCROSS_boxe_matriz_ref_enem_LM": {
			style: "_option36"
		},
		"05_BOXCROSS_boxe_na_BNCC_LM": {
			style: "_option36"
		},
		"07_BODY_lembretes_LM": {
			style: "_option37"
		},
		"04_TITLEH1_partes": {
			style: "_option38"
		},
	},

	summaryContainers: {
        "02_CROSS_sum": {
            style: "_option39"
        },
		"02_CROSS_sum_cap_p2": {
            style: "_option39"
        },
		"02_CROSS_sum_titulo_finais_lp": {
            style: "_option39"
        },
		"02_CROSS_sum_titulo_finais_p1": {
            style: "_option39"
        },
		"02_CROSS_sum_unid_titulo_lp_p1_numeracao": {
            style: "_option39"
        },
		"02_CROSS_sum_unid_titulo_lp_p2": {
            style: "_option39"
        },
		"02_CROSS_sum_unid_titulo_lp_p2_epoca": {
            style: "_option39"
        },
		"02_CROSS_sum_unid_titulo_lp_p2_estudos": {
            style: "_option39"
        },
		"02_CROSS_sum_unid_titulo_p1": {
            style: "_option39"
        },
		"02_CROSS_sum_cap_p3": {
            style: "_option39"
        },
		"02_CROSS_sum_secao_titulo_p1": {
            style: "_option39"
        },
		"02_CROSS_sum_unid_titulo_lp_p2_recuo": {
            style: "_option39"
        },
		"02_CROSS_sum_unid_titulo_lp_p3_recuo": {
            style: "_option39"
        },
		"02_CROSS_sum_unid_titulo_lp_p4": {
            style: "_option39"
        },
		"02_CROSS_sum_unid_titulo_lp_p1": {
            style: "_option40"
        },
		"02_CROSS_sum_parte_LM": {
            style: "_option41"
        },
		"02_CROSS_sum_cap_titulo_p1_LM": {
            style: "_option41"
        },
		"02_CROSS_sum_cap_titulo_p2_LM": {
            style: "_option42"
        },
		"02_CROSS_sum_cap_titulo_p3_LM": {
            style: "_option42"
        },
		"02_CROSS_sum_cap_titulo_p4_LM": {
            style: "_option42"
        },
    },

	//optional, title settings
	appendTitle: {
		"titleh1": [
		],
		"titleh2": [
		],
		"titleh3": [
		],
		"titleh4": [
		],
		"titleh5": [
		],
		"titleh6": [
		]
	},

	quotes:{
		"_default":[
			"04_QUOTE_terc_txt_pensamento", 
			"04_QUOTELISTBULL_terc_bullet_l1",
			"04_QUOTELISTBULL_terc_bullet_l2",
			"04_QUOTELISTBULL_terc_bullet_l3",
			"04_QUOTE_terc_subtitulo",
			"04_QUOTE_terc_txt", 
			"04_QUOTE_terc_txt_numerado",
			"04_QUOTE_terc_chamada", 
			"04_QUOTE_terc_txt_poesia",
		],
		"_option1":[
			"05_BOXQUOTE_terc_txt", 
		],
		"_option2":[
			"04_QUOTE_terc_subtitulo_eu_voce",
			"04_QUOTE_terc_txt_eu_voce",
			"04_BOXQUOTE_terc_txt_voce_em_acao",
			"04_BOXQUOTE_terc_subtitulo_voce_em_acao",
			"04_BOXQUOTE_terc_subtitulo_boxe_simples",
			"04_BOXQUOTE_terc_txt_boxe_simples",
			"04_BOXQUOTE_terc_subtitulo_boxe_ampliando",
			"04_BOXQUOTE_terc_txt_boxe_ampliando",
		],
		"_option3":[
			"04_BOXQUOTE_terc_txt_boxe_dica",
			"04_BOXQUOTE_terc_subtitulo_boxe_dica",	
			"04_BOXQUOTE_terc_txt_boxe_conceito",
			"04_BOXQUOTE_terc_subtitulo_boxe_conceito",
			"04_BOXQUOTE_terc_txt_boxe_estetica",
			"04_BOXQUOTE_terc_subtitulo_boxe_estetica",
			"04_BOXQUOTE_terc_subtitulo_boxe_trilha_do_enem",
			"04_BOXQUOTE_terc_txt_boxe_trilha_do_enem",
		],
		"_option4":[
			"04_QUOTE_terc_subtitulo_LM",
			"04_QUOTE_terc_txt_LM",
			"04_QUOTE_terc_txt_sem_recuo_LM",
			"04_QUOTE_terc_txt_resposta_LM",
		],
		"_option5":[
			"04_QUOTE_terc_txt_com_recuo_LM",
			"04_QUOTE_terc_txt_resposta_LM",
		],
		
	},

	//Optional digital component style definitions 
	digitalComponentStyles: {
		"Footnote": {
			"styles": {
				"style": "_footnote"
			}
		},
		"Glossary": {
			"styles": {
				"style": "_glossary"
			}
		},
		"Option1": {
			"styles": {
				"style": "_option1"
			}
		},
		"Option2": {
			"styles": {
				"style": "_option2"
			}
		},
		"Option3": {
			"styles": {
				"style": "_option3"
			}
		},
		"Option4": {
			"styles": {
				"style": "_option4"
			}
		},
		"Option5": {
			"styles": {
				"style": "_option5"
			}
		},
		"Option6": {
			"styles": {
				"style": "_option6"
			}
		},
		"Option7": {
			"styles": {
				"style": "_option7"
			}
		},
		"Option8": {
			"styles": {
				"style": "_option8"
			}
		},
		"Option9": {
			"styles": {
				"style": "_option9"
			}
		},
		"Option10": {
			"styles": {
				"style": "_option10"
			}
		},
		"Option11": {
			"styles": {
				"style": "_option11"
			}
		},
		"Option12": {
			"styles": {
				"style": "_option12"
			}
		},
		"Option13": {
			"styles": {
				"style": "_option13"
			}
		},
		"Option14": {
			"styles": {
				"style": "_option14"
			}
		},
		"Option15": {
			"styles": {
				"style": "_option15"
			}
		},
		"Option16": {
			"styles": {
				"style": "_option16"
			}
		},
		"Option17": {
			"styles": {
				"style": "_option17"
			}
		},
		"Option18": {
			"styles": {
				"style": "_option18"
			}
		},
		"Option19": {
			"styles": {
				"style": "_option19"
			}
		},
		"Option20": {
			"styles": {
				"style": "_option20"
			}
		},
		"Option21": {
			"styles": {
				"style": "_option21"
			}
		},
		"Option22": {
			"styles": {
				"style": "_option22"
			}
		},
		"Option23": {
			"styles": {
				"style": "_option23"
			}
		},
		"Option24": {
			"styles": {
				"style": "_option24"
			}
		},
		"Option25": {
			"styles": {
				"style": "_option25"
			}
		},
		"Option26": {
			"styles": {
				"style": "_option26"
			}
		},
		"Option27": {
			"styles": {
				"style": "_option27"
			}
		},
		"Option28": {
			"styles": {
				"style": "_option28"
			}
		},
		"Option29": {
			"styles": {
				"style": "_option29"
			}
		},
		"Option30": {
			"styles": {
				"style": "_option30"
			}
		},
		"Option31": {
			"styles": {
				"style": "_option31"
			}
		},
		"Option32": {
			"styles": {
				"style": "_option32"
			}
		},
		"Option33": {
			"styles": {
				"style": "_option33"
			}
		},
		"Option34": {
			"styles": {
				"style": "_option34"
			}
		},
		"Option35": {
			"styles": {
				"style": "_option35"
			}
		},
		"Option36": {
			"styles": {
				"style": "_option36"
			}
		},
		"Option37": {
			"styles": {
				"style": "_option37"
			}
		},
		"Option38": {
			"styles": {
				"style": "_option38"
			}
		},
		"Option39": {
			"styles": {
				"style": "_option39"
			}
		},
		"Option40": {
			"styles": {
				"style": "_option40"
			}
		},
		"Option41": {
			"styles": {
				"style": "_option41"
			}
		},
		"Option42": {
			"styles": {
				"style": "_option42"
			}
		},
		"Option43": {
			"styles": {
				"style": "_option43"
			}
		},
		"Option44": {
			"styles": {
				"style": "_option44"
			}
		},
		"Option45": {
			"styles": {
				"style": "_option45"
			}
		},
		"Option46": {
			"styles": {
				"style": "_option46"
			}
		},
		"Option47": {
			"styles": {
				"style": "_option47"
			}
		},
		"Option48": {
			"styles": {
				"style": "_option48"
			}
		},
		"Option49": {
			"styles": {
				"style": "_option49"
			}
		},
		"Option50": {
			"styles": {
				"style": "_option50"
			}
		},
		"Option51": {
			"styles": {
				"style": "_option51"
			}
		},
		"Option52": {
			"styles": {
				"style": "_option52"
			}
		},
		"Option53": {
			"styles": {
				"style": "_option53"
			}
		},
		"Option54": {
			"styles": {
				"style": "_option54"
			}
		},
		"Option55": {
			"styles": {
				"style": "_option55"
			}
		},
		"Option56": {
			"styles": {
				"style": "_option56"
			}
		},
		"Option57": {
			"styles": {
				"style": "_option57"
			}
		},
		"Option58": {
			"styles": {
				"style": "_option58"
			}
		},
		"Option59": {
			"styles": {
				"style": "_option59"
			}
		},
		"Option60": {
			"styles": {
				"style": "_option60"
			}
		},
		"Option61": {
			"styles": {
				"style": "_option61"
			}
		},
		"Option62": {
			"styles": {
				"style": "_option62"
			}
		},
		"Option63": {
			"styles": {
				"style": "_option63"
			}
		},
		"Option64": {
			"styles": {
				"style": "_option64"
			}
		},
		"Option65": {
			"styles": {
				"style": "_option65"
			}
		},
		"Option66": {
			"styles": {
				"style": "_option66"
			}
		},
		"Option67": {
			"styles": {
				"style": "_option67"
			}
		},
		"Option68": {
			"styles": {
				"style": "_option68"
			}
		},
		"Option69": {
			"styles": {
				"style": "_option69"
			}
		},
		"Option70": {
			"styles": {
				"style": "_option70"
			}
		},
		"Option71": {
			"styles": {
				"style": "_option71"
			}
		},
		"Option72": {
			"styles": {
				"style": "_option72"
			}
		},
		"Option73": {
			"styles": {
				"style": "_option73"
			}
		},
		"Option74": {
			"styles": {
				"style": "_option74"
			}
		},
		"Option75": {
			"styles": {
				"style": "_option75"
			}
		},
		"Option76": {
			"styles": {
				"style": "_option76"
			}
		},
		"Option77": {
			"styles": {
				"style": "_option77"
			}
		},
		"Option78": {
			"styles": {
				"style": "_option78"
			}
		},
		"Option79": {
			"styles": {
				"style": "_option79"
			}
		},
		"Option80": {
			"styles": {
				"style": "_option80"
			}
		},
		"Option81": {
			"styles": {
				"style": "_option81"
			}
		},
		"Option82": {
			"styles": {
				"style": "_option82"
			}
		},
		"Option83": {
			"styles": {
				"style": "_option83"
			}
		},
		"Option84": {
			"styles": {
				"style": "_option84"
			}
		},
		"Option85": {
			"styles": {
				"style": "_option85"
			}
		},
		"Option86": {
			"styles": {
				"style": "_option86"
			}
		},
		"Option87": {
			"styles": {
				"style": "_option87"
			}
		},
		"Option88": {
			"styles": {
				"style": "_option88"
			}
		},
		"Option89": {
			"styles": {
				"style": "_option89"
			}
		},
		"Option90": {
			"styles": {
				"style": "_option90"
			}
		},
		"Option91": {
			"styles": {
				"style": "_option91"
			}
		},
		"Option92": {
			"styles": {
				"style": "_option92"
			}
		},
		"Option93": {
			"styles": {
				"style": "_option93"
			}
		},
		"Option94": {
			"styles": {
				"style": "_option94"
			}
		},
		"Option95": {
			"styles": {
				"style": "_option95"
			}
		},
		"Option96": {
			"styles": {
				"style": "_option96"
			}
		},
		"Option97": {
			"styles": {
				"style": "_option97"
			}
		},
		"Option98": {
			"styles": {
				"style": "_option98"
			}
		},
		"Option99": {
			"styles": {
				"style": "_option99"
			}
		},
		"Option100": {
			"styles": {
				"style": "_option100"
			}
		},
	},

	imageComponent: {
		//Base json of the image component
		definition: {
			"content": {
				"image": {
					"id": "",
					"focuspoint": {
						"x": 0.5,
						"y": 0.5
					},
					"cropper": false
				},
				"caption": [],
				"picture credit": []
			},
			"id": "",
			"identifier": "image",
			"styles": {
				"fitting": "_fit-frame-height-to-content"
			}
		},

		//List of the text filters of the image component as configured in textFilterList
		textFilters: [
			"image.caption"
		]
	},
	
	ptdimageComponent: {
		definition: {
			"content": {
				"ptdimage": {
					"id": "",
					"focuspoint": {
						"x": 0.5,
						"y": 0.5
					},
					"cropper": false
				},
				"caption": [],
				"picture credit": []
			},
			"id": "",
			"identifier": "ptdimage",
			"styles": {
				"ptdimage-fitting": "_fitting",
				"ptdimage-style": ""
			},
			"inlineStyles": {
				"width": ""
			}
		},
		//List of the text filters of the image component as configured in textFilterList
		textFilters: [
			"image.caption"
		]
	},

	mathComponent: {
		definition: {
			"content": {
				"mathml": {
					"options": {
						"mathML": ""
					}
				}
			},
			"id": "",
			"data": {
				"mathml-html-data": ""
			},
			"identifier": "mathml",
			"styles": {}
		}
	},

	//collapsiblebox
	collapsible: {
		"00_COLLAPBODY_abc_atv_adaptada": {
			definition: {
				"content": {
					"headerwithline": [
						{
							"insert": "Atividade adaptada"
						}
					]
				},
				"id": "",
				"identifier": "collapsiblebox",
				"styles": {},
				"containers": {
					"main": []
				}
			}
		},
		"00_COLLAPBODY_bullet_atv_adaptada": {
			definition: {
				"content": {
					"headerwithline": [
						{
							"insert": "Atividade adaptada"
						}
					]
				},
				"id": "",
				"identifier": "collapsiblebox",
				"styles": {},
				"containers": {
					"main": []
				}
			}
		},
		"00_COLLAPBODY_enunciado_atv_adaptada": {
			definition: {
				"content": {
					"headerwithline": [
						{
							"insert": "Atividade adaptada"
						}
					]
				},
				"id": "",
				"identifier": "collapsiblebox",
				"styles": {},
				"containers": {
					"main": []
				}
			}
		},
		"04_BODY_resposta": {
			definition: {
				"content": {
					"headerwithline": [
						{
							 "insert": "Orienta\u00E7\u00E3o para o professor"
						}
					]
				},
				"id": "",
				"identifier": "collapsiblebox",
				"styles": {},
				"containers": {
					"main": []
				}
			}
		},
		"00_COLLAPBODY_transcricao": {
			definition: {
				"content": {
					"headerwithline": [
						{
							"insert": "Transcri\u00E7\u00E3o" 
						}
					]
				},
				"id": "",
				"identifier": "collapsiblebox",
				"styles": {},
				"containers": {
					"main": []
				}
			}
		},
	},

	//Icon and Image Header definitions
	header: {
		"04_BODYWICON_cap_titulo_p1_LM": { //Paragraph style name
			definition: {
				"content": {
					"imageicon": {
						"id": "",
						"focuspoint": {
							"x": 0.5,
							"y": 0.5
						},
						"cropper": false
					},
					"titlewi": [		//title with icon example
					],
				},
				"id": "",
				"identifier": "titlewithicon",
				"styles": {},
				"inlineStyles": {
				}
			}
		},
		"04_TITLEWICONH2_cap_p1_LM": { //Paragraph style name
			definition: {
				"content": {
					"imageicon": {
						"id": "",
						"focuspoint": {
							"x": 0.5,
							"y": 0.5
						},
						"cropper": false
					},
					"titlewih2": [		//title with icon example
					],
				},
				"id": "",
				"identifier": "titlewithiconh2",
				"styles": {},
				"inlineStyles": {
				}
			}
		},
		"04_TITLEWICONH3_cap_p1_LM": { //Paragraph style name
			definition: {
				"content": {
					"imageicon": {
						"id": "",
						"focuspoint": {
							"x": 0.5,
							"y": 0.5
						},
						"cropper": false
					},
					"titlewih3": [		//title with icon example
					],
				},
				"id": "",
				"identifier": "titlewithiconh3",
				"styles": {},
				"inlineStyles": {
				}
			}
		},
		"05_BOXBODY_txt_conceito": { //Paragraph style name
			definition: {
				"content": {
					"imageicon": {
						"id": "",
						"focuspoint": {
							"x": 0.5,
							"y": 0.5
						},
						"cropper": false
					},
					"titlewi": [		//title with icon example
					],
				},
				"id": "",
				"identifier": "titlewithicon",
				"styles": {},
				"inlineStyles": {
				}
			}
		},
		"02_CROSS_subsecao_marcador": { //Paragraph style name
			definition: {
				"content": {
					"imageicon": {
						"id": "",
						"focuspoint": {
							"x": 0.5,
							"y": 0.5
						},
						"cropper": false
					},
					"titlewi": [		//title with icon example
					],
				},
				"id": "",
				"identifier": "titlewithicon",
				"styles": {},
				"inlineStyles": {
				}
			}
		},
		"05_TITLEWICONH2_secao_pensamento": { //Paragraph style name
			definition: {
				"content": {
					"imageicon": {
						"id": "",
						"focuspoint": {
							"x": 0.5,
							"y": 0.5
						},
						"cropper": false
					},
					"titlewih2": [		//title with icon example
					],
				},
				"id": "",
				"identifier": "titlewithiconh2",
				"styles": {},
				"inlineStyles": {
				}
			}
		},
		"05_TITLEWICONH2_secao_eu_voce": { //Paragraph style name
			definition: {
				"content": {
					"imageicon": {
						"id": "",
						"focuspoint": {
							"x": 0.5,
							"y": 0.5
						},
						"cropper": false
					},
					"titlewih2": [		//title with icon example
					],
				},
				"id": "",
				"identifier": "titlewithiconh2",
				"styles": {},
				"inlineStyles": {
				}
			}
		},
		"04_TITLEWICONH4_secao_temas": { //Paragraph style name
			definition: {
				"content": {
					"imageicon": {
						"id": "",
						"focuspoint": {
							"x": 0.5,
							"y": 0.5
						},
						"cropper": false
					},
					"titlewih4": [		//title with icon example
					],
				},
				"id": "",
				"identifier": "titlewithiconh4",
				"styles": {},
				"inlineStyles": {
				}
			}
		},
		"05_TITLEWICONH3_secao_oficina": { //Paragraph style name
			definition: {
				"content": {
					"imageicon": {
						"id": "",
						"focuspoint": {
							"x": 0.5,
							"y": 0.5
						},
						"cropper": false
					},
					"titlewih3": [		//title with icon example
					],
				},
				"id": "",
				"identifier": "titlewithiconh3",
				"styles": {},
				"inlineStyles": {
				}
			}
		},
		"05_TITLEWICONH2_secao_titulo_hora_IA": { //Paragraph style name
			definition: {
				"content": {
					"imageicon": {
						"id": "",
						"focuspoint": {
							"x": 0.5,
							"y": 0.5
						},
						"cropper": false
					},
					"titlewih2": [		//title with icon example
					],
				},
				"id": "",
				"identifier": "titlewithiconh2",
				"styles": {},
				"inlineStyles": {
				}
			}
		},
		"04_TITLEWICONH2_secao_producao": { //Paragraph style name
			definition: {
				"content": {
					"imageicon": {
						"id": "",
						"focuspoint": {
							"x": 0.5,
							"y": 0.5
						},
						"cropper": false
					},
					"titlewih2": [		//title with icon example
					],
				},
				"id": "",
				"identifier": "titlewithiconh2",
				"styles": {},
				"inlineStyles": {
				}
			}
		},
		"05_TITLEWICONH2_secao_analise": { //Paragraph style name
			definition: {
				"content": {
					"imageicon": {
						"id": "",
						"focuspoint": {
							"x": 0.5,
							"y": 0.5
						},
						"cropper": false
					},
					"titlewih2": [		//title with icon example
					],
				},
				"id": "",
				"identifier": "titlewithiconh2",
				"styles": {},
				"inlineStyles": {
				}
			}
		},
		"05_TITLEWICONH2_secao_pensar": { //Paragraph style name
			definition: {
				"content": {
					"imageicon": {
						"id": "",
						"focuspoint": {
							"x": 0.5,
							"y": 0.5
						},
						"cropper": false
					},
					"titlewih2": [		//title with icon example
					],
				},
				"id": "",
				"identifier": "titlewithiconh2",
				"styles": {},
				"inlineStyles": {
				}
			}
		},
		"05_TITLEWICONH3_dialogos_titulo": { //Paragraph style name
			definition: {
				"content": {
					"imageicon": {
						"id": "",
						"focuspoint": {
							"x": 0.5,
							"y": 0.5
						},
						"cropper": false
					},
					"titlewih3": [		//title with icon example
					],
				},
				"id": "",
				"identifier": "titlewithiconh3",
				"styles": {},
				"inlineStyles": {
				}
			}
		},
		"05_TITLEWICONH2_secao_titulo": { //Paragraph style name
			definition: {
				"content": {
					"imageicon": {
						"id": "",
						"focuspoint": {
							"x": 0.5,
							"y": 0.5
						},
						"cropper": false
					},
					"titlewih2": [		//title with icon example
					],
				},
				"id": "",
				"identifier": "titlewithiconh2",
				"styles": {},
				"inlineStyles": {
				}
			}
		},
		"04_TITLEWICONH2_secao_passos": { //Paragraph style name
			definition: {
				"content": {
					"imageicon": {
						"id": "",
						"focuspoint": {
							"x": 0.5,
							"y": 0.5
						},
						"cropper": false
					},
					"titlewih2": [		//title with icon example
					],
				},
				"id": "",
				"identifier": "titlewithiconh2",
				"styles": {},
				"inlineStyles": {
				}
			}
		},
		"05_TITLEWICONH2_literatura_titulo": { //Paragraph style name
			definition: {
				"content": {
					"imageicon": {
						"id": "",
						"focuspoint": {
							"x": 0.5,
							"y": 0.5
						},
						"cropper": false
					},
					"titlewih2": [		//title with icon example
					],
				},
				"id": "",
				"identifier": "titlewithiconh2",
				"styles": {},
				"inlineStyles": {
				}
			}
		},
		"05_TITLEWICONH2_secao_titulo_leitura": { //Paragraph style name
			definition: {
				"content": {
					"imageicon": {
						"id": "",
						"focuspoint": {
							"x": 0.5,
							"y": 0.5
						},
						"cropper": false
					},
					"titlewih2": [		//title with icon example
					],
				},
				"id": "",
				"identifier": "titlewithiconh2",
				"styles": {},
				"inlineStyles": {
				}
			}
		},
		"05_TITLEWICONH3_secao_titulo_hora_mundodigital": { //Paragraph style name
			definition: {
				"content": {
					"imageicon": {
						"id": "",
						"focuspoint": {
							"x": 0.5,
							"y": 0.5
						},
						"cropper": false
					},
					"titlewih3": [		//title with icon example
					],
				},
				"id": "",
				"identifier": "titlewithiconh3",
				"styles": {},
				"inlineStyles": {
				}
			}
		},
		"04_TITLEWICONH3_epoca": { //Paragraph style name
			definition: {
				"content": {
					"imageicon": {
						"id": "",
						"focuspoint": {
							"x": 0.5,
							"y": 0.5
						},
						"cropper": false
					},
					"titlewih3": [		//title with icon example
					],
				},
				"id": "",
				"identifier": "titlewithiconh3",
				"styles": {},
				"inlineStyles": {
				}
			}
		},
		"04_TITLEH3_epoca": { //Paragraph style name
			definition: {
				"content": {
					"imageicon": {
						"id": "",
						"focuspoint": {
							"x": 0.5,
							"y": 0.5
						},
						"cropper": false
					},
					"titlewih3": [		//title with icon example
					],
				},
				"id": "",
				"identifier": "titlewithiconh3",
				"styles": {},
				"inlineStyles": {
				}
			}
		},
		"03_TITLEWICONH3_cap_titulo_abre_LM": { //Paragraph style name
			definition: {
				"content": {
					"imageicon": {
						"id": "",
						"focuspoint": {
							"x": 0.5,
							"y": 0.5
						},
						"cropper": false
					},
					"titlewih3": [		//title with icon example
					],
				},
				"id": "",
				"identifier": "titlewithiconh3",
				"styles": {},
				"inlineStyles": {
				}
			}
		},
	},

	//Place components in a container based on their paragraph style
	containers: {
		"": { //Paragraph style
			definition: { // Container definition 
				"content": {},
				"id": "",
				"identifier": "bulleted-list", //bulleted-list, lowerletters-list, upperletters-list, upperroman-list, numbered-list
				"styles": {},
				"containers": {
					"main": []
				}
			},
			containerName: "main", //Container field in the container definition
		},
		"": { //Paragraph style
			definition: { // Container definition 
				"content": {},
				"id": "",
				"identifier": "bulleted-list", //bulleted-list, lowerletters-list, upperletters-list, upperroman-list, numbered-list
				"styles": {},
				"containers": {
					"main": []
				}
			},
			containerName: "main", //Container field in the container definition
		},
		"": { //Paragraph style
			definition: { // Container definition 
				"content": {},
				"id": "",
				"identifier": "bulleted-list",
				"styles": {},
				"containers": {
					"main": []
				}
			},
			containerName: "main", //Container field in the container definition
		},
		"": { //Paragraph style
			definition: { // Container definition 
				"content": {},
				"id": "",
				"identifier": "bulleted-list",
				"styles": {},
				"containers": {
					"main": []
				}
			},
			containerName: "main", //Container field in the container definition
		},
		"": { //Paragraph style
			definition: { // Container definition 
				"content": {},
				"id": "",
				"identifier": "bulleted-list",
				"styles": {},
				"containers": {
					"main": []
				}
			},
			containerName: "main", //Container field in the container definition
		},
		"": { //Paragraph style
			definition: { // Container definition 
				"content": {},
				"id": "",
				"identifier": "lowerletters-list",
				"styles": {},
				"containers": {
					"main": []
				}
			},
			containerName: "main", //Container field in the container definition
		},
		"": { //Paragraph style
			definition: { // Container definition 
				"content": {},
				"id": "",
				"identifier": "lowerletters-list",
				"styles": {},
				"containers": {
					"main": []
				}
			},
			containerName: "main", //Container field in the container definition
		},
		"": { //Paragraph style
			definition: { // Container definition 
				"content": {},
				"id": "",
				"identifier": "bulleted-list",
				"styles": {},
				"containers": {
					"main": []
				}
			},
			containerName: "main", //Container field in the container definition
		},
		"": { //Paragraph style
			definition: { // Container definition 
				"content": {},
				"id": "",
				"identifier": "bulleted-list",
				"styles": {},
				"containers": {
					"main": []
				}
			},
			containerName: "main", //Container field in the container definition
		},
		"": { //Paragraph style
			definition: { // Container definition 
				"content": {},
				"id": "",
				"identifier": "bulleted-list",
				"styles": {},
				"containers": {
					"main": []
				}
			},
			containerName: "main", //Container field in the container definition
		},
		"": { //Paragraph style
			definition: { // Container definition 
				"content": {},
				"id": "",
				"identifier": "bulleted-list",
				"styles": {},
				"containers": {
					"main": []
				}
			},
			containerName: "main", //Container field in the container definition
		},
		"": { //Paragraph style
			definition: { // Container definition 
				"content": {},
				"id": "",
				"identifier": "lowerletters-list",
				"styles": {},
				"containers": {
					"main": []
				}
			},
			containerName: "main", //Container field in the container definition
		},
		"": { //Paragraph style
			definition: { // Container definition 
				"content": {},
				"id": "",
				"identifier": "lowerletters-list",
				"styles": {},
				"containers": {
					"main": []
				}
			},
			containerName: "main", //Container field in the container definition
		},
		"": { //Paragraph style
			definition: { // Container definition 
				"content": {},
				"id": "",
				"identifier": "lowerletters-list",
				"styles": {},
				"containers": {
					"main": []
				}
			},
			containerName: "main", //Container field in the container definition
		},
		"": { //Paragraph style
			definition: { // Container definition 
				"content": {},
				"id": "",
				"identifier": "lowerletters-list",
				"styles": {},
				"containers": {
					"main": []
				}
			},
			containerName: "main", //Container field in the container definition
		},
		"": { //Paragraph style
			definition: { // Container definition 
				"content": {},
				"id": "",
				"identifier": "lowerletters-list",
				"styles": {},
				"containers": {
					"main": []
				}
			},
			containerName: "main", //Container field in the container definition
		},
		"": { //Paragraph style
			definition: { // Container definition 
				"content": {},
				"id": "",
				"identifier": "lowerletters-list",
				"styles": {},
				"containers": {
					"main": []
				}
			},
			containerName: "main", //Container field in the container definition
		},
		"": { //Paragraph style
			definition: { // Container definition 
				"content": {},
				"id": "",
				"identifier": "lowerletters-list",
				"styles": {},
				"containers": {
					"main": []
				}
			},
			containerName: "main", //Container field in the container definition
		},
		"": { //Paragraph style
			definition: { // Container definition 
				"content": {},
				"id": "",
				"identifier": "bulleted-list",
				"styles": {},
				"containers": {
					"main": []
				}
			},
			containerName: "main", //Container field in the container definition
		},
		"": { //Paragraph style
			definition: { // Container definition 
				"content": {},
				"id": "",
				"identifier": "lowerletters-list",
				"styles": {},
				"containers": {
					"main": []
				}
			},
			containerName: "main", //Container field in the container definition
		},
		"": { //Paragraph style
			definition: { // Container definition 
				"content": {},
				"id": "",
				"identifier": "lowerletters-list",
				"styles": {},
				"containers": {
					"main": []
				}
			},
			containerName: "main", //Container field in the container definition
		},
		"": { //Paragraph style
			definition: { // Container definition 
				"content": {},
				"id": "",
				"identifier": "bulleted-list",
				"styles": {},
				"containers": {
					"main": []
				}
			},
			containerName: "main", //Container field in the container definition
		},
		"": { //Paragraph style
			definition: { // Container definition 
				"content": {},
				"id": "",
				"identifier": "lowerletters-list",
				"styles": {},
				"containers": {
					"main": []
				}
			},
			containerName: "main", //Container field in the container definition
		},
		"": { //Paragraph style
			definition: { // Container definition 
				"content": {},
				"id": "",
				"identifier": "bulleted-list",
				"styles": {},
				"containers": {
					"main": []
				}
			},
			containerName: "main", //Container field in the container definition
		},
		"": { //Paragraph style
			definition: { // Container definition 
				"content": {},
				"id": "",
				"identifier": "bulleted-list",
				"styles": {},
				"containers": {
					"main": []
				}
			},
			containerName: "main", //Container field in the container definition
		},
		"": { //Paragraph style
			definition: { // Container definition 
				"content": {},
				"id": "",
				"identifier": "bulleted-list",
				"styles": {},
				"containers": {
					"main": []
				}
			},
			containerName: "main", //Container field in the container definition
		},
		"": { //Paragraph style
			definition: { // Container definition 
				"content": {},
				"id": "",
				"identifier": "lowerletters-list",
				"styles": {},
				"containers": {
					"main": []
				}
			},
			containerName: "main", //Container field in the container definition
		},
		"": { //Paragraph style
			definition: { // Container definition 
				"content": {},
				"id": "",
				"identifier": "numbered-list",
				"styles": {},
				"containers": {
					"main": []
				}
			},
			containerName: "main", //Container field in the container definition
		}
	},

	// The 'styles' section provides the export details about what styling should result in bold and italic
	// overrides in the output.
	styles: {
		// Mark character styles as bold or italic. Matching is on full character style name. Most commonly used.
		character: {
			"Bold": { bold: true },
			"Bold Italic": { bold: true, italic: true },
			"Italic": { italic: true },
			"Subscript": { subscript: true },
			"Superscript": { superscript: true },
			"Underline": { underline: true },
			"Strikethrough": { strikethrough: true },
			"Uppercase": { uppercase: true },
			"Lowercase": { lowercase: true },
			"Titlecase": { titlecase: true },
			"00_acessibilidade_abreviatura": { characterstyle: "cs-00_acessibilidade_abreviatura" },
			"00_acessibilidade_fonetica": { characterstyle: "cs-00_acessibilidade_fonetica" },
			"00_acessibilidade_medida": { characterstyle: "cs-00_acessibilidade_medida" },
			"00_acessibilidade_monetario": { characterstyle: "cs-00_acessibilidade_monetario" },
			"00_acessibilidade_pagina": { characterstyle: "cs-00_acessibilidade_pagina" },
			"00_acessibilidade_romano": { characterstyle: "cs-00_acessibilidade_romano" },
			"00_acessibilidade_siglas": { characterstyle: "cs-00_acessibilidade_siglas" },
			"00_acessibilidade_simbolos": { characterstyle: "cs-00_acessibilidade_simbolos" },
			"00_bullet_exercicio": { characterstyle: "cs-00_bullet_exercicio" },
			"00_conexoes_marcador_negativo": { characterstyle: "cs-00_conexoes_marcador_negativo" },
			"00_destaque_exerc_abc": { characterstyle: "cs-00_destaque_exerc_abc" },
			"00_destaque_exerc_numero": { characterstyle: "cs-00_destaque_exerc_numero" },
			"00_destaque_exerc_secao_cor_1": { characterstyle: "cs-00_destaque_exerc_secao_cor_1" },
			"00_destaque_exerc_secao_cor_2": { characterstyle: "cs-00_destaque_exerc_secao_cor_2" },
			"00_glifo": { characterstyle: "cs-00_glifo" },
			"00_highlight_sumario": { characterstyle: "cs-00_highlight_sumario" },
			"00_indent_level_1_abre_unidade_numero": { characterstyle: "cs-00_indent_level_1_abre_unidade_numero" },
			"00_indent_level_1_bold_texto_geral": { characterstyle: "cs-00_indent_level_1_bold_texto_geral" },
			"00_indent_level_1_bold_texto_terceiro": { characterstyle: "cs-00_indent_level_1_bold_texto_terceiro" },
			"00_indent_level_1_bullet_exercicio": { characterstyle: "cs-00_indent_level_1_bullet_exercicio" },
			"00_indent_level_1_bullet_resolucao": { characterstyle: "cs-00_indent_level_1_bullet_resolucao" },
			"00_indent_level_1_bullet_tabela_texto": { characterstyle: "cs-00_indent_level_1_bullet_tabela_texto" },
			"00_indent_level_1_bullet_texto_geral": { characterstyle: "cs-00_indent_level_1_bullet_texto_geral" },
			"00_indent_level_1_exerc_abc": { characterstyle: "cs-00_indent_level_1_exerc_abc" },
			"00_indent_level_1_exerc_boxe_lateral": { characterstyle: "cs-00_indent_level_1_exerc_boxe_lateral" },
			"00_indent_level_1_exerc_numero": { characterstyle: "cs-00_indent_level_1_exerc_numero" },
			"00_indent_level_1_exerc_secao_cor_1": { characterstyle: "cs-00_indent_level_1_exerc_secao_cor_1" },
			"00_indent_level_1_exerc_secao_cor_2": { characterstyle: "cs-00_indent_level_1_exerc_secao_cor_2" },
			"00_indent_level_1_exerc_secao_cor_3": { characterstyle: "cs-00_indent_level_1_exerc_secao_cor_3" },
			"00_indent_level_2_bold_texto_geral": { characterstyle: "cs-00_indent_level_2_bold_texto_geral" },
			"00_indent_level_2_bullet_exercicio": { characterstyle: "cs-00_indent_level_2_bullet_exercicio" },
			"00_indent_level_2_bullet_tabela_texto": { characterstyle: "cs-00_indent_level_2_bullet_tabela_texto" },
			"00_indent_level_2_bullet_texto_geral": { characterstyle: "cs-00_indent_level_2_bullet_texto_geral" },
			"00_indent_level_2_exerc_abc": { characterstyle: "cs-00_indent_level_2_exerc_abc" },
			"00_indent_level_2_exerc_abc_cx_alta": { characterstyle: "cs-00_indent_level_2_exerc_abc_cx_alta" },
			"00_indent_level_2_exerc_boxe_lateral": { characterstyle: "cs-00_indent_level_2_exerc_boxe_lateral" },
			"00_indent_level_2_exerc_numero": { characterstyle: "cs-00_indent_level_2_exerc_numero" },
			"00_indent_level_3_bullet_exercicio": { characterstyle: "cs-00_indent_level_3_bullet_exercicio" },
			"00_indent_level_3_bullet_tabela_texto": { characterstyle: "cs-00_indent_level_3_bullet_tabela_texto" },
			"00_indent_level_3_bullet_texto_geral": { characterstyle: "cs-00_indent_level_3_bullet_texto_geral" },
			"00_indent_level_3_exerc_abc": { characterstyle: "cs-00_indent_level_3_exerc_abc" },
			"00_indent_level_3_exerc_numero": { characterstyle: "cs-00_indent_level_3_exerc_numero" },
			"00_lang_espanhol": { characterstyle: "cs-00_lang_espanhol" },
			"00_lang_espanhol_glossario": { characterstyle: "cs-00_lang_espanhol_glossario" },
			"00_lang_espanhol_italico": { characterstyle: "cs-00_lang_espanhol_italico" },
			"00_lang_frances": { characterstyle: "cs-00_lang_frances" },
			"00_lang_frances_italico": { characterstyle: "cs-00_lang_frances_italico" },
			"00_lang_ingles": { characterstyle: "cs-00_lang_ingles" },
			"00_lang_ingles_glossario": { characterstyle: "cs-00_lang_ingles_glossario" },
			"00_lang_ingles_italico": { characterstyle: "cs-00_lang_ingles_italico" },
			"00_lang_latim": { characterstyle: "cs-00_lang_latim" },
			"00_lang_latim_italico": { characterstyle: "cs-00_lang_latim_italico" },
			"00_lang_russo": { characterstyle: "cs-00_lang_russo" },
			"00_lang_russo_italico": { characterstyle: "cs-00_lang_russo_italico" },
			"00_marcador_capitulo": { characterstyle: "cs-03_capitulo_numero" },
			"00_ordinal": { characterstyle: "cs-00_ordinal" },
			"00_ordinal_bold": { characterstyle: "cs-00_ordinal_bold" },
			"00_ordinal_bold_italico": { characterstyle: "cs-00_ordinal_bold_italico" },
			"00_ordinal_italico": { characterstyle: "cs-00_ordinal_italico" },
			"00_ponto_invisivel": { characterstyle: "cs-00_ponto_invisivel" },
			"00_sobrescrito": { characterstyle: "cs-00_sobrescrito" },
			"00_sobrescrito_bold": { characterstyle: "cs-00_sobrescrito_bold" },
			"00_sobrescrito_bold_italico": { characterstyle: "cs-00_sobrescrito_bold_italico" },
			"00_sobrescrito_italico": { characterstyle: "cs-00_sobrescrito_italico" },
			"00_subscrito": { characterstyle: "cs-00_subscrito" },
			"00_subscrito_bold": { characterstyle: "cs-00_subscrito_bold" },
			"00_subscrito_bold_italico": { characterstyle: "cs-00_subscrito_bold_italico" },
			"00_subscrito_italico": { characterstyle: "cs-00_subscrito_italico" },
			"00_unidade_marcador": { characterstyle: "cs-03_unidade_numero" },
			"00-acessibilidade-abreviatura-bold": { characterstyle: "cs-00-acessibilidade-abreviatura-bold" },
			"00-acessibilidade-abreviatura-bold-italic": { characterstyle: "cs-00-acessibilidade-abreviatura-bold-italic" },
			"00-acessibilidade-abreviatura-italic": { characterstyle: "cs-00-acessibilidade-abreviatura-italic" },
			"00-acessibilidade-fonetica": { characterstyle: "cs-00-acessibilidade-fonetica" },
			"00-acessibilidade-fonetica-bold": { characterstyle: "cs-00-acessibilidade-fonetica-bold" },
			"00-acessibilidade-fonetica-bold-italic": { characterstyle: "cs-00-acessibilidade-fonetica-bold-italic" },
			"00-acessibilidade-fonetica-italic": { characterstyle: "cs-00-acessibilidade-fonetica-italic" },
			"00-acessibilidade-monetario-bold": { characterstyle: "cs-00-acessibilidade-monetario-bold" },
			"00-acessibilidade-monetario-bold-italic": { characterstyle: "cs-00-acessibilidade-monetario-bold-italic" },
			"00-acessibilidade-monetario-italic": { characterstyle: "cs-00-acessibilidade-monetario-italic" },
			"00-acessibilidade-pagina": { characterstyle: "cs-00-acessibilidade-pagina" },
			"00-acessibilidade-romano": { characterstyle: "cs-00-acessibilidade-romano" },
			"00-acessibilidade-romano-bold": { characterstyle: "cs-00-acessibilidade-romano-bold" },
			"00-acessibilidade-romano-bold-italic": { characterstyle: "cs-00-acessibilidade-romano-bold-italic" },
			"00-acessibilidade-romano-italic": { characterstyle: "cs-00-acessibilidade-romano-italic" },
			"00-acessibilidade-siglas": { characterstyle: "cs-00-acessibilidade-siglas" },
			"00-acessibilidade-siglas-bold": { characterstyle: "cs-00-acessibilidade-siglas-bold" },
			"00-acessibilidade-siglas-bold-italic": { characterstyle: "cs-00-acessibilidade-siglas-bold-italic" },
			"00-acessibilidade-siglas-italic": { characterstyle: "cs-00-acessibilidade-siglas-italic" },
			"00-lang-espanhol-bold": { characterstyle: "cs-00-lang-espanhol-bold" },
			"00-lang-espanhol-bold-italico": { characterstyle: "cs-00-lang-espanhol-bold-italico" },
			"00-lang-espanhol-italico": { characterstyle: "cs-00-lang-espanhol-italico" },
			"00-lang-frances-bold": { characterstyle: "cs-00-lang-frances-bold" },
			"00-lang-frances-bold-italico": { characterstyle: "cs-00-lang-frances-bold-italico" },
			"00-lang-frances-italico": { characterstyle: "cs-00-lang-frances-italico" },
			"00-lang-ingles": { characterstyle: "cs-00-lang-ingles" },
			"00-lang-ingles-bold": { characterstyle: "cs-00-lang-ingles-bold" },
			"00-lang-ingles-bold-italico": { characterstyle: "cs-00-lang-ingles-bold-italico" },
			"00-lang-ingles-italico": { characterstyle: "cs-00-lang-ingles-italico" },
			"00-lang-latim-bold": { characterstyle: "cs-00-lang-latim-bold" },
			"00-lang-latim-bold-italico": { characterstyle: "cs-00-lang-latim-bold-italico" },
			"00-lang-latim-italico": { characterstyle: "cs-00-lang-latim-italico" },
			"00-lang-russo-bold": { characterstyle: "cs-00-lang-russo-bold" },
			"00-lang-russo-bold-italico": { characterstyle: "cs-00-lang-russo-bold-italico" },
			"00-lang-russo-italico": { characterstyle: "cs-00-lang-russo-italico" },
			"01_italico_texto_geral": { characterstyle: "cs-01_italico_texto_geral" },
			"02_bold_texto_geral": { characterstyle: "cs-02_bold_texto_geral" },
			"03_bold_italico_texto_geral": { characterstyle: "cs-03_bold_italico_texto_geral" },
			"03_capitulo_numero": { characterstyle: "cs-03_capitulo_numero" },
			"03_unidade_numero": { characterstyle: "cs-03_unidade_numero" },
			"04_italico_texto_terceiro": { characterstyle: "cs-04_italico_texto_terceiro" },
			"05_bold_texto_terceiro": { characterstyle: "cs-05_bold_texto_terceiro" },
			"06_bold_italico_texto_terceiro": { characterstyle: "cs-06_bold_italico_texto_terceiro" },
			"07_destaque_glossario": { characterstyle: "cs-07_destaque_glossario" },
			"13_subscrito": { characterstyle: "cs-13_subscrito" },
			"14_subscrito_italico": { characterstyle: "cs-14_subscrito_italico" },
			"15_sobrescrito": { characterstyle: "cs-15_sobrescrito" },
			"36_italico_genero_jornal": { characterstyle: "cs-36_italico_genero_jornal" },
			"37_bold_genero_jornal": { characterstyle: "cs-37_bold_genero_jornal" },
			"38_bold_italico_genero_jornal": { characterstyle: "cs-38_bold_italico_genero_jornal" },
			"39_resposta": { characterstyle: "cs-39_resposta" },
			"39_resposta_bold": { characterstyle: "cs-39_resposta_bold" },
			"39_resposta_bold_italico": { characterstyle: "cs-39_resposta_bold_italico" },
			"39_resposta_light": { characterstyle: "cs-39_resposta_light" },
			"40_bold_genero_jornal": { characterstyle: "cs-40_bold_genero_jornal" },
			"40_destaque_glossario_terceiro": { characterstyle: "cs-40_destaque_glossario_terceiro" },
			"41_destaque_glossario_jornal": { characterstyle: "cs-41_destaque_glossario_jornal" },
			"42_bold_resolucao": { characterstyle: "cs-42_bold_resolucao" },
			"50_destaque_exemplo_Obs": { characterstyle: "cs-50_destaque_exemplo_Obs" },
			"52_sumario_destaque_secao_lp": { characterstyle: "cs-52_sumario_destaque_secao_lp" },
			"57_subscrito_bold": { characterstyle: "cs-57_subscrito_bold" },
			"58_subscrito_bold_italic": { characterstyle: "cs-58_subscrito_bold_italic" },
			"59_italic_titulo": { characterstyle: "cs-59_italic_titulo" },
			"60_sublinhado": { characterstyle: "cs-60_sublinhado" },
			"61_sublinhado_resposta": { characterstyle: "cs-61_sublinhado_resposta" },
			"62_sumario_destaque_texto_lp": { characterstyle: "cs-62_sumario_destaque_texto_lp" },
			"65_voce_em_acao_marcador_negativo": { characterstyle: "cs-65_voce_em_acao_marcador_negativo" },
			"00-lang-italiano": { characterstyle: "cs-00-lang-italiano" },
			"00-lang-italiano-italico": { characterstyle: "cs-00-lang-italiano-italico" },
			"00-lang-italiano-bold": { characterstyle: "cs-00-lang-italiano-bold" },
			"00-lang-italiano-bold-italico": { characterstyle: "cs-00-lang-italiano-bold-italico" },
			"00-lang-alemao": { characterstyle: "cs-00-lang-alemao" },
			"00-lang-alemao-italico": { characterstyle: "cs-00-lang-alemao-italico" },
			"00-lang-alemao-bold": { characterstyle: "cs-00-lang-alemao-bold" },
			"00-lang-alemao-bold-italico": { characterstyle: "cs-00-lang-alemao-bold-italico" },
			"00-lang-arabe": { characterstyle: "cs-00-lang-arabe" },
			"00-lang-arabe-italico": { characterstyle: "cs-00-lang-arabe-italico" },
			"00-lang-arabe-bold": { characterstyle: "cs-00-lang-arabe-bold" },
			"00-lang-arabe-bold-italico": { characterstyle: "cs-00-lang-arabe-bold-italico" },
			"00_bullet_box_nao_lista": { characterstyle: "cs-00_bullet_box_nao_lista" },
			"00_numerado_nao_lista": { characterstyle: "cs-00_numerado_nao_lista" },
			"18_sumario_pontilhado": { characterstyle: "cs-18_sumario_pontilhado" },
			"00_sumario_destaque_OED": { characterstyle: "cs-00_sumario_destaque_OED" },
			"00_sumario_destaque_OED_italico": { characterstyle: "cs-00_sumario_destaque_OED_italico" },
			"18_sumario_destaque_pontilhado": { characterstyle: "cs-18_sumario_destaque_pontilhado" },
			//add 6 new character styles for Roman List
			"00_indent_level_1_lower_roman": { characterstyle: "cs-00_indent_level_1_lower_roman" },
			"00_indent_level_2_lower_roman": { characterstyle: "cs-00_indent_level_2_lower_roman" },
			"00_indent_level_3_lower_roman": { characterstyle: "cs-00_indent_level_3_lower_roman" },
			"00_indent_level_1_upper_roman": { characterstyle: "cs-00_indent_level_1_upper_roman" },
			"00_indent_level_2_upper_roman": { characterstyle: "cs-00_indent_level_2_upper_roman" },
			"00_indent_level_3_upper_roman": { characterstyle: "cs-00_indent_level_3_upper_roman" },
			"2_extrabold_texto_geral": { characterstyle: "cs-2_extrabold_texto_geral" },
			//new character styles for Livro
			"00_indent_level_1_num_black_txt_geral_LM": { characterstyle: "cs-00_indent_level_1_num_black_txt_geral_LM" },
			"00_indent_level_1_bold_texto_geral_LM": { characterstyle: "cs-00_indent_level_1_bold_texto_geral_LM" },
			"00_indent_level_1_bold_texto_terceiro_LM": { characterstyle: "cs-00_indent_level_1_bold_texto_terceiro_LM" },
			"00_indent_level_1_bullet_box_objetivos_LM": { characterstyle: "cs-00_indent_level_1_bullet_box_objetivos_LM" },
			"00_indent_level_1_bullet_exerc_LM": { characterstyle: "cs-00_indent_level_1_bullet_exerc_LM" },
			"00_indent_level_1_bullet_tabela_texto_LM": { characterstyle: "cs-00_indent_level_1_bullet_tabela_texto_LM" },
			"00_indent_level_1_bullet_texto_geral_LM": { characterstyle: "cs-00_indent_level_1_bullet_texto_geral_LM" },
			"00_indent_level_1_exerc_secao_cor_1_LM": { characterstyle: "cs-00_indent_level_1_exerc_secao_cor_1_LM" },
			"00_indent_level_2_bold_texto_geral_LM": { characterstyle: "cs-00_indent_level_2_bold_texto_geral_LM" },
			"00_indent_level_2_bullet_texto_geral_LM": { characterstyle: "cs-00_indent_level_2_bullet_texto_geral_LM" },
			"00_indent_level_2_exerc_abc_LM": { characterstyle: "cs-00_indent_level_2_exerc_abc_LM" },
			"00_indent_level_2_resposta_abc_LM": { characterstyle: "cs-00_indent_level_2_resposta_abc_LM" },
			"00_indent_level_3_bullet_exercicio_LM": { characterstyle: "cs-00_indent_level_3_bullet_exercicio_LM" },
			"00_bullet_box_objetivos_LM": { characterstyle: "cs-00_bullet_box_objetivos_LM" },
			"00_bullet_box_para_ampliar_LM": { characterstyle: "cs-00_bullet_box_para_ampliar_LM" },
			"00_capitulo_marcador_LM": { characterstyle: "cs-00_capitulo_marcador_LM" },
			"00_capitulo_numero_LM": { characterstyle: "cs-00_capitulo_marcador_LM" },
			"00_destaque_exerc_abc_LM": { characterstyle: "cs-00_destaque_exerc_abc_LM" },
			"00_destaque_exerc_secao_cor_2_LM": { characterstyle: "cs-00_destaque_exerc_secao_cor_2_LM" },
			"00_num_black_txt_geral_LM": { characterstyle: "cs-00_num_black_txt_geral_LM" },
			"00_resposta_abc_LM": { characterstyle: "cs-00_resposta_abc_LM" },
			"00_resposta_numero_LM": { characterstyle: "cs-00_resposta_numero_LM" },
			"00_unidade_marcador_LM": { characterstyle: "cs-00_unidade_marcador_LM" },
			"00_unidade_numero_LM": { characterstyle: "cs-00_unidade_marcador_LM" },
			"01_italico_texto_geral_LM": { characterstyle: "cs-01_italico_texto_geral_LM" },
			"02_bold_texto_geral_LM": { characterstyle: "cs-02_bold_texto_geral_LM" },
			"03_bold_italico_texto_geral_LM": { characterstyle: "cs-03_bold_italico_texto_geral_LM" },
			"04_italico_texto_terceiro_LM": { characterstyle: "cs-04_italico_texto_terceiro_LM" },
			"05_bold_texto_terceiro_LM": { characterstyle: "cs-05_bold_texto_terceiro_LM" },
			"06_bold_italico_texto_terceiro_LM": { characterstyle: "cs-06_bold_italico_texto_terceiro_LM" },
			"11_mat_stix_LM": { characterstyle: "cs-11_mat_stix_LM" },
			"12_caracter_cursivo_LM": { characterstyle: "cs-12_caracter_cursivo_LM" },
			"18_bullet_numerado_LM": { characterstyle: "cs-18_bullet_numerado_LM" },
			"18_sumario_pontilhado_LM": { characterstyle: "cs-18_sumario_pontilhado_LM" },
			"20_bullet_tabela_LM": { characterstyle: "cs-20_bullet_tabela_LM" },
			"22_nota_de_rodape_LM": { characterstyle: "cs-22_nota_de_rodape_LM" },
			"23_competencia_geral_cor_LM": { characterstyle: "cs-23_competencia_geral_cor_LM" },
			"23_texto_bullet_geral_LM": { characterstyle: "cs-23_texto_bullet_geral_LM" },
			"24_competencia_especifica_LM": { characterstyle: "cs-24_competencia_especifica_LM" },
			"25_habilidades_LM": { characterstyle: "cs-25_habilidades_LM" },
			"35_infra_regular_LM": { characterstyle: "cs-35_infra_regular_LM" },
			"36_italico_genero_jornal_LM": { characterstyle: "cs-36_italico_genero_jornal_LM" },
			"37_bold_genero_jornal_LM": { characterstyle: "cs-37_bold_genero_jornal_LM" },
			"37_competencia_geral_destaque_LM": { characterstyle: "cs-37_competencia_geral_destaque_LM" },
			"38_bold_italico_genero_jornal_LM": { characterstyle: "cs-38_bold_italico_genero_jornal_LM" },
			"38_habilidade_destaque_LM": { characterstyle: "cs-38_habilidade_destaque_LM" },
			"39_competencia_especifica_destaque_LM": { characterstyle: "cs-39_competencia_especifica_destaque_LM" },
			"40_bold_genero_jornal_LM": { characterstyle: "cs-40_bold_genero_jornal_LM" },
			"40_destaque_tct_LM": { characterstyle: "cs-40_destaque_tct_LM" },
			"59_italic_titulo_LM": { characterstyle: "cs-59_italic_titulo_LM" },
			"60_sublinhado_LM": { characterstyle: "cs-60_sublinhado_LM" },
			"66_mat_stix_sobrescrito_LM": { characterstyle: "cs-66_mat_stix_sobrescrito_LM" },
			"68_mat_stix_subscrito_LM": { characterstyle: "cs-68_mat_stix_subscrito_LM" },
			"71_titulo_unidade_sum_LM": { characterstyle: "cs-71_titulo_unidade_sum_LM" },
			"00_indent_level_2_upper-roman": { characterstyle: "cs-00_indent_level_2_upper-roman" },
			"00-sumario-id": { characterstyle: "cs-00-sumario-id" },
		},
	
		// Mark use of certain font styles as bold or italic in the output. Be aware that this will match for all
		// font families used with the specified font style
		font: {
		},
		// Mark entire paragraphs as bold or italic. Not commonly used.
		paragraph: {
		}
	},

	// The 'output' section defines how bold and italic overrides will be output to Ptd. In addition it offers
	// the opportunity to remove and/or replace characters in the output. Html special characters will automatically be
	// escaped in the output.
	output: {
		htmlTags: {
			bold: {
				tag: "b"
			},
			italic: {
				tag: "i"
			},
			superscript: {
				tag: "sup"
			},
			subscript: {
				tag: "sub"
			},
			uppercase: {
				tag: "up"
			}
		},
		htmlEncode: [
		]
	},

	// Using the 'charConvert' section certain characters can be replaced by other characters 
	charConvert: [
		//Thin space to space
		['\u2009', ' ']
	],

	// The directory used as base directory for logging
	exportDirectory: '~/Desktop/ptd-indesign-logs',

	// Logging settings. Log files will be put in the document's output directory.
	logging: {
		level: 'INFO',
		wipe: true
	},

	//Content Station URL relative to index.php, default assumes that Content Station is installed in the same folder as index.php
	contentStationURL: "../app/",

	//If set to true, each set of grouped frames on a layout is added as a Container component.
	//Each frame of the group will be a separate component in the Container.
	//Note: The default Container component is used; custom Container components are not supported.
	createContainerForGroup: true,

	//If set to true, images will be scaled by percentage in conversion, respecting the scaling (percentage) of frame width and print page width
	//Else set image width to 100% in conversion, so that the image is sized by CSS styling or scaled to fit full width of digital article
	scalePTDImages: true
};