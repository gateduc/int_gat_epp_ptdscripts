﻿/**
 * @description Ptd prepare service - prepares InDesign layout by converting tables and groups to images
 *
 * @copyright WoodWing Software B.V. All rights reserved.
 */

if (forceInit || typeof $.global.PtdPrepareService === 'undefined') {

    #include '_.jsx'

    #include 'err.jsx'

    #include 'config-service.jsx'

    #include 'component-lookup.jsx'

    #include 'json2.js'

    #include "logging.jsx"

    var PtdPrepareService = function(Err, ConfigService, ComponentLookup, JSON, _) {
        'use strict';

        var imageIndex = 0;
        var mathmlIndex = 0;

        /**
         * Convert text tables to images
         * @param doc
         * @private
         */
        function _convertTables(doc) {
            var stories = doc.stories;
            var mdDoc = doc.entMetaData;
            var mdWf = doc.entWorkflow;
            var saveDossiers = [];
            var wwLayer;
            var pageItemsforGroups = [];

            var overwrite = overwriteExisting("Tabelas", doc);

            // loop through all stories
            for (var x = stories.length - 1; x >= 0; x--) {
                var story = stories[x];
                exportTableHTML(doc, mdDoc, mdWf, story, pageItemsforGroups);
                exportTables(doc, mdDoc, mdWf, story, overwrite);
            }

            //create single CSS tables styles for all tables.
            if (pageItemsforGroups.length > 1) {
                var group = doc.groups.add(pageItemsforGroups);
                app.select(group);
                var groupCSSPath = doc.filePath + "/GROUP_CSS-web-resources/css/idGeneratedStyles.css";
                group.exportFile(ExportFormat.HTML, new File(doc.filePath + "/GROUP_CSS" + ".html"), false);
                group.remove();
                var assetId = saveToAsset([groupCSSPath], "/PTD Tables/" + mdDoc.get("Core_Publication") + "/" + mdDoc.get("Core_Issue") + "/" + mdDoc.get("Core_Name"));
            } else if (pageItemsforGroups.length > 0) {
                pageItemsforGroups[0].exportFile(ExportFormat.HTML, new File(doc.filePath + "/GROUP_CSS" + ".html"), false);
                var groupCSSPath = doc.filePath + "/GROUP_CSS-web-resources/css/idGeneratedStyles.css";
                var assetId = saveToAsset([groupCSSPath], "/PTD Tables/" + mdDoc.get("Core_Publication") + "/" + mdDoc.get("Core_Issue") + "/" + mdDoc.get("Core_Name"));
                pageItemsforGroups[0].remove();
            } else {}
            var folder = Folder(doc.filePath + "/GROUP_CSS-web-resources");
            if (folder.exists) {
                folder.removeRecursively();
            }
            var groupHTML = File(doc.filePath + "/GROUP_CSS" + ".html")
            if (groupHTML.exists) {
                groupHTML.remove();
            }
        }

        function exportTableHTML(doc, mdDoc, mdWf, story, pageItemsforGroups) {
            var storyTables = story.tables;
            var wwLayer;
            var docPrefs = doc.htmlExportPreferences;

            docPrefs.exportSelection = true;
            docPrefs.viewDocumentAfterExport = false;

            // loop through story's tables
            if (storyTables.length > 0) {
                for (var y = storyTables.length - 1; y >= 0; y--) {
                    var firstPage = doc.pages[0];
                    var currentPage = storyTables[y].parent.parentPage;

                    app.select(storyTables[y]);
                    app.copy();

                    // add a new text frame to paste table into
                    var copiedTableFrame = currentPage.textFrames.add();

                    // adjust leading and pointsize to minimize spacing around table
                    copiedTableFrame.parentStory.leading = 0;
                    copiedTableFrame.parentStory.pointSize = 0.1;

                    // select and paste clipboard into the text frame
                    app.select(copiedTableFrame.insertionPoints[0]);
                    app.paste();

                    // refit text frame to table
                    copiedTableFrame.fit(FitOptions.FRAME_TO_CONTENT);

                    var newTable = copiedTableFrame.tables[0];
                    // var tableWidth = newTable.width;
                    // var tableHeight = newTable.height;
                    // //var tableRatio = tableWidth / tableHeight;
                    // //var pageWidth = currentPage.bounds[3] - currentPage.bounds[1];
                    // var percent = 1.5;
                    // // Scale the width of each cell in each column
                    // for (var k = 0; k < newTable.columns.length; k++) {
                    //     var currentColumn = newTable.columns[k];
                    //     currentColumn.width = currentColumn.width * percent;
                    // }
                    // //scale the height
                    // newTable.height = newTable.height * percent;

                    for (var k = 0; k < newTable.cells.length; k++) {
                        var cell = newTable.cells[k];
                        var cellType = cell.cellType.toString();

                        //if cell has mathml, do mathml replacement for this cell
                        if (cell.mtAllMathZones && cell.mtAllMathZones.length > 0) {
                            for (var l = 0; l < cell.mtAllMathZones.length; l++) {
                                var mathZone = cell.mtAllMathZones[l];
                                var insertionPoint = cell.insertionPoints.itemByRange(mathZone.index, mathZone.index);
                                var mathML = '';
                                mathML = mathZone.insertionPoints.item(0).mtExportMathZoneAsMathML();
                                mathML = mathML.substring(mathML.indexOf("<m")); //Remove XML header
                                if (mathML.indexOf("display=") == -1) {
                                    mathML = mathML.substring(0, 6) + 'display="block" ' + mathML.substring(6);
                                }
                                var mathMLTempID = "mathml_" + mathmlIndex;

                                exportMathMLinTable(doc, mdDoc, mdWf, mathZone, true, currentPage);
                                mathmlIndex++;

                                insertionPoint.contents = mathMLTempID;

                                var mathMLObject = {
                                    mathml: mathML
                                };
                                var StudioID = 0;
                                //upload mathml it assets for replacement later
                                uploadReplacementFile(doc, mdDoc, mathMLTempID, mathMLObject, "MathML");

                                mathZone.remove();
                            }
                        }

                        if (cellType == "GRAPHIC_TYPE_CELL") {
                            if (cell.allGraphics.length > 0) {
                                // Replace each image with text
                                for (var l = 0; l < cell.allGraphics.length; l++) {
                                    // convert the graphic cell
                                    cell.convertCellType(1701730388);
                                    var textFrames = cell.texts;
                                    for (var textIndex = 0; textIndex < textFrames.length; textIndex++) {
                                        var textFrame = textFrames[textIndex];
                                        //insert ptd image information
                                        textFrame.contents = "Image Placeholder HTML";
                                    }
                                }
                            }
                        } else if (cellType == "TEXT_TYPE_CELL") {
                            if (cell.allGraphics.length > 0) {
                                //replace inline section with image html
                                var inlineCharacter;
                                for (var l = 0; l < cell.characters.length; l++) {
                                    var character = cell.characters[l];
                                    // Check if the character is an inline image
                                    if (character.allGraphics.length > 0) {
                                        // Replace the inline image with text
                                        var inlineGraphic = character.allGraphics[0]; // Modify the index as needed
                                        inlineCharacter = character;

                                        //do inline graphic replacement
                                        var tableName = "tableImage_" + imageIndex;
                                        var frame_width = inlineGraphic.parent.visibleBounds[3] - inlineGraphic.parent.visibleBounds[1];
                                        var cell_width = cell.width;

                                        imageIndex++;
                                        var width = Math.floor((frame_width / cell_width * 100) * 100) / 100;
                                        if (width > 100) {
                                            width = 100;
                                        }
                                        var scImg = inlineGraphic.managedImage;
                                        if (scImg) {
                                            var metadata = scImg.entMetaData;
                                            var id = metadata.get('Core_ID');
                                        }

                                        var imageHTML = '<figure class="inlineptdimage ptdimage _fitting _caption-none" style="display: inline-block;width: ' + width + '%;"><img src="../resources/images/im_' + inlineGraphic.itemLink.name + '" alt=""><figcaption></figcaption></figure>';

                                        var tableObject = {
                                            imageHTML: imageHTML,
                                            id: id
                                        };
                                        //create file
                                        uploadReplacementFile(doc, mdDoc, tableName, tableObject, "Images");

                                        var textRef = cell.texts.item(0);
                                        var insertionPoint = textRef.insertionPoints.itemByRange(l, l);
                                        insertionPoint.contents = tableName;

                                        // Remove the inline graphic
                                        inlineGraphic.remove();
                                    }
                                }
                                //remove inline characters
                                inlineCharacter.remove()
                            } else {
                                //do nothing to text
                            }
                        }
                    }
                    
                    //move table to first page?
                    copiedTableFrame.move(firstPage);

                    pageItemsforGroups.push(copiedTableFrame);

                    var tableHTMLPath = doc.filePath + "/table_" + storyTables[y].id + ".html";
                    newTable.parent.exportFile(ExportFormat.HTML, new File(doc.filePath + "/table_" + storyTables[y].id + ".html"), false);
                    var assetId = saveToAsset([tableHTMLPath], "/PTD Tables/" + mdDoc.get("Core_Publication") + "/" + mdDoc.get("Core_Issue") + "/" + mdDoc.get("Core_Name"));

                    //delete leftover css
                    var folder = Folder(doc.filePath + "/table_" + storyTables[y].id + "-web-resources");
                    if (folder.exists) {
                        folder.removeRecursively();
                    }
                }
            }
            return imageIndex;
        }

        function uploadReplacementFile(doc, mdDoc, name, text, lastFolder) {
            var filePath = doc.filePath + "/" + name + ".json";
            var replacementFile = new File(filePath);
            replacementFile.open("w");
            replacementFile.writeln(JSON.stringify(text));
            replacementFile.close();

            // Add image to Assets
            var assetId = saveToAsset([filePath], "/PTD Tables/" + mdDoc.get("Core_Publication") + "/" + mdDoc.get("Core_Issue") + "/" + mdDoc.get("Core_Name") + "/" + lastFolder);
        }


        function exportMathMLinTable(doc, mdDoc, mdWf, zone, overwrite, currentPage) {
            var pasteboardItem = false;
            var currPage, currSpread;

            var wwLayer;
            try {
                wwLayer = doc.layers.add({
                    name: "WW_generated_images"
                });
            } catch (err) {
                // already exists
                wwLayer = doc.layers.item("WW_generated_images");
            }

            currPage = currentPage;
            if (currPage == null) {
                if (zone.parentTextFrames[0].parent instanceof Spread)
                    currSpread = zone.parentTextFrames[0].parent;
                else
                    currSpread = zone.parentTextFrames[0].parent.parentTextFrames[0].parent;
                pasteboardItem = true;
            } else {
                currSpread = currPage.parent;
            }
            var updateInstead = false;
            var mathMLFileName = "mathml" + "_" + mathmlIndex + ".png";
            var mathMLLink = findLinkByNameMathML(doc, mathMLFileName, mathmlIndex);
            if (mathMLLink != undefined && mathMLLink.isValid && overwrite === true) {
                graphic = mathMLLink.parent.parent;
                updateInstead = true;
            } else if (mathMLLink != undefined && mathMLLink.isValid) {} else {
                if (pasteboardItem) {
                    if (currSpread.pages.length > 1) {
                        if (zone.paragraphs[0].parentTextFrames[0].visibleBounds[1] < 0) {
                            // left side of spread
                            currPage = currSpread.pages.item(0);
                        } else {
                            currPage = currSpread.pages.item(1);
                        }
                    } else {
                        currPage = currSpread.pages.item(0);
                    }
                }
                graphic = currPage.rectangles.add();
            }

            // add a new text frame to paste table into
            var textFrame = currPage.textFrames.add();

            // adjust leading and pointsize to minimize spacing around table
            textFrame.parentStory.leading = 0;
            textFrame.parentStory.pointSize = 0.1;

            // select and paste clipboard into the text frame
            zone.duplicate(LocationOptions.AFTER, textFrame);

            // refit text frame to table
            textFrame.visibleBounds = zone.paragraphs[0].parentTextFrames[0].visibleBounds;
            log.info("visible bounds: " + textFrame.visibleBounds);

            //remove textstyles
            //remove all paragraph styles
            var color = makeColor("C=0 M=0 Y=0 K=100", ColorSpace.CMYK, ColorModel.process, [0, 0, 0, 100]);
            textFrame.textColumns.everyItem().fillColor = color;
            textFrame.parentStory.firstLineIndent = 0;
            textFrame.parentStory.lastLineIndent = 0;
            textFrame.parentStory.leftIndent = 0.25;
            textFrame.parentStory.rightIndent = 0;
            textFrame.parentStory.spaceBefore = 0;
            textFrame.parentStory.bulletsAndNumberingListType = ListType.NO_LIST;
            textFrame.parentStory.spanColumnType = SpanColumnTypeOptions.SINGLE_COLUMN;
            textFrame.fit(FitOptions.FRAME_TO_CONTENT);
            textFrame.geometricBounds = [textFrame.geometricBounds[0], textFrame.geometricBounds[1], textFrame.geometricBounds[2], textFrame.geometricBounds[3] + 1];

            //remove secret nested textstyles..
            for (var index = 0; index < textFrame.parentStory.nestedStyles.length; index++) {
                textFrame.parentStory.nestedStyles[index].remove();
            }

            // export text frame to png
            var mathMLFileName = "mathml" + "_" + mathmlIndex + ".png";
            var filePath = doc.filePath + "/" + mathMLFileName;
            var mathMLFile = new File(filePath);
            app.pngExportPreferences.exportResolution = 300.0;
            app.pngExportPreferences.transparentBackground = true;
            textFrame.exportFile(ExportFormat.PNG_FORMAT, mathMLFile, false);

            // delete text frame after export
            textFrame.remove();

            // Add image to Assets
            var assetId = saveToAsset([filePath], "/PTD Tables/" + mdDoc.get("Core_Publication") + "/" + mdDoc.get("Core_Issue") + "/" + mdDoc.get("Core_Name") + "/" + "MathML Table Descriptions");
            if (assetId && assetId != '') {
                if (updateInstead) {
                    log.info('Update Instead ' + filePath);
                    $.sleep(500);
                    mathMLLink.downloadElvisLink();
                    mdWf.updateAllContent();
                    graphic.fit(FitOptions.FRAME_TO_CONTENT);
                } else {
                    graphic.elvisPlace(assetId);
                    graphic.fit(FitOptions.FRAME_TO_CONTENT);

                    // Capture spread bounds
                    var LeftRightSpreadBoundX = currSpread.pages.firstItem().bounds[1];
                    for (var z = 0; z < currSpread.pages.length; z++) {
                        if (currSpread.pages[z].side == PageSideOptions.LEFT_HAND) {
                            LeftRightSpreadBoundX = currSpread.pages[z].bounds[3];
                        }
                    }

                    if (currPage.side === PageSideOptions.LEFT_HAND) {
                        dX = LeftRightSpreadBoundX - currSpread.pages.firstItem().bounds[1];
                    } else {
                        dX = currSpread.pages.lastItem().bounds[3] - LeftRightSpreadBoundX;
                    }

                    dX += Math.max(
                        doc.documentPreferences.documentBleedInsideOrLeftOffset,
                        doc.documentPreferences.slugInsideOrLeftOffset
                    );
                    dX += Math.max(
                        doc.documentPreferences.documentBleedOutsideOrRightOffset,
                        doc.documentPreferences.slugRightOrOutsideOffset
                    );

                    var pbOffset = 10;

                    dX += pbOffset;

                    // Adjust pasteboard margins if our object is too big
                    var pbMargins = doc.pasteboardPreferences.pasteboardMargins;
                    if (pbMargins[0] < dX + pbOffset) {
                        doc.pasteboardPreferences.pasteboardMargins = [dX + pbOffset, pbMargins[1]];
                    }

                    if (currPage.side === PageSideOptions.LEFT_HAND) {
                        dX *= -1;
                    }

                    // Move first to original location (only if it's not a pasteboard item)
                    if (!pasteboardItem)
                        graphic.move([zone.horizontalOffset, zone.baseline - (graphic.visibleBounds[2] - graphic.visibleBounds[0])]);
                    else
                        graphic.move([currPage.bounds[1], currPage.bounds[0]]);

                    // Move horizontally to pasteboard
                    graphic.move(undefined, [dX, 0]);

                    graphic.nonprinting = true;
                    graphic.itemLayer = wwLayer;
                    graphic.fillColor = doc.swatches.item("None");
                    graphic.strokeColor = doc.swatches.item("None");
                }


            } else {
                alert("Unable to proceed due to error. Please try again.");
            }

            return mathmlIndex;
        }

        function _convertMathML(doc) {
            var stories = doc.stories;
            var mdDoc = doc.entMetaData;
            var mdWf = doc.entWorkflow;
            var saveDossiers = [];
            var wwLayer;

            try {
                wwLayer = doc.layers.add({
                    name: "WW_generated_images"
                });
            } catch (err) {
                // already exists
                wwLayer = doc.layers.item("WW_generated_images");
            }

            var overwrite = overwriteExisting("MathML", doc);

            if (overwrite == "close") {
                return;
            }

            // loop through all stories
            var stories = app.activeDocument.stories.everyItem().paragraphs.everyItem();
            var allMathZones = stories.mtAllMathZones;

            var mathmlIndex = 1;
            for (var x = allMathZones.length - 1; x >= 0; x--) {
                if (typeof allMathZones[x] != 'undefined') {
                    exportMathML(doc, mdDoc, mdWf, allMathZones[x], overwrite, mathmlIndex);
                }
            }
        }

        function exportTables(doc, mdDoc, mdWf, story, overwrite) {
            var storyTables = story.tables;
            var wwLayer;

            try {
                wwLayer = doc.layers.add({
                    name: "WW_generated_images"
                });
            } catch (err) {
                // already exists
                wwLayer = doc.layers.item("WW_generated_images");
            }

            // loop through story's tables
            if (storyTables.length > 0) {
                for (var y = storyTables.length - 1; y >= 0; y--) {
                    var pasteboardItem = false;
                    var currPage, currSpread;

                    // get current page and spread
                    currPage = storyTables[y].parent.parentPage;
                    if (currPage == null) {
                        currSpread = storyTables[y].parent.parent;
                        pasteboardItem = true;
                    } else {
                        currSpread = currPage.parent;
                    }

                    var graphic;
                    var updateInstead = false;
                    var tableFileName = mdDoc.get("Core_Name") + "_table_" + storyTables[y].id + ".png";
                    var tableLink = findLinkByName(doc, tableFileName, storyTables[y].id);
                    if (tableLink != undefined && tableLink.isValid && overwrite === true) {
                        graphic = tableLink.parent.parent;
                        updateInstead = true;
                    } else if (tableLink != undefined && tableLink.isValid) {
                        // skip
                        continue;
                    } else {
                        if (pasteboardItem) {
                            if (currSpread.pages.length > 1) {
                                if (storyTables[y].parent.visibleBounds[1] < 0) {
                                    // left side of spread
                                    currPage = currSpread.pages.item(0);
                                } else {
                                    currPage = currSpread.pages.item(1);
                                }
                            } else {
                                currPage = currSpread.pages.item(0);
                            }
                        }
                        graphic = currPage.rectangles.add();
                    }
                    // select and copy the table to clipboard
                    app.select(storyTables[y]);
                    app.copy();

                    // add a new text frame to paste table into
                    var textFrame = currPage.textFrames.add();

                    // adjust leading and pointsize to minimize spacing around table
                    textFrame.parentStory.leading = 0;
                    textFrame.parentStory.pointSize = 0.1;

                    // select and paste clipboard into the text frame
                    app.select(textFrame.insertionPoints[0]);
                    app.paste();

                    // refit text frame to table
                    textFrame.fit(FitOptions.FRAME_TO_CONTENT);

                    // export text frame to png
                    var tableFileName = mdDoc.get("Core_Name") + "_table_" + storyTables[y].id + ".png";
                    var filePath = doc.filePath + "/" + tableFileName;
                    var tableFile = new File(filePath);
                    app.pngExportPreferences.exportResolution = 300.0;
                    app.pngExportPreferences.transparentBackground = true;
                    textFrame.exportFile(ExportFormat.PNG_FORMAT, tableFile, false);

                    // delete text frame after export
                    textFrame.remove();

                    // Add image to Assets
                    var assetId = saveToAsset([filePath], "/PTD Images/" + mdDoc.get("Core_Publication") + "/" + mdDoc.get("Core_Issue") + "/" + mdDoc.get("Core_Name"));
                    if (assetId && assetId != '') {
                        if (updateInstead) {
                            $.sleep(250);
                            tableLink.downloadElvisLink();
                            mdWf.updateAllContent();
                            graphic.fit(FitOptions.FRAME_TO_CONTENT);
                        } else {
                            var temp = graphic.elvisPlace(assetId);

                            graphic.fit(FitOptions.FRAME_TO_CONTENT);

                            // Re-adjust image anchor offset to account for paragraph spacing from exporting image to png
                            var anchorYoffset = "-2mm";

                            // If table was in-line with other text, make offset larger
                            if (storyTables[y].parent.allPageItems.length > 0) {
                                anchorYoffset = "-2mm";
                            }

                            // Capture the position the table is in within the text frame
                            var insertionPoint = storyTables[y].storyOffset;

                            // Capture spread bounds
                            var LeftRightSpreadBoundX = currSpread.pages.firstItem().bounds[1];
                            for (var z = 0; z < currSpread.pages.length; z++) {
                                if (currSpread.pages[z].side == PageSideOptions.LEFT_HAND) {
                                    LeftRightSpreadBoundX = currSpread.pages[z].bounds[3];
                                }
                            }

                            if (currPage.side === PageSideOptions.LEFT_HAND) {
                                dX = LeftRightSpreadBoundX - currSpread.pages.firstItem().bounds[1];
                            } else {
                                dX = currSpread.pages.lastItem().bounds[3] - LeftRightSpreadBoundX;
                            }

                            dX += Math.max(
                                doc.documentPreferences.documentBleedInsideOrLeftOffset,
                                doc.documentPreferences.slugInsideOrLeftOffset
                            );
                            dX += Math.max(
                                doc.documentPreferences.documentBleedOutsideOrRightOffset,
                                doc.documentPreferences.slugRightOrOutsideOffset
                            );

                            var pbOffset = 10;

                            dX += pbOffset;

                            // Adjust pasteboard margins if our object is too big
                            var pbMargins = doc.pasteboardPreferences.pasteboardMargins;
                            if (pbMargins[0] < dX + pbOffset) {
                                doc.pasteboardPreferences.pasteboardMargins = [dX + pbOffset, pbMargins[1]];
                            }

                            if (currPage.side === PageSideOptions.LEFT_HAND) {
                                dX *= -1;
                            }

                            // Move first to original location (only if it's not a pasteboard item)
                            if (!pasteboardItem)
                                graphic.move([storyTables[y].storyOffset.horizontalOffset, storyTables[y].storyOffset.baseline - (graphic.visibleBounds[2] - graphic.visibleBounds[0])]);
                            else
                                graphic.move([currPage.bounds[1], currPage.bounds[0]]);

                            // Move horizontally to pasteboard
                            graphic.move(undefined, [dX, 0]);

                            graphic.nonprinting = true;
                            graphic.itemLayer = wwLayer;
                            graphic.fillColor = doc.swatches.item("None");
                            graphic.strokeColor = doc.swatches.item("None");
                        }
                    } else {
                        alert("Unable to proceed due to error. Please try again.");
                    }
                }
            }
            return true;
        }

        function exportMathML(doc, mdDoc, mdWf, mathZones, overwrite, mathmlIndex) {
            var wwLayer;
            try {
                wwLayer = doc.layers.add({
                    name: "WW_generated_images"
                });
            } catch (err) {
                // already exists
                wwLayer = doc.layers.item("WW_generated_images");
            }

            for (var y = 0; y < mathZones.length; y++) {
                // select and copy the math ml to clipboard

                var pasteboardItem = false;
                var currPage, currSpread;
                var zone = mathZones[y];

                currPage = zone.parentTextFrames[0].parentPage;
                if (currPage == null) {
                    if (zone.parentTextFrames[0].parent instanceof Spread)
                        currSpread = zone.parentTextFrames[0].parent;
                    else
                        currSpread = zone.parentTextFrames[0].parent.parentTextFrames[0].parent;
                    pasteboardItem = true;
                } else {
                    currSpread = currPage.parent;
                }

                var mathMLFileName = "mathml" + "_" + mathmlIndex + ".png";
                var mathMLLink = findLinkByNameMathML(doc, mathMLFileName, mathmlIndex);
                if (mathMLLink != undefined && mathMLLink.isValid && overwrite === true) {
                    graphic = mathMLLink.parent.parent;
                    updateInstead = true;
                } else if (mathMLLink != undefined && mathMLLink.isValid) {
                    // skip
                    continue;
                } else {
                    if (pasteboardItem) {
                        if (currSpread.pages.length > 1) {
                            if (zone.paragraphs[0].parentTextFrames[0].visibleBounds[1] < 0) {
                                // left side of spread
                                currPage = currSpread.pages.item(0);
                            } else {
                                currPage = currSpread.pages.item(1);
                            }
                        } else {
                            currPage = currSpread.pages.item(0);
                        }
                    }
                    graphic = currPage.rectangles.add();
                }

                // add a new text frame to paste table into
                var textFrame = currPage.textFrames.add();

                // adjust leading and pointsize to minimize spacing around table
                textFrame.parentStory.leading = 0;
                textFrame.parentStory.pointSize = 0.1;

                // select and paste clipboard into the text frame
                zone.duplicate(LocationOptions.AFTER, textFrame);

                // refit text frame to table
                textFrame.visibleBounds = zone.paragraphs[0].parentTextFrames[0].visibleBounds;
                log.info("visible bounds: " + textFrame.visibleBounds);

                //remove textstyles
                //remove all paragraph styles
                var color = makeColor("C=0 M=0 Y=0 K=100", ColorSpace.CMYK, ColorModel.process, [0, 0, 0, 100]);
                textFrame.textColumns.everyItem().fillColor = color;
                textFrame.parentStory.firstLineIndent = 0;
                textFrame.parentStory.lastLineIndent = 0;
                textFrame.parentStory.leftIndent = 0.25;
                textFrame.parentStory.rightIndent = 0;
                textFrame.parentStory.spaceBefore = 0;
                textFrame.parentStory.bulletsAndNumberingListType = ListType.NO_LIST;
                textFrame.parentStory.spanColumnType = SpanColumnTypeOptions.SINGLE_COLUMN;
                textFrame.fit(FitOptions.FRAME_TO_CONTENT);
                textFrame.geometricBounds = [textFrame.geometricBounds[0], textFrame.geometricBounds[1], textFrame.geometricBounds[2], textFrame.geometricBounds[3] + 1];

                //remove secret nested textstyles..
                for (var index = 0; index < textFrame.parentStory.nestedStyles.length; index++) {
                    textFrame.parentStory.nestedStyles[index].remove();
                }


                // export text frame to png
                var mathMLFileName = "mathml" + "_" + mathmlIndex + ".png";
                var filePath = doc.filePath + "/" + mathMLFileName;
                var mathMLFile = new File(filePath);
                app.pngExportPreferences.exportResolution = 300.0;
                app.pngExportPreferences.transparentBackground = true;
                textFrame.exportFile(ExportFormat.PNG_FORMAT, mathMLFile, false);

                // delete text frame after export
                textFrame.remove();

                // Add image to Assets
                var assetId = saveToAsset([filePath], "/PTD Tables/" + mdDoc.get("Core_Publication") + "/" + mdDoc.get("Core_Issue") + "/" + mdDoc.get("Core_Name") + "/" + "MathML Table Descriptions");
                if (assetId && assetId != '') {
                    if (updateInstead) {
                        log.info('Update Instead ' + filePath);
                        $.sleep(500);
                        mathMLLink.downloadElvisLink();
                        mdWf.updateAllContent();
                        graphic.fit(FitOptions.FRAME_TO_CONTENT);
                    } else {
                        graphic.elvisPlace(assetId);
                        graphic.fit(FitOptions.FRAME_TO_CONTENT);

                        // Capture spread bounds
                        var LeftRightSpreadBoundX = currSpread.pages.firstItem().bounds[1];
                        for (var z = 0; z < currSpread.pages.length; z++) {
                            if (currSpread.pages[z].side == PageSideOptions.LEFT_HAND) {
                                LeftRightSpreadBoundX = currSpread.pages[z].bounds[3];
                            }
                        }

                        if (currPage.side === PageSideOptions.LEFT_HAND) {
                            dX = LeftRightSpreadBoundX - currSpread.pages.firstItem().bounds[1];
                        } else {
                            dX = currSpread.pages.lastItem().bounds[3] - LeftRightSpreadBoundX;
                        }

                        dX += Math.max(
                            doc.documentPreferences.documentBleedInsideOrLeftOffset,
                            doc.documentPreferences.slugInsideOrLeftOffset
                        );
                        dX += Math.max(
                            doc.documentPreferences.documentBleedOutsideOrRightOffset,
                            doc.documentPreferences.slugRightOrOutsideOffset
                        );

                        var pbOffset = 10;

                        dX += pbOffset;

                        // Adjust pasteboard margins if our object is too big
                        var pbMargins = doc.pasteboardPreferences.pasteboardMargins;
                        if (pbMargins[0] < dX + pbOffset) {
                            doc.pasteboardPreferences.pasteboardMargins = [dX + pbOffset, pbMargins[1]];
                        }

                        if (currPage.side === PageSideOptions.LEFT_HAND) {
                            dX *= -1;
                        }

                        // Move first to original location (only if it's not a pasteboard item)
                        if (!pasteboardItem)
                            graphic.move([zone.horizontalOffset, zone.baseline - (graphic.visibleBounds[2] - graphic.visibleBounds[0])]);
                        else
                            graphic.move([currPage.bounds[1], currPage.bounds[0]]);

                        // Move horizontally to pasteboard
                        graphic.move(undefined, [dX, 0]);

                        graphic.nonprinting = true;
                        graphic.itemLayer = wwLayer;
                        graphic.fillColor = doc.swatches.item("None");
                        graphic.strokeColor = doc.swatches.item("None");
                    }


                } else {
                    alert("Unable to proceed due to error. Please try again.");
                }
                //mathmlIndex++;
            }
            return mathmlIndex;
        }

        function makeColor(colorName, colorSpace, colorModel, colorValue) {

            var doc = app.activeDocument;

            var color = doc.colors.item(colorName);

            if (!color.isValid) {

                color = doc.colors.add({
                    name: colorName,
                    space: colorSpace,
                    model: colorModel,
                    colorValue: colorValue
                });

            }
            return color;
        }

        /**
         * Converts tables to asset images in the front document
         * @throws ArticleExistsError
         */
        function prepareTables() {
            log.info('=> ptd-prepare-service.prepareTables');
            var doc = app.activeDocument;
            var myRegularExpression = /.indd/gi
            var name = doc.name.replace(myRegularExpression, "");

            installJSON();
            _convertTables(doc);

            log.info('<= ptd-prepare-service.prepareTables');
        }



        function prepareMathML() {
            log.info('=> ptd-prepare-service.prepareMathML');
            var doc = app.activeDocument;
            var myRegularExpression = /.indd/gi
            var name = doc.name.replace(myRegularExpression, "");

            installJSON();
            _convertMathML(doc);

            log.info('<= ptd-prepare-service.prepareMathML');
        }

        function saveToAsset(filePaths, pAssetPath) {
            var assetId = '';
            for (var i = 0; i < filePaths.length; i++) {
                var assetFile = new File(filePaths[i]);
                if (assetFile.exists) {
                    var existingAssetId = getAsset(decodeURI(assetFile.name), pAssetPath);
                    if (existingAssetId) {
                        log.info("Updating Asset " + existingAssetId + " named: " + assetFile.name + "");
                        var isAssetUpdate = updateAsset(existingAssetId, assetFile);
                        //if( isAssetUpdate && pProZonePath ) {
                        //	updateAssetInProductionZone( existingAssetId, assetFile );
                        //}
                        assetId = existingAssetId;
                    } else {
                        assetId = createNewAsset(assetFile, pAssetPath);
                        log.info("New asset has Id " + assetId);
                    }
                    assetFile.remove();
                } else {
                    alert("Image File " + assetFile.path + " does not exist.");
                }
            }
            return assetId;
        }

        function getAsset(fileName, pAssetPath) {
            var queryString = 'filename:"' + fileName + '" AND folderPath: "' + pAssetPath + '"';
            var r = [
                ["q", queryString, "String"],
                ["num", "1", "String"],
                ["metadataToReturn", "", "String"]
            ];
            var response = app.elvisPostRequest("/search", r);
            if (!response) {
                throw new Error('Cannot connect to Asset Server.');
                return false;
            }
            var asset = JSON.parse(response);
            if (asset == null) {
                throw new Error("Asset Server didn't return valid JSON.");
            }
            if (asset && asset.errorcode && asset.errorcode == 401) {
                throw new Error('Cannot connect to Asset Server.');
            }
            if (asset.totalHits == 0) {
                return false;
            }
            return asset.hits[0].id;
        }

        function createNewAsset(assetFile, pAssetPath) {
            var r = [
                ["Filedata", assetFile, "File"],
                ["filename", decodeURI(assetFile.name), "String"],
                ["folderPath", pAssetPath, "String"],
                ["metadataToReturn", "assetPath", "String"]
            ];
            var response = app.elvisPostRequest("/create", r);
            var newAsset = JSON.parse(response);
            if (newAsset) {} else {
                alert("New asset failed to create in Asset Server.");
            }
            return newAsset.id;
        }

        function updateAsset(assetId, assetFile) {
            var r = [
                ["id", assetId, "String"],
                ["Filedata", assetFile, "File"],
                ["filename", decodeURI(assetFile.name), "String"],
                ["metadataToReturn", "assetPath", "String"]
            ];
            var response = app.elvisPostRequest("/update", r);
            var asset = JSON.parse(response);
            if (asset) {} else {
                alert("Asset failed to update in Asset Server.");
                return false;
            }
            return true;
        }

        function showIt(theObj) {
            if (arguments.length > 0) {
                // Select object, turn to page and center it in the window
                app.select(theObj);
            }
            // Note: if no object is passed and there is no selection the current page
            // will be centered in the window at whatever zoom is being used
            var myZoom = app.activeWindow.zoomPercentage;
            app.activeWindow.zoom(ZoomOptions.showPasteboard);
            app.activeWindow.zoomPercentage = myZoom;
        }

        //mathml helper function
        function findLinkByNameMathML(doc, filename, itemId) {
            log.info("Finding link: " + filename);
            var links = doc.links;
            for (var x = 0; x < links.length; x++) {
                if (links[x].name.indexOf("_" + itemId) > 0 && links[x].name.indexOf("ml_") > 0) {
                    log.info("Found link: " + filename);
                    return links[x];
                }
            }
            log.info("Could not find: " + filename);
            return undefined;
        }

        function findLinkByName(doc, filename, itemId) {
            log.info("Finding link: " + filename);
            var links = doc.links;
            for (var x = 0; x < links.length; x++) {
                if (links[x].name.indexOf("_" + itemId) > 0 && links[x].name.indexOf("_table_") > 0) {
                    log.info("Found link: " + filename);
                    return links[x];
                }
            }
            log.info("Could not find: " + filename);
            return undefined;
        }

        function overwriteExisting(type, doc) {
            var selectedValue = false;

            if (typeof doc.mtAllMathZones != 'undefined') {
                var allMathZonesLength = doc.mtAllMathZones.length;
            }

            myDlg = new Window('dialog', '');
            myDlg.orientation = 'column';
            myDlg.alignment = 'left';

            //Add label
            myDlg.LblGroup = myDlg.add('group');
            myDlg.LblGroup.orientation = 'row';
            myDlg.LblGroup.alignment = 'left';
            myDlg.LblGroup.add('statictext', undefined, "Preparar opções de " + type + "\n");

            if (type == "MathML") {
                myDlg.numGroup = myDlg.add('group');
                myDlg.numGroup.orientation = 'row';
                myDlg.numGroup.alignment = 'left';
                if (typeof doc.mtAllMathZones != 'undefined') {
                    myDlg.numGroup.add('statictext', undefined, allMathZonesLength + " MathZones para processar");
                }
            }

            //add drop-down
            myDlg.DDgroup = myDlg.add('group');
            myDlg.DDgroup.orientation = 'row';
            myDlg.DDgroup.alignment = 'left';

            myDlg.DDgroup.DD = myDlg.DDgroup.add('checkbox', undefined, undefined, {
                name: "checkbox"
            });
            myDlg.DDgroup.DD.text = "Regenerar " + type + " existentes?";
            myDlg.DDgroup.DD.selection = 0;
            myDlg.DDgroup.DD.minimumSize.width = 400;

            //Cancel button
            myDlg.btnGroup = myDlg.add('group');
            myDlg.btnGroup.orientation = 'row';
            myDlg.btnGroup.alignment = 'right';

            myDlg.cancelBtn = myDlg.btnGroup.add('button', undefined, 'Cancel');
            myDlg.cancelBtn.onClick = function() {
                selectedValue = "close";
                this.parent.close();
            }

            //Ok Button
            myDlg.okBtn = myDlg.btnGroup.add('button', undefined, 'OK');
            myDlg.okBtn.onClick = function() {
                selectedValue = myDlg.DDgroup.DD.value;
                this.parent.close();
            }

            myDlg.center();
            myDlg.show();

            return selectedValue;
        }

        function installJSON() {
            if (typeof JSON !== 'object') {
                JSON = {};
            }

            if (typeof JSON.stringify !== 'function' || typeof JSON.parse !== 'function') {
                (function() {
                    'use strict';

                    var rx_one = /^[\],:{}\s]*$/;
                    var rx_two = /\\(?:["\\\/bfnrt]|u[0-9a-fA-F]{4})/g;
                    var rx_three = /"[^"\\\n\r]*"|true|false|null|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?/g;
                    var rx_four = /(?:^|:|,)(?:\s*\[)+/g;
                    var rx_escapable = /[\\"\u0000-\u001f\u007f-\u009f\u00ad\u0600-\u0604\u070f\u17b4\u17b5\u200c-\u200f\u2028-\u202f\u2060-\u206f\ufeff\ufff0-\uffff]/g;
                    var rx_dangerous = /[\u0000\u00ad\u0600-\u0604\u070f\u17b4\u17b5\u200c-\u200f\u2028-\u202f\u2060-\u206f\ufeff\ufff0-\uffff]/g;

                    function f(n) {
                        // Format integers to have at least two digits.
                        return n < 10 ?
                            '0' + n :
                            n;
                    }

                    function this_value() {
                        return this.valueOf();
                    }

                    if (typeof Date.prototype.toJSON !== 'function') {

                        Date.prototype.toJSON = function() {

                            return isFinite(this.valueOf()) ?
                                this.getUTCFullYear() + '-' +
                                f(this.getUTCMonth() + 1) + '-' +
                                f(this.getUTCDate()) + 'T' +
                                f(this.getUTCHours()) + ':' +
                                f(this.getUTCMinutes()) + ':' +
                                f(this.getUTCSeconds()) + 'Z' :
                                null;
                        };

                        Boolean.prototype.toJSON = this_value;
                        Number.prototype.toJSON = this_value;
                        String.prototype.toJSON = this_value;
                    }

                    var gap;
                    var indent;
                    var meta;
                    var rep;


                    function quote(string) {
                        rx_escapable.lastIndex = 0;
                        return rx_escapable.test(string) ? '"' + string.replace(rx_escapable, function(a) {
                            var c = meta[a];
                            return typeof c === 'string' ?
                                c :
                                '\\u' + ('0000' + a.charCodeAt(0).toString(16)).slice(-4);
                        }) + '"' : '"' + string + '"';
                    }

                    function str(key, holder) {

                        var i; // The loop counter.
                        var k; // The member key.
                        var v; // The member value.
                        var length;
                        var mind = gap;
                        var partial;
                        var value = holder[key];

                        if (value && typeof value === 'object' &&
                            typeof value.toJSON === 'function') {
                            value = value.toJSON(key);
                        }

                        if (typeof rep === 'function') {
                            value = rep.call(holder, key, value);
                        }

                        switch (typeof value) {
                            case 'string':
                                return quote(value);
                            case 'number':
                                return isFinite(value) ? String(value) : 'null';
                            case 'boolean':
                            case 'null':
                                return String(value);
                            case 'object':
                                if (!value) {
                                    return 'null';
                                }
                                gap += indent;
                                partial = [];
                                if (Object.prototype.toString.apply(value) === '[object Array]') {
                                    length = value.length;
                                    for (i = 0; i < length; i += 1) {
                                        partial[i] = str(i, value) || 'null';
                                    }
                                    v = partial.length === 0 ? '[]' : gap ? '[\n' + gap + partial.join(',\n' + gap) + '\n' + mind + ']' : '[' + partial.join(',') + ']';
                                    gap = mind;
                                    return v;
                                }

                                if (rep && typeof rep === 'object') {
                                    length = rep.length;
                                    for (i = 0; i < length; i += 1) {
                                        if (typeof rep[i] === 'string') {
                                            k = rep[i];
                                            v = str(k, value);
                                            if (v) {
                                                partial.push(quote(k) + (gap ? ': ' : ':') + v);
                                            }
                                        }
                                    }
                                } else {

                                    for (k in value) {
                                        if (Object.prototype.hasOwnProperty.call(value, k)) {
                                            v = str(k, value);
                                            if (v) {
                                                partial.push(quote(k) + (gap ? ': ' : ':') + v);
                                            }
                                        }
                                    }
                                }

                                v = partial.length === 0 ?
                                    '{}' :
                                    gap ?
                                    '{\n' + gap + partial.join(',\n' + gap) + '\n' + mind + '}' :
                                    '{' + partial.join(',') + '}';
                                gap = mind;
                                return v;
                        }
                    }

                    if (typeof JSON.stringify !== 'function') {
                        meta = { // table of character substitutions
                            '\b': '\\b',
                            '\t': '\\t',
                            '\n': '\\n',
                            '\f': '\\f',
                            '\r': '\\r',
                            '"': '\\"',
                            '\\': '\\\\'
                        };
                        JSON.stringify = function(value, replacer, space) {

                            var i;
                            gap = '';
                            indent = '';

                            if (typeof space === 'number') {
                                for (i = 0; i < space; i += 1) {
                                    indent += ' ';
                                }
                            } else if (typeof space === 'string') {
                                indent = space;
                            }

                            rep = replacer;
                            if (replacer && typeof replacer !== 'function' &&
                                (typeof replacer !== 'object' ||
                                    typeof replacer.length !== 'number')) {
                                throw new Error('JSON.stringify');
                            }

                            return str('', {
                                '': value
                            });
                        };
                    }

                    if (typeof JSON.parse !== 'function') {
                        JSON.parse = function(text, reviver) {
                            var j;

                            function walk(holder, key) {
                                var k;
                                var v;
                                var value = holder[key];
                                if (value && typeof value === 'object') {
                                    for (k in value) {
                                        if (Object.prototype.hasOwnProperty.call(value, k)) {
                                            v = walk(value, k);
                                            if (v !== undefined) {
                                                value[k] = v;
                                            } else {
                                                delete value[k];
                                            }
                                        }
                                    }
                                }
                                return reviver.call(holder, key, value);
                            }

                            text = String(text);
                            rx_dangerous.lastIndex = 0;
                            if (rx_dangerous.test(text)) {
                                text = text.replace(rx_dangerous, function(a) {
                                    return '\\u' +
                                        ('0000' + a.charCodeAt(0).toString(16)).slice(-4);
                                });
                            }

                            if (
                                rx_one.test(
                                    text
                                    .replace(rx_two, '@')
                                    .replace(rx_three, ']')
                                    .replace(rx_four, '')
                                )
                            ) {

                                j = eval('(' + text + ')');

                                return typeof reviver === 'function' ?
                                    walk({
                                        '': j
                                    }, '') :
                                    j;
                            }

                            throw new SyntaxError('JSON.parse');
                        };
                    }
                }());
            }
        }

        // Public API
        return {
            prepareTables: prepareTables,
            prepareMathML: prepareMathML
        }
    }(Err, ConfigService, ComponentLookup, JSON, _);
}