/**
 * @description Ptd export - Helper to lookup component for an style
 *
 * @copyright WoodWing Software B.V. All rights reserved.
 */

if (forceInit || typeof $.global.ComponentLookup === 'undefined') {

#include '_.jsx'
#include 'err.jsx'
#include 'logging.jsx'

	var ComponentLookup = function (styles, mappingKey) {
		'use strict';
		var lookup = {}, // lookup of key to components
			regexes = {}; // lookup of regex key to new RegExp object
		_init();

		function _init() {
			var count = 0;
			log.info('=> component-lookup._init({})', mappingKey);

			_.each(styles, function (values, component) {
				if (Array.isArray(values)) {
					_.each(values, function (value) {
						// the value is also the key.

						if ((lookup[value] && lookup[value] !== component) || (regexes[value] && regexes[value] !== component)) {
							throw new Err.ConfigurationError(
								"Configuration of .{} mapping is incorrect. Style '{}' cannot not be mapped multiple times. See components '{}' and '{}'.".format(
									mappingKey, value, lookup[value], component),
								$.fileName, $.line);
						}

						lookup[value] = component;
						var match = value.match(new RegExp('^/(.*?)/([gimy]*)$'));
						log.info("  {}: '{}' -> {}", match?"REGEX":"STRING", value, component);
						if (match) {
							regexes[value] = new RegExp(match[1], match[2]);
						}
						count++;
					});
				}
			});
			if (!count) {
				throw new Err.ConfigurationError("Configuration of {} mapping is empty or incomplete.".format(mappingKey), $.fileName, $.line);
			}
			log.info('<= component-lookup._init');
		}

		/**
		 * Lookup which component this style matches to.
		 * @param style
		 * @returns {*}
		 */
		function lookupComponentForStyle(style) {
			var r, result = lookup[style];
			log.info('=> component-lookup.lookup({})', style);
			
			if (!result) {
				var found = _.some(regexes.keys(),function(k){
					r = regexes[k];
					if (r && style.match(r)) {
						result = lookup[k]
						return true;
					}
				});
			}

			log.info('<= component-lookup.lookup:[{}]',result);
			return result;
		}

		return {
			map: styles,
			lookup: lookupComponentForStyle
		};
	}
}
