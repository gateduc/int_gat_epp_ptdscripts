/**
 * @description Entry point for export of the InDesign article for use in Ptd
 *
 * @copyright WoodWing Software B.V. All rights reserved.
 */

#targetengine 'ptd'

var forceInit = false;

#include "modules/err.jsx"
#include "modules/logging.jsx"
#include "modules/ptd-switch-config.jsx"

// Force reload the configuration
ConfigService.loadConfig();

log.init(ConfigService.getConfig().logging, ConfigService.getConfig().exportDirectory+"/"+File.prototype.basename(app.activeDocument.name),"indesign-export.log");
log.info('{}, config: \n{}', $.fileName, JSON.stringify(ConfigService.getConfig(), null, 4));

(function(PtdSwitchService, Err){
	'use strict';

	try {
		$.hiresTimer;
		PtdSwitchService.displayWindow();
		var t = $.hiresTimer;

	} catch(error if error.is(Err.ArticleDoesNotExistError)) {
		error.alert();
	}

})(PtdSwitchService, Err);

$.gc();
log.warning('Footprint:\n\tArray:\t\t\t{Array}\n\tFunction:\t\t{Function}\n\t(workspace):\t{(workspace)}\n\tObject:\t\t\t{Object}', _.memArray());