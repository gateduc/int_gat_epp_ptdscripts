﻿/**
 * @description Error extensions and factory. Based on https://github.com/debrouwere/Extendables.
 *
 * @copyright Extendables has a MIT-license
 */

if(forceInit || typeof $.global.Err === 'undefined') {

#include "_.jsx"
#include "logging.jsx"

var Err = function() {
	'use strict';

	/**
	 * First part copied and adapted from extendables/patches/error.jsx. Indicated by START and END.
	 *
	 * -- START --
	 *
	 */

	/**
	 * @desc This methodo all error types being considered the base class Error. This problem makes it impossible to
	 * do simple comparisons on errors, for example ``new EvalError() instanceof SyntaxError``. The previous
	 * expression should return false but will return true.
	 *
	 * When testing whether you're dealing with a specific kind of error, use this method, and refrain
	 * from using ``instanceof``.
	 *
	 * @param {Constructor} type Use the constructor itself, not a string or an instance.
	 *
	 * @example
	 *     try { overloads :func:`Object#is` to combat a problem with some versions of ExtendScript
	 * that leads t
	 *         raise new SyntaxError();
	 *     } catch (error if error.is(TypeError)) {
	 *         alert("This displays in case of a type error, but not in case of a syntax error.");
	 *     }
	 *
	 * @see :ref:`error-handling` has some useful advice on how to handle errors in ExtendScript.
	 *
	 * @returns {Bool}
	 *     True or false. Any error type matches the base class, so ``new SyntaxError().is(Error)`` would return ``true``.
	 */

	Error.prototype.is = function (type) {
		if (typeof this !== "undefined" && this instanceof type) {
			if ('_type' in this) {
				return type == Error || this._type == type;
			} else {
				throw new TypeError("This method only works on built-in error types \
					and those created using the Error.factory class method.");
			}
		} else {
			return false;
		}
	}

	Error.prototype.alert = function (msg) {
		var includeErrorDetail = ConfigService.getConfig().includeErrorDetail;
		if(msg) {
			alert("An error occurred: " + msg + (includeErrorDetail ? "\n"+this.name+": "+this.message+"\nFile: "+this.file+"\nLine: "+this.line : ""));
		} else {
			//alert(this.name+": "+this.message+"\nFile: "+this.file+"\nLine: "+this.line);
			alert (this.message);
		}
	}

	/**
	 * @desc Use this classmethod to make sure your custom error types work
	 * just like the built-in ones.
	 *
	 * @param {String} name Preferably the same name as the variable you're associating the error with.
	 *
	 * @example var DatabaseError = Error.factory("DatabaseError");
	 */

	Error.factory = function (name, defaultMsg) {
		var error = function error(msg, file, line) {
			this.name = name;
			if(typeof file !== 'undefined')
				this.file = file;
			if(typeof line !== 'undefined')
				this.line = line;
			this.message = msg || defaultMsg;
			this._type = error;
			this.stack = $.stack;

			log.error('Error.factory :: name:[{name}], file:[{file}], line:[{line}], message:[{message}, stack:\n{stack}', this)
		}
		error.prototype = new Error();
		return error;
	}
	/**
	 * @class
	 * @name Error
	 * @desc A general-purpose error
	 */

	Error.prototype._type = Error;

	/**
	 * @class
	 * @name EvalError
	 * @desc An error that occurs regarding the global function eval()
	 */

	EvalError.prototype._type = EvalError;

	/**
	 * @class
	 * @name RangeError
	 * @desc An error that occurs when a numeric variable or parameter is outside of its valid range
	 */

	RangeError.prototype._type = RangeError;

	/**
	 * @class
	 * @name ReferenceError
	 * @desc An error that occurs when de-referencing an invalid reference
	 */

	ReferenceError.prototype._type = ReferenceError;

	/**
	 * @class
	 * @name SyntaxError
	 * @desc An error that occurs regarding the global function eval()
	 */

	SyntaxError.prototype._type = SyntaxError;

	/**
	 * @class
	 * @name TypeError
	 * @desc An error that occurs when a variable or parameter is not of a valid type
	 */

	TypeError.prototype._type = TypeError;

	/**
	 * @class
	 * @name IOError
	 * @desc Use when an IO operation (loading a file, writing to a file, an internet connection) fails.
	 */

	IOError.prototype._type = IOError;

	if (app.name.toLowerCase().indexOf("indesign") >= 0) {
		/**
		 * @class
		 * @name ValidationError
		 */
		ValidationError.prototype._type = ValidationError;
	}

	function wrapMessage(msg, e) {
		var str = msg;
		if (e) {
			str += "\nCaused by: " + (e.msg || e.message || e );
			if (e.fileName) str += "\n  file: " + e.fileName;
			if (e.line) str += "\n  line: " + e.line;
		}
		return str;
	}

	return {

		wrap: wrapMessage,

		/**
		 * @class
		 * @name ArithmeticError
		 * @desc Use when a calculation misbehaves.
		 */
		ArithmeticError: Error.factory("ArithmeticError"),

		/**
		 * @class
		 * @name ImportError
		 * @desc Use when an import fails. More specific than IOError.
		 */
		ImportError: Error.factory("ImportError"),

		/**
		 * @class
		 * @name EnvironmentError
		 * @desc Use for exceptions that have nothing to do with Extendables or ExtendScript.
		 */
		EnvironmentError: Error.factory("EnvironmentError"),

		/**
		 * @class
		 * @name ParseError
		 * @desc Much like EvalError, but for your own parsers.
		 */
		ParseError: Error.factory("ParseError"),

		/**
		 * @class
		 * @name SystemError
		 * @desc Use when the system (either the Creative Suite app or the operating system) malfunctions.
		 */
		SystemError: Error.factory("SystemError"),

		/**
		 * @class
		 * @name NotImplementedError
		 * @desc Use to warn people that a feature has not yet been implemented, as a placeholder
		 * to remind yourself or to indicate that a subclass needs to overload the parent method.
		 */
		NotImplementedError: Error.factory("NotImplementedError"),

		/**
		 * -- END --
		 */


		/**
		 * Ptd errors
		 */
		ArticleExistsError: Error.factory('ArticleExistsError', 'The PrintToDigtal article already exists.\nPlease see the InDesign Articles panel'),
		ArticleDoesNotExistError: Error.factory('ArticleDoesNotExistError', 'The PrintToDigital article does not exist, please select "Prepare Article" first'),

		FileWriteError: Error.factory('FileWriteError', 'Could not write to file.'),
		ExportError: Error.factory('ExportError', 'Could not export article to ptd.'),
		ArgumentError: Error.factory("ArgumentError", "Invalid argument"),
		ConfigurationError: Error.factory('ConfigurationError')
	}
}();

}
