﻿/**
 * @description Startup script for menu creation
 *
 * @copyright WoodWing Software B.V. All rights reserved.
 */
 #targetengine 'ptd'

var ptdStartup = ptdStartup ||
	(function(){

		_actions = [];

		var ptdScriptFolder = app.activeScript.parent.parent;
		ptdScriptFolder.changePath('PrintToDigital');
		if(!ptdScriptFolder.exists)
			throw("Configuration error: PrintToDigital scripts cannot be located.");

		function handler(title, fileName) {
			return function(ev) {
				app.doScript( new File(ptdScriptFolder + '/' + fileName), ScriptLanguage.JAVASCRIPT, [], UndoModes.FAST_ENTIRE_SCRIPT, title );
			}
		}

		function _createMenu(title, fileName){
			var action = app.scriptMenuActions.add(title);
			action.eventListeners.add('onInvoke', handler(title, fileName));
			ptdSubmenu.menuItems.add(action);
            _actions.push(action);
		}
		var tableSubmenu = app.menus.item( '$ID/Main' ).submenus.item('$ID/Table');
		var ptdSubmenu = app.menus.item( '$ID/Main' ).submenus.add('Print to Digital', LocationOptions.AFTER, tableSubmenu);

		_createMenu('Prepare Tables', 'prepare-tables.jsx');
		_createMenu('Prepare Groups', 'prepare-groups.jsx');
		_createMenu('Prepare Selection', 'prepare-selection.jsx');
		_createMenu('Prepare MathML', 'prepare-mathml.jsx');
		_createMenu('Prepare Article', 'create-article.jsx');
		_createMenu('Create Article', 'export-article.jsx');
		_createMenu('Change Config', 'change-config.jsx');

//		var destroyAction = app.scriptMenuActions.add('Destroy');
//		destroyAction.eventListeners.add('onInvoke', destroy);
//		ptdSubmenu.menuItems.add(destroyAction);


		function destroy(){
			while(_actions.length>0)
				_actions.shift().eventListeners.everyItem().remove();
			ptdSubmenu.remove();
			ptdStartup = null;
		}

		return {
			destroy: destroy
		}
	})();