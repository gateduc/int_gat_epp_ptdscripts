# Print To Digital Script - Moderna

## Version

- 1.4.3

## Changes

### 1.1.1
- Initial Update
- Updated ptd-config-sample.jsx for reference

### 1.1.2
- Added support for DOUBLE_LEFT_QUOTE and ELLIPSIS_CHARACTER (three dots) special characters
- Bug fixes and better support for bulleted items that are not "InDesign" bulleted items.

### 1.1.3
- Added support for other special characters like DOUBLE_RIGHT_QUOTE (PS-5623/PS-5615)
- Solved bug caused by inline graphics in bulleted line objects (PS-5619)

### 1.1.4
- Solved an issue where if an image is on two pages, it would become larger than 100% size. Now defaults to 100% if too large.
- Speed improvements on creating articles.
- Fix font color bug
- Temporary fix for MathML Issues causing delays (PS-5619)

### 1.1.5
- Enabled MathML fix.

### 1.2.1
- Added Styled Boxes,
    - Usage for config.jsx
    ```javascript
    	styledBox: {
		"BOX_BODY_06-box-titulo-para-saber-mais":{
			style: "_option2"
		},
		"BOX_BODY_06-box-texto-para-saber-mais":{
			style: "_option2"
		},
	},
    ```
	- Styled boxes consist of a paragraph style mapping to an option, as seen in this example. Those styles will then be mapped and placed into styled containers (boxes).
- Fixed MathML in containers (some style changes in the digital editor are still required)(PS-5632)
- Fixed Prepare MathML styling issue (zendesk ticket #133216)

### 1.2.2
- Support for list-items inside of Styled Boxes
- Support for InDesign type of footnotes, including superscript numbers
- MathML improvements
- Fixed inheritance problem with paragraph styles being extended to mathml objects
- PTD support for new MathML component set.
	- Important: You need to update the config.jsx to have the following mathComponent.
	```javascript
	mathComponent: {
		definition: {
			"content": {
				"html": ""
			},
			"id": "",
			"data": {
				"mathml-html-data": ""
			},

			"identifier": "mathml",
			"styles": {}
		}
	},
	```

### 1.2.3
- Fixes for styled boxes
- Changes to how containers are inline. An Inline property is added. It is important that the component set be updated to reflect those changes.
- Numbered-List workaround for ticket #133645 (See the changed needed in PS-5658)
	- Important: the component set and config.jsx needs to be updated before this version of PTD script can be used.
	- An example of the config.jsx update for numbered-lists can be seen here.
	```javascript
			"Example Paragraph Style": { 
			definition: { 
				"content": {},
				"id": "",
				"identifier": "numbered-list", 
				"styles": {},
				"containers": {
					"main": []
				},
				"data":{
					"start":""
				}
			},
			containerName: "main", 
		},
		```

### 1.2.4
- Quick fix for layout Supercao_Mathmatica where inline images that are OVERSET will crash the script.

### 1.2.5
- It is important the ptf-configs are updated before using this version.
- Fix for the Digital article not inheriting issue from the Layout (ticket 134508)
- Fix for footnotes repeating by resetting the running list of footnotes after each successfully placement.
- Fixed support for Inline objects for collapsible boxes
- Fix for styled boxes
- Additional changes to support starting numbers for alphabetical and roman numeral lists (see ticket #133645, Jira PS-5658)
	- It is important the componentset is updated to support. See this example,
```javascript
        "name": "upperletters-list",
        "icon": "icons/components/upperletters-list.svg",
        "selectionMethod": "handle",
        "label": "Upper-letters list",
        "properties": [
            "style",
            "position",
            "background-color",
            "start"
        ],````

- It is important the ptf-configs are updated with the following changes. You can see a full example of the lists in the gitlab config.jsx.
- we add the data, start value to ALL types of lists like so,
	````javascript
		"lowerletters-list-style": { //Paragraph style
			definition: { // Container definition 
				"content": {},
				"id": "",
				"identifier": "lowerletters-list",
				"styles": {},
				"containers": {
					"main": []
				},
				"data":{
					"start":""
				}
			},
			containerName: "main", //Container field in the container definition
		},````
```
### 1.2.6
- Redesign, and fixes for Styled Boxes

### 1.2.7
- Small fixes for Styled Boxes

### 1.2.8
- Footnote Asterisks support (Jira ticket #PS-5746)
- Prepare Mathml nested styling fix (Zendesk Ticket #135351)
- Collapsible Box, coloring and mathml fixes (Zendesk Ticket #134894)

### 1.2.9
- Fixes to parentTextBox error (Jira Ticket #PS-5766)
- Fixes to plain containers

### 1.2.10
- Color of items no longer creates extra swatches in the InDesign document

### 1.2.11
- Small list-item numbering fix

### 1.2.12
- Better support for list items in collapsible boxes

### 1.2.13
- Text fix for crosshead like components.

### 1.2.14
- Fix for collapsible boxes where list items are the first item.

### 1.2.15
- fixes for collapsible boxes
- fixes for containers in collapsible boxes
- fixes for list-items being empty

### 1.3.1
- Support for styled boxes in collapsible boxes
	-including list-items in styled boxes, which are in collapsible boxes
- fixes for MathML items in list-items
- Fixes for starting number of list-items that are inside styled boxes

### 1.3.2
- Fixed a container Issue

### 1.3.3
- added "display=block" setting for MathML objects.

### 1.3.4
- MathML was not being placed in bulleted Items (but already was for all other lists)
- Containers with inline images were not set to inline properly, this is fixed in version 1.3.3.

### 1.3.5
- 'Starting number' field blank has been fixed. 

### 1.3.6
- Test fix for extra MathML display's being made. 

### 1.3.7
- Fix for problem found by WWDS (PS-5996)

### 1.3.8
- Added a warning and catch for if graphics that do not have links are added as inline images.

### 1.3.9
- Small patch for image descriptions
- Fix for WWDS program regarding crashing due to image links.

### 1.3.10
- Provided small change to avoid "menu bar disappearing" issue.

### 1.3.11
- Fixed duplicate component issue
- Fixed PS-6331 causing crash errors

### 1.3.12
- Important performance tests for the prepare MathML Script.
- fix for ticket GATZEN #1561

### 1.3.13
- Cancel on the prepare dialog should now work.

### 1.3.14
- Quick fix for image bug

### 1.3.15
- fix regarding MathML Link search to address crashing bug.

### 1.3.16
- fix a naming error introduced in version 1.3.12 causing mathml images to not be found when looking them up on the layout.

### 1.3.17
- fix a rare error caused by special paragraph styles

### 1.3.18
- reduced the character size of mathml image names.

### 1.3.19
- added support for Student Collapsible Boxes

### 1.3.20
- quick fix for footnote paragraph style bug.

### 1.3.21
- quick fix for prepare script testing.

### 1.3.22
- another fix regarding the prepare script

### 1.4.0
- New feature: Changing ptd-config files
	- A new option has been added to the drop down menu titled Change Config. This allows the user to switch effortlessly between ptd-config.jsx files.
	- Note: There should always be a single default ptd-config.jsx file titled ptd-config.jsx, as a backup.
	- All other ptd-config.jsx files can have different names, such as, ptd-config-Geography.jsx. However the file must end in the file extension .jsx
	- A new ptd-startup.jsx found in this update needs to be copied to the "startup scripts" folder inside of the InDesign scripts folder.

### 1.4.1
- Bugfix: crashing on selecting a config file possibly fixed.

### 1.4.2
- Support for two additional collapsible boxes

### 1.4.3
- Support for any type of collapsible box headers