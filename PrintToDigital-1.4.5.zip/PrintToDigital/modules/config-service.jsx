/**
 * @description Configuration service - encapsulates configuration file and provides minimal default configuration
 *
 * @copyright WoodWing Software B.V. All rights reserved.
 */

if(forceInit || typeof $.global.ConfigService === 'undefined') {

#include 'err.jsx'
#include '_.jsx'
#include "../ptd-config.jsx"

var ConfigService = function(_, Err) {
	'use strict';

	var config = null;
	var defaultConfig = {
		includeErrorDetail: false,
		exportDPSContent: false,

		textFilter: 'paragraphStyleName',
		textFilterList: {
			title: [],
			subtitle: [],
			author: [],
			intro: [],
			quote: [],
			body: [],
			footer: []
		},		
		imageComponent: {
			//Base json of the image component
			definition: {
				"content": {
                    "image": {
                        "id": "",
                        "focuspoint": {
                            "x": 0.5,
                            "y": 0.5
                        },
                        "cropper": false
                    },
                    "caption": []
                },
                "id": "",
                "identifier": "image",
                "styles": {
				}
			},
	
			//List of the text filters of the image component as configured in textFilterList
			textFilters: [
				"caption"
			]
		},		
		styles: {
			paragraph: {
			},
			character: {
			},
			font: {
			}
		},
		output: {
			htmlTags: {
				bold: {
					tag: "b"
				},
				italic: {
					tag: "i"
				}
			},
			htmlEncode: [
				['\n', ''],
				['\r', '']
			],
			cleanHyphenation: false
		},
		exportDirectory: '~/Desktop/ptd-indesign-export',
		logging: {
			directory: '~/Desktop/ptd-indesign-export',
			level: 'INFO',
            wipe:false // when true, wipe contents before each script execution
		},
		version: '1.0.31'
	};

	function _getGlobalConfig() {
		// Load the global configuration
		var currentPath = File($.fileName).path.slice(0, -7);
		var configFile = new File(currentPath + "/selected-ptd.txt");
		configFile.encoding = 'UTF-8';
		configFile.open('r');
		var newConfig = configFile.read();
		configFile.close();

		if (newConfig) {
			if (typeof ptdConfig === 'undefined')
				throw new Err.ConfigurationError('No configuration', $.fileName, $.line);
			var configFileCheck = new File(currentPath + "/" + newConfig);
			if (configFileCheck.exists) {
				eval("#include '" + newConfig + "'");
			} else {
				eval("#include 'ptd-config.jsx'");
			}
		}

		return ptdConfig;
	}
	/**
	 * Combine the default config with the provided config if not cached
	 * @throws ConfigurationError
	 */
	function getConfig() {
		if(!config) {
            loadConfig();
		}		
		return config;
	}

	/**
	 * Loads the config. Can be used to force reloading the cached config
	 * @throws ConfigurationError
	 */
	function loadConfig() {
        // Validate and retrieve the global configuration
        var globalConfig = _getGlobalConfig();

        // Use the default as base and mixin missing settings from the provided
        config = _.mixin(defaultConfig, globalConfig );
	}

	// Public API
	return {
		getConfig: getConfig,
		loadConfig: loadConfig
	}
}(_, Err);
}
