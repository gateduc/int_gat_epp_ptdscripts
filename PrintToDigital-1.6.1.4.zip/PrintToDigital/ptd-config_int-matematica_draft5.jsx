/**
 * @description Configuration file for creation and export to Ptd
 * 
 * Collection: Interacao
 * Discipline: Matematica
 * 
 * PTD Config Version: Draft 5
 * Look n Feel Version: Draft 5
 * PTD Script Version: 1.6.1.2
 * Component Set Version: 1.6.0
 *
 * @copyright WoodWing Software B.V. All rights reserved.
 */
 $.global.ptdConfig = {

	// Filter text based on paragraph style name. For now the only option.
	textFilter: 'paragraphStyleName',
	// Object with all digital article component types. Each type has an array of style names that will be used
	// to define the type. Style names can be either strings or regular expressions (in string form)
	// By default the text is placed in the text field of the component, to override this behavior add "." and the field name, for example subtitle.title
	// To use a specfic digitalComponentStyleOptions add a "#" and the name of the digitalComponentStyleOptions, for example title#option1_red or subtitle.title#option2_blue	

	//This is print to digital configuration script for Grandes Autores - Matemática Bianchini

	textFilterList: {
		"titleh1": [
			"10_TITLEH1_finais_secao_titulo",
		],
		"titleh1#Option1": [
			"03_TITLEWICONH1_unid_titulo_abre",
		],
		"titleh1#Option2": [
			"04_TITLEH1_partes",
		],
		"titleh2": [
			
		],
		"titleh2#Option1": [
			"03_TITLEH2_unid_titulo_abre_LM",
		],
		"titleh2#Option2": [
			"03_TITLEWICONH2_cap_titulo_abre",
		],
		"titleh2#Option3": [
			"03_TITLEH2_titulo_LM",
		],
		"titleh3": [
			
		],
		"titleh3#Option1": [
			"06_TITLEH3_secao_retomar",
		],
		"titleh3#Option2": [
			"04_TITLEH3_cap_p1",
		],
		"titleh3#Option3": [
			"06_TITLEH3_infografico",
		],
		"titleh3#Option4": [
			"04_TITLEH3_cap_p2_LM",
		],
		"titleh3#Option5": [
			"06_TITLEH3_secao_conexoes",
		],
		"titleh3#Option6": [
			"04_TITLEH3_titulo_LM",
		],
		"titleh4": [
			"04_TITLEH4_cap_p2",
		],
		"titleh4#Option1": [
			"04_TITLEH4_cap_p3_LM",
		],
		"titleh4#Option2": [
			"04_TITLEH4_cap_p2_LM",
		],
		"titleh5": [
			"04_TITLEH5_cap_p4_LM",
		],
		"titleh5#Option1": [
			
		],
		"titleh5#Option2": [
		],
		"titleh5#Option3": [
		],
		"titleh5#Option4": [
		],
		"titleh5#Option5": [
		],
		"titleh5#Option6": [
		],
		"titleh5#Option7": [
		],
		"titleh5#Option8": [
		],
		"titleh5#Option9": [
		],
		"titleh5#Option10": [
		],
		"titleh6": [
		],
		"titleh6#Option1": [
		],
		"titleh6#Option2": [
		],
		"titleh6#Option3": [
		],
		"titleh6#Option4": [
		],
		"titleh6#Option5": [
		],
		"titleh6#Option6": [
		],
		"titleh6#Option7": [
		],
		"titleh6#Option8": [
		],
		"subtitle": [ 
			"02_CROSS_sum_titulo_finais_p1",
		],
		"subtitle#Option1": [
			"03_CROSS_unid_titulo_l1",
		],
		"subtitle#Option2": [
			"05_BOXCROSS_boxe_t2_titulo",
		],
		"subtitle#Option3": [
			"01_CROSS_iniciais_titulo_p3",
		],
		"subtitle#Option4": [
			"04_CROSS_projeto_p4",
		],
		"subtitle#Option5": [
			"04_CROSS_cap_titulo_p4",
		],
		"subtitle#Option6": [],
		"subtitle#Option7": [
			"05_BOXCROSS_boxe_bncc_mat_titulo",
		],
		"subtitle#Option8": [
			"04_CROSS_cap_titulo_p3",
		],
		"subtitle#Option9": [
			"03_CROSS_unid_mat_titulo_p2",
		],
		"subtitle#Option10": [
			"04_CROSS_projeto_p2",
		],
		"subtitle#Option11": [
			"01_CROSS_conheca_sumario",
		],
		"subtitle#Option12": [
			"05_BOXCROSS_boxe_ficadica_mat_marcador",
		],
		"subtitle#Option13": [
			"04_CROSS_projeto_p1",
		],
		"subtitle#Option14": [
			"01_CROSS_iniciais_titulo_p1",
		],
		"subtitle#Option15": [
			"01_CROSS_iniciais",
		],
		"subtitle#Option16": [
			"07_CROSS_titulo_grafico",
		],
		"subtitle#Option17": [
			"01_CROSS_conheca_titulo_p1",
		],
		"subtitle#Option18": [
			"04_CROSS_cap_titulo_p5",
		],
		"subtitle#Option19": [
			"10_CROSS_gabarito_titulo_paginas",
		],
		"subtitle#Option20": [
			"11_BOXCROSS_marcador_revista_online",
		],
		"subtitle#Option21": [
			"07_CROSS_gravata_mapa_grafico",
		],
		"subtitle#Option22": [
			"11_BOXCROSS_revista_online",
		],
		"subtitle#Option23": [
			"11_BOXCROSS_revista_impressa",
		],
		"subtitle#Option24": [
			
		],
		"subtitle#Option25": [
			"11_BOXCROSS_web_jornal",
			"11_BOXCROSS_jornal",
		],
		"subtitle#Option26": [
			"05_BOXCROSS_boxe_t2_marcador",
		],
		"subtitle#Option27": [ 
			"02_CROSS_sum_unid_titulo_mat",
		],
		"subtitle#Option28": [
			"02_CROSS_topico",
		],
		"subtitle#Option29": [
			"01_CROSS_iniciais_titulo_p2",
		],
		"subtitle#Option30": [
			"05_BOXCROSS_glossario_mat_titulo",
		],
		"subtitle#Option31": [
			"05_BOXCROSS_secao_titulo_l2_LM",
			"04_CROSS_cap_titulo_p5_LM",
			"04_CROSS_cap_titulo_p6_LM",
		],
		"subtitle#Option32": [
			"02_CROSS_sum_cap_titulo_p1_LM",
		],
		"subtitle#Option33": [
			"07_CROSS_gravata_mapa_grafico_LM",
		],
		"subtitle#Option34": [
			"05_BOXCROSS_secao_titulo_LM",
		],
		"subtitle#Option35": [
			"02_CROSS_sum_parte_LM",
		],
		"subtitle#Option36": [
			"04_CROSS_cap_titulo_p4_LM",
		],
		"subtitle#Option37": [
			"01_CROSS_titulo_pagina_iniciais_LM",
		],
		"subtitle#Option38": [
			"05_BOXCROSS_boxe_ficadica_marcador_LM",
		],
		"subtitle#Option39": [
			"05_BOXCROSS_boxe_na_BNCC_LM",
		],
		"subtitle#Option40": [
			"05_BOXCROSS_boxe_objetivos_da_unidade_LM",
		],
		"subtitle#Option41": [
			"05_BOXCROSS_boxe_BNCC_nesta_unidade_LM",
		],
		"subtitle#Option42": [
			"05_BOXCROSS_boxe_para_ampliar_LM",
		],
		"subtitle#Option43": [
			"04_CROSS_cap_titulo_p3_LM",
		],
		"subtitle#Option44": [
			"02_CROSS_cap_titulo_abre",
		],
		"subtitle#Option45": [
			"01_CROSS_titulo_iniciais_LM",
		],
		"subtitle#Option46": [
			"01_CROSS_titulo_sumario_LM",
		],
		"subtitle#Option47": [
			"02_CROSS_sum_cap_titulo_p2_LM",
		],
		"subtitle#Option48": [
			"02_CROSS_sum_cap_titulo_p3_LM",
		],
		"subtitle#Option49": [
			"02_CROSS_sum_cap_titulo_p4_LM",
		],
		"subtitle#Option50": [
			"07_CROSS_numero_letra_imagem_LM",
		],
		"subtitle#Option51": [
			"02_CROSS_sum",
		],
		"subtitle#Option52": [
			"02_CROSS_sum_recuo",
		],
		"subtitle#Option53": [
			"02_CROSS_sum_secao_analise",
		],
		"subtitle#Option54": [
			"03_CROSS_unid_mat_titulo_p1",
		],
		"subtitle#Option55": [
			
		],
		"subtitle#Option56": [
			"05_BOXCROSS_boxe_titulo_questao_disp",
			"05_BOXCROSS_boxe_exerc_pensar_titulo",
		],
		"subtitle#Option57": [
			"05_BOXCROSS_boxe_t2_titulo_simples",
			"05_BOXCROSS_boxe_t2_titulo_destaque",
		],
		"subtitle#Option58": [
			"04_QUOTE_terc_subtitulo_LM",
		],
		"subtitle#Option59": [
			"04_CROSS_cap_titulo_p2_LM",
		],
		"subtitle#Option60": [
			"05_BOXCROSS_boxe_matriz_ref_enem_LM",
		],
		"image.caption": [
			"07_CAPTION_legenda_branca",
			"07_CAPTION_legenda_direita",
			"07_CAPTION_legenda_esquerda",
			"11_BOXCAPTION_legenda_revista_impressa",
			"11_BOXCAPTION_jornal_legenda",
			"04_CROSS_icone_txt",
			"07_CAPTION_legenda_LM",
		],
		"picturecredit": [
			"07_CREDIT_credito",
		],
		"picturecredit#Option1": [
			"07_CREDIT_credito_LM",
		],
		"body": [
			"04_BODY_text_sem_recuo",
			"05_BOXBODY_boxe_txt_lateral_bncc",
			"05_BOXBODY_glossario_verbete",
			"05_BOXBODY_txt_geral_vozes",
			"00_COLLAPBODY_transcricao",
			"05_BOXBODY_boxe_exerc_lateral_pensar",
			"05_BOXBODY_boxe_txt_lateral",
			"05_BOXBODY_boxe_txt_lateral_simples",
			"05_BOXBODY_boxe_txt_lateral_vozes",
			"09_BOXBODY_exerc_resolucao_sem_paragrafo",
		],
		"body#Option1": [
			"05_BOXBODY_boxe_exerc_mat_pensar",
		],
		"body#Option2": [
			"05_BOXBODY_txt_filme_site_livro_mat",
			"10_BODY_txt_referencias",
		],
		"body#Option3": [
			"04_BODY_resposta",
		],
		"body#Option4": [
			"09_BOXBODY_exerc_resolucao_num",
		],
		"body#Option5": [
			"04_BODY_txt_geral_centralizado",
			"05_BOXBODY_txt_geral_centralizado_conceito",
			"05_BOXBODY_txt_geral_centralizado_destaque",
			"07_BODY_cota",
			"07_BODY_cota_branca",
			"07_BODY_lembretes",
			"09_BOXBODY_exerc_resolucao_centralizado",
			"04_BODY_icone_titulo",
		],
		"body#Option6": [],
		"body#Option7": [
			"04_BODY_mapa_conceitual_2",
			"08_TABLE_txt",
			"08_TABLE_txt_centralizado",
			"05_BOXBODY_txt_geral_centralizado_retomar",
		],
		"body#Option8": [
			"11_BOXBODY_TEXT_online_sem_recuo",
		],
		"body#Option9": [
			"11_BOXBODY_subtitulo_revista_online",
		],
		"body#Option10": [
			"11_BOXBODY_subtitulo_revista_impressa",
		],
		"body#Option11": [
			"04_BODY_mapa_conceitual_1",
			"07_CROSS_numero_letra_imagem",
			"08_TABLE_peso1",
			"08_TABLE_peso2",
		],
		"body#Option12": [],
		"body#Option13": [],
		"body#Option14": [
			"03_BOXBODY_boxe_unid_titulo_l2",
		],
		"body#Option15": [],
		"body#Option16": [
			"07_CROSS_gravata_mapa",
		],
		"body#Option17": [],
		"body#Option18": [
			"04_BODY_olho",
		],
		"body#Option19": [
			"11_BOX_intertitulo_revista_impressa",
			"11_BOXBODY_intertitulo_revista_impressa",
			"11_BOXBODY_intertitulo_revista_online",
		],
		"body#Option20": [
			"11_BOXBODY_web_jornal_subtitulo",
		],
		"body#Option21": [
			"11_BOXBODY_online_legenda",
			"11_BOXBODY_TEXT_revista_online",
			"05_BOXQUOTE_terc_txt_explorar",
			"09_QUOTE_terc_txt_retomar",
			"09_QUOTE_terc_txt_poesia_retomar",
		],
		"body#Option22": [
			"11_BOXBODY_TEXT_revista_impressa",
			"11_QUOTE_BODY_web_jornal",
			"04_QUOTE_terc_txt",
			"11_BOXBODY_web_jornal",
		],
		"body#Option23": [
			"03_BODY_unid_texto",
		],
		"body#Option24": [],
		"body#Option25": [],
		"body#Option26": [],
		"body#Option27": [
			"10_BODY_referencias_comentarios",
		],
		"body#Option28": [
			"11_BOXBODY_online_comentario_titulo",
		],
		"body#Option29": [
			"04_BODY_mapa_conceitual_1_LM",
			"04_BODY_mapa_conceitual_2_LM",
			"04_BODY_text_sem_recuo_LM",
			"04_BODY_txt_quimica_LM",
			"05_BOXBODY_txt_competencias_LM",
			"05_BOXBODY_txt_sem_recuo_LM",
			"07_BODY_cota_LM",
			"07_BODY_lembretes_LM",
			"08_TABLE_txt_LM",
			"10_BODY_txt_referencias_LM",
		],
		"body#Option30": [
			"04_BODY_resposta_LM",
			"01_CROSS_txt_iniciais_LM",
			"04_BODY_txt_geral_LM",
			"05_BOXBODY_boxe_txt_para_ampliar_LM",
			"05_BOXBODY_txt_boxe_destaque_LM",
		],
		"body#Option31": [
			"10_BODY_referencias_comentarios_LM",
		],
		"body#Option32": [
			"04_BODY_txt_geral_centralizado_LM",
			"05_BOXBODY_txt_centralizado_boxe_destaque_LM",
			"08_TABLE_txt_centralizado_LM",
		],
		"body#Option33": [
			"07_BODY_cota_branca_LM",
		],
		"body#Option34": [
			"08_TABLE_peso1_LM",
			"08_TABLE_peso2_LM",
		],
		"body#Option35": [
			"07_BODY_fonte",
			"07_BODY_fonte_esquerda",
		],
		"body#Option36": [
			"05_BOXQUOTE_terc_txt_simples",
		],
		"body#Option37": [
			"05_BOXQUOTE_terc_txt_destaque",
		],
		"body#Option38": [],
		"body#Option39": [
			"04_QUOTE_terc_chamada",
		],
		"body#Option40": [
			"04_QUOTE_terc_subtitulo",
		],
		"body#Option41": [
			"01_BODY_conheca_txt",
		],
		"body#Option42": [
			"04_BODY_txt_geral",
			"05_BOXBODY_txt_pre_exercicio_explorar",
			"05_BOXBODY_txt_geral_explorar",
			"05_BOXBODY_txt_geral_conceito",
			"05_BOXBODY_txt_geral_retomar",
			"05_BOXBODY_txt_geral_simples",
			"05_BOXBODY_txt_geral_destaque",
			"05_BOXBODY_exerc_contin_explorar",
		],
		"body#Option43": [
			"09_BOXBODY_exerc_resolucao",
		],
		"body#Option44": [
			"09_BODY_exerc_mat_contin_retomar",
			"11_BOXBODY_email_cabecalho",
			"00_BODY_expediente",
		],
		"body#Option45": [
			"11_BOXBODY_generos_sem_recuo",
			"04_QUOTE_terc_txt_poesia",
		],
		"body#Option46": [],
		"body#Option47": [
			"11_BOXBODY_jornal_intertitulo",
		],
		"body#Option48": [
			"11_BOXBODY_online_comentario_nome",
		],
		"body#Option49": [
			"05_BOXBODY_txt_geral_centralizado_simples",
		],
		"body#Option50": [
			"05_BOXBODY_txt_geral_centralizado_explorar",
		],
		"body#Option51": [
			"01_CROSS_conheca_titulo_p2",
		],
		"body#Option52": [
			"09_BODY_exerc_mat_contin",
		],
		"body#Option53": [
			"04_BODY_icone_txt",
		],
		"body#Option54": [
			"05_BOXBODY_fonte_LM",
			"07_BODY_fonte_LM",
		],
		"body#Option55": [
			"04_QUOTE_terc_txt_LM",
		],
		"body#Option56": [
			"04_QUOTE_terc_txt_com_recuo_LM",
			"04_QUOTE_terc_txt_sem_recuo_LM",
			"04_QUOTE_terc_txt_resposta_LM",
		],
		"body#Option57": [
			"04_BODY_resposta_abc_cont_LM",
			"04_BODY_resposta_numerada_cont_LM",
		],
		"body#Option58": [
			"05_BOXBODY_boxe_txt_objetivos_LM",
		],
		"body#Option59": [
			"04_BODY_genero_textual_fonte",
		],
		"body#Footnote": [
			"07_BODY_rodape",
			"07_BODY_rodape_fio",
			"04_BODY_txt_rodape_LM"
		],
		"bodylist": [
			"05_BOXBODY_txt_geral_questao_disparadora",
			"09_BODY_gabarito_exercicio_l1",
			"04_LISTNUM_txt_geral_numerado",
			"05_BOXLISTBULL_boxe_lateral_bullet_simples",
			"05_BOXLISTNUM_boxe_exerc_lateral_pensar",
			"09_BODY_exerc_bullet_l1",
			"09_BODY_exerc_bullet_l1_retomar",
			"09_BOXBODY_bullet_exerc_resolucao_l1",
			"09_LISTROMAN_exerc_item_romano",
			"09_LISTROMAN_exerc_item_romano_retomar",
			"00_COLLAPBODY_enunciado_atv_adaptada",
		],
		"bodylist#Option1": [
			"09_BODY_exerc_abc_bullet",
			"09_BODY_exerc_abc_bullet_retomar",
			"09_LISTABC_exerc_abc_contin",
			"09_LISTABC_exerc_abc_contin_retomar",
			"00_COLLAPBODY_abc_atv_adaptada",
		],
		"bodylist#Option2": [
			"04_LISTBULLET_txt_geral_l3",
			"00_COLLAPBODY_bullet_atv_adaptada",
		],
		"bodylist#Option3": [
			"08_TABLELISTNUM_txt_numerado",
			"08_TABLELISTBULLET_txt_bullet_level1",
			"03_LISTBULL_unid_enunciado_bullet",
		],
		"bodylist#Option4": [],
		"bodylist#Option5": [],
		"bodylist#Option6": [
			"04_QUOTELIST_terc_txt_numerado",
			"04_QUOTELISTBULL_terc_bullet_l1",
			"09_QUOTELIST_terc_txt_numerado_retomar",
		],
		"bodylist#Option7": [
			"09_QUOTELISTBULL_terc_bullet_l1_retomar",
		],
		"bodylist#Option9": [	
			"04_BODY_bullet_unico_txt_geral_l1_LM",
			"04_LISTBULLET_txt_geral_l1_LM",
			"04_LISTNUM_txt_geral_numerado_LM",
			"05_BODY_bullet_unico_box_objetivos_LM",
			"05_BODY_bullet_unico_box_para_ampliar_LM",
			"05_BOXLISTBULL_boxe_bullet_objetivos_LM",
			"05_BOXLISTBULL_boxe_bullet_para_ampliar_LM",
			"08_BODY_txt_tabela_bullet_unico_level1_LM",
			"08_BODY_txt_tabela_numerado_LM",
			"08_TABLELISTBULLET_txt_bullet_level1_LM",
			"08_TABLELISTNUM_txt_abc_tabela_LM",
			"04_BODY_txt_geral_numerado_LM",
			"04_LISTBULLET_resposta_bullet_l1_LM",
			"04_BODY_resposta_bullet_unico_l1_LM",
			"04_BODY_resposta_numerada_LM",
		],
		"bodylist#Option10": [
			"04_LISTBULLET_txt_geral_l2_LM",
			"04_LISTNUM_txt_geral_abc_LM",
			"09_LISTABC_exerc_item_abc_l1_LM",
			"04_BODY_resposta_abc_LM",
			"04_BODY_resposta_recuo_abc_LM",
			"04_LISTBULLET_resposta_numerada_bullet_l1_LM",
			"04_LISTROMAN_resposta_romano_LM",
		],
		"bodylist#Option11": [
			"04_LISTBULLET_resposta_abc_bullet_l1_LM",
			"04_BODY_resposta_abc_bullet_unico_l1_LM",
		],
		"bodylist#Option12": [
			"04_QUOTE_terc_bullet_unico_l1_LM",
			"04_QUOTELISTBULL_terc_bullet_l1_LM",
			"04_QUOTELISTNUM_terc_txt_numerado_123_LM",
		],
		"bodylist#Option13": [],
		"bodylist#Option14": [],
		"bodylist#Option15": [
			"03_BOXLISTBULLET_nesta_unidade_l1",
			"04_LISTBULLET_txt_geral_l1",
			"04_LISTBULLET_projeto",
			"09_BOXLISTBULLET_exerc_resolucao_l1",
			"05_BOXBODY_exerc_bullet_l1_explorar",
			"05_BOXLISTBULL_txt_bullet_l1_conceito",
			"05_BOXLISTNUM_boxe_exerc_mat_pensar",
			"05_BOXLISTBULL_txt_bullet_l1_destaque",
			"05_BOXLISTBULL_txt_bullet_l1_simples",
			"05_BOXLISTBULL_txt_bullet_l1_retomar",
			"05_BOXBODY_exerc_mat_explorar",
			"09_BODY_exerc_mat",
			"09_BODY_secao_exerc_retomar",
		],
		"bodylist#Option16": [
			"09_BODY_exerc_abc_l1_retomar",
			"09_BODY_exerc_abc_l1",
			"04_LISTBULLET_txt_geral_l2",
			"05_BOXLISTBULL_txt_bullet_l2_conceito",
			"05_BOXBODY_exerc_abc_l1_explorar",
			"09_BODY_gabarito_exercicio_l2",
		],
		"bodylist#Option17": [],
		"bodylist#Option18": [
			"09_BOXLISTNUM_exerc_resolucao_num",
			"05_BOXLISTNUM_exerc_mat_infografico",	
			"05_BOXLISTBULL_txt_bullet_l1_explorar",
		],
		"bodylist#Option19": [],
		"bodylist#Option20": [],
		"bodylist#Option21": [
			"03_LISTNUM_unid_enunciado_123",
		],
		"bodylist#Option22": [],
		"bodylist#Option23": [],
		"footer": [],
		"crosshead": [
		],
		"crosshead#Option1": [
			"11_BOXCROSS_marcador_revista_impressa",
		],
		"crosshead#Option2": [
			"11_BOXCROSS_marcador_jornal_online",
			"11_BOXCROSS_marcador_jornal",
		],
		"crosshead#Option3": [],
		"unmaptext": [
			"/^.*/",
			"[Basic Paragraph]",
			"[No Paragraph Style]",
		],
		"list-item": [
		],
		"list-item#Option13": [
		],
		"list-item#Option16": [
		],
		"list-item#Option26": [
		],
		"titlewi": [
			"05_BOXBODYWICON_boxe_retomar_marcador",
		],
		"titlewi#Option1": [
			"05_BOXBODYWICON_boxe_vozes_marcador",
		],
		"titlewi#Option2": [
			"06_BODYWICON_secao_marcador_ativ_resolvidas",
		],
		"titlewi#Option3": [
			"06_BODYWICON_secao_marcador_ativ",
		],
		"titlewi#Option4": [
			"04_BODYWICON_cap_titulo_p1_LM",
		],
		"titlewih1": [
		],
		"titlewih2": [
			"04_TITLEWICONH2_cap_p1_LM",
		],
		"titlewih3": [
			"06_TITLEWICONH3_secao_analise",
		],
		"titlewih3#Option1": [
			"06_TITLEWICONH3_secao_ativ_finais",
		],
		"titlewih3#Option2": [
			"04_TITLEWICONH3_cap_p1_LM",
		],
		"titlewih3#Option3": [
			"03_TITLEWICONH3_cap_titulo_abre_LM",
		],
		"titlewih4": [
		],
		"titlewih5": [
		],
		"titlewih6": [
		],
		"titlewithimage": [
		],
		"titlewithimage#Option1": [
		],
		"quotewithheader.header": [
			"05_BOXQUOTE_terc_titulo_simples",
			"05_BOXQUOTE_terc_titulo_destaque",
		],
		"quote.author": [
			"05_BOXQUOTE_terc_fonte_simples",
			"05_BOXQUOTE_terc_fonte_destaque",
		],
		"quotewithheader.header#Option1": [
			"05_BOXQUOTE_terc_titulo_explorar",
		],
		"quote.author#Option1": [
			"05_BOXQUOTE_terc_fonte_explorar",
		],
		"quotewithheader.header#Option2": [
			"09_QUOTE_terc_titulo_retomar",
			"04_QUOTE_terc_titulo",
		],
		"quote.author#Option2": [
			"09_QUOTE_terc_fonte_retomar",
			"04_QUOTE_terc_fonte",
		],
		"quotewithheader.header#Option3": [
			"04_QUOTE_terc_titulo_LM",
		],
		"quote.author#Option3": [
			"04_QUOTE_terc_fonte_LM",
		],
	},

	styledBox: {
		"05_BOXCROSS_boxe_t2_titulo_destaque": {
			style: "_option7"
		},
		"05_BOXQUOTE_terc_titulo_destaque": {
			style: "_option7"
		},
		"05_BOXQUOTE_terc_txt_destaque": {
			style: "_option7"
		},
		"05_BOXBODY_txt_geral_destaque": {
			style: "_option7"
		},
		"05_BOXLISTBULL_txt_bullet_l1_destaque": {
			style: "_option7"
		},
		"05_BOXQUOTE_terc_fonte_destaque": {
			style: "_option7"
		},
		"05_BOXBODY_txt_geral_centralizado_destaque": {
			style: "_option7"
		},
		"05_BOXLISTBULL_txt_bullet_l1_conceito": {
			style: "_option8"
		},
		"05_BOXBODY_txt_filme_site_livro_mat": {
			style: "_option8"
		},
		"05_BOXBODY_txt_geral_conceito": {
			style: "_option8"
		},
		"05_BOXBODY_txt_geral_centralizado_conceito": {
			style: "_option8"
		},
		"05_BOXLISTBULL_txt_bullet_l2_conceito": {
			style: "_option8"
		},
		"05_BOXCROSS_boxe_ficadica_mat_marcador": {
			style: "_option8"
		},
		"09_BODY_secao_exerc_retomar": {
			style: "_option9"
		},
		"09_BODY_exerc_abc_l1_retomar": {
			style: "_option9"
		},
		"09_BODY_exerc_mat_contin_retomar": {
			style: "_option9"
		},
		"11_BOX_intertitulo_revista_impressa": {
			style: "_option10"
		},
		"11_BOXBODY_intertitulo_revista_impressa": {
			style: "_option10"
		},
		"11_BOXBODY_subtitulo_revista_impressa": {
			style: "_option10"
		},
		"11_BOXBODY_TEXT_revista_impressa": {
			style: "_option10"
		},
		"11_BOXCROSS_revista_impressa": {
			style: "_option10"
		},
		"11_BOXCAPTION_legenda_revista_impressa": {
			style: "_option10"
		},
		"11_BOXCROSS_marcador_revista_impressa": {
			style: "_option10"
		},
		"05_BOXBODYWICON_boxe_vozes_marcador": {
			style: "_option11"
		},
		"05_BOXBODY_boxe_exerc_mat_pensar": {
			style: "_option11"
		},
		"05_BOXBODY_boxe_txt_lateral_bncc": {
			style: "_option11"
		},
		"05_BOXBODY_txt_geral_vozes": {
			style: "_option11"
		},
		"05_BOXCROSS_boxe_bncc_mat_titulo": {
			style: "_option11"
		},
		"05_BOXCROSS_boxe_exerc_pensar_titulo": {
			style: "_option11"
		},
		"05_BOXLISTNUM_boxe_exerc_mat_pensar": {
			style: "_option11"
		},
		"05_BOXBODY_exerc_abc_l1_explorar": {
			style: "_option12"
		},
		"05_BOXBODY_exerc_bullet_l1_explorar": {
			style: "_option12"
		},
		"05_BOXBODY_exerc_contin_explorar": {
			style: "_option12"
		},
		"05_BOXBODY_exerc_mat_explorar": {
			style: "_option12"
		},
		"05_BOXBODY_txt_geral_centralizado_explorar": {
			style: "_option12"
		},
		"05_BOXBODY_txt_geral_explorar": {
			style: "_option12"
		},
		"05_BOXBODY_txt_pre_exercicio_explorar": {
			style: "_option12"
		},
		"05_BOXQUOTE_terc_fonte_explorar": {
			style: "_option12"
		},
		"05_BOXQUOTE_terc_titulo_explorar": {
			style: "_option12"
		},
		"05_BOXQUOTE_terc_txt_explorar": {
			style: "_option12"
		},
		"05_BOXLISTBULL_txt_bullet_l1_explorar": {
			style: "_option12"
		},
		"05_BOXCROSS_boxe_t2_marcador": {
			style: "_option12"
		},
		"05_BOXCROSS_boxe_t2_titulo_simples": {
			style: "_option13"
		},
		"05_BOXCROSS_boxe_titulo_questao_disp": {
			style: "_option13"
		},
		"05_BOXCROSS_glossario_mat_titulo": {
			style: "_option13"
		},
		"05_BOXLISTBULL_txt_bullet_l1_simples": {
			style: "_option13"
		},
		"05_BOXBODY_txt_geral_centralizado_simples": {
			style: "_option13"
		},
		"05_BOXQUOTE_terc_titulo_simples": {
			style: "_option13"
		},
		"05_BOXQUOTE_terc_txt_simples": {
			style: "_option13"
		},
		"05_BOXQUOTE_terc_fonte_simples": {
			style: "_option13"
		},
		"05_BOXBODY_glossario_verbete": {
			style: "_option13"
		},
		"05_BOXBODY_txt_geral_questao_disparadora": {
			style: "_option13"
		},
		"05_BOXBODY_txt_geral_simples": {
			style: "_option13"
		},
		"05_BOXBODY_txt_geral_retomar": {
			style: "_option16"
		},
		"05_BOXBODY_txt_geral_centralizado_retomar": {
			style: "_option16"
		},
		"05_BOXLISTBULL_txt_bullet_l1_retomar": {
			style: "_option16"
		},
		"11_BOXBODY_email_cabecalho": {
			style: "_option17"
		},
		"11_BOXBODY_generos_sem_recuo": {
			style: "_option17"
		},
		"11_BOXBODY_intertitulo_revista_online": {
			style: "_option17"
		},
		"11_BOXBODY_jornal_intertitulo": {
			style: "_option17"
		},
		"11_BOXBODY_online_comentario_nome": {
			style: "_option17"
		},
		"11_BOXBODY_online_comentario_titulo": {
			style: "_option17"
		},
		"11_BOXBODY_online_legenda": {
			style: "_option17"
		},
		"11_BOXBODY_subtitulo_revista_online": {
			style: "_option17"
		},
		"11_BOXBODY_TEXT_revista_online": {
			style: "_option17"
		},
		"11_BOXBODY_web_jornal": {
			style: "_option17"
		},
		"11_BOXBODY_web_jornal_subtitulo": {
			style: "_option17"
		},
		"11_BOXCROSS_web_jornal": {
			style: "_option17"
		},
		"11_BOXCROSS_jornal": {
			style: "_option17"
		},
		"11_BOXCROSS_marcador_jornal_online": {
			style: "_option17"
		},
		"11_BOXCROSS_marcador_jornal": {
			style: "_option17"
		},
		"11_BOXCROSS_revista_online": {
			style: "_option17"
		},
		"11_BOXCROSS_marcador_revista_online": {
			style: "_option17"
		},
		"11_BOXBODY_TEXT_online_sem_recuo": {
			style: "_option17"
		},
		"09_BOXBODY_exerc_resolucao_num": {
			style: "_option19"
		},
		"03_BOXBODY_boxe_unid_titulo_l2": {
			style: "_option20"
		},
		"03_BOXLISTBULLET_nesta_unidade_l1": {
			style: "_option20"
		},
		"05_BOXLISTNUM_exerc_mat_infografico": {
			style: "_option21"
		},
		"03_LISTNUM_unid_enunciado_123": {
			style: "_option22"
		},
		"09_BOXBODY_exerc_resolucao_sem_paragrafo": {
			style: "_option23"
		},
		"07_BODY_lembretes": {
			style: "_option25"
		},
		"05_BODY_bullet_unico_box_objetivos_LM": {
			style: "_option27"
		},
		"05_BOXBODY_boxe_txt_objetivos_LM": {
			style: "_option27"
		},
		"05_BOXLISTBULL_boxe_bullet_objetivos_LM": {
			style: "_option27"
		},
		"05_BODY_bullet_unico_box_para_ampliar_LM": {
			style: "_option28"
		},
		"05_BOXBODY_boxe_txt_para_ampliar_LM": {
			style: "_option28"
		},
		"05_BOXLISTBULL_boxe_bullet_para_ampliar_LM": {
			style: "_option28"
		},
		"05_BOXCROSS_boxe_para_ampliar_LM": {
			style: "_option28"
		},
		"05_BOXBODY_txt_boxe_destaque_LM": {
			style: "_option29"
		},
		"05_BOXBODY_txt_centralizado_boxe_destaque_LM": {
			style: "_option29"
		},
		"07_BODY_cota_branca_LM": {
			style: "_option30"
		},
		"05_BOXBODY_txt_competencias_LM": {
			style: "_option31"
		},
		"05_BOXBODY_txt_sem_recuo_LM": {
			style: "_option32"
		},
		"05_BOXCROSS_boxe_matriz_ref_enem_LM": {
			style: "_option32"
		},
		"05_BOXCROSS_boxe_na_BNCC_LM": {
			style: "_option32"
		},
		"07_BODY_lembretes_LM": {
			style: "_option33"
		},
		"04_TITLEH1_partes": {
			style: "_option34"
		},
		"09_BOXBODY_bullet_exerc_resolucao_l1": {
			style: "_option35"
		},
		"09_BOXBODY_exerc_resolucao": {
			style: "_option35"
		},
		"09_BOXLISTNUM_exerc_resolucao_num": {
				style: "_option35"
			},
		"09_BOXLISTBULLET_exerc_resolucao_l1": {
			style: "_option35"
		},
		"09_BOXBODY_exerc_resolucao_centralizado": {
			style: "_option35"
		},
	},

	summaryContainers: {
		"02_CROSS_topico": {
			style: "_option36"
		},
		"02_CROSS_sum": {
			style: "_option37"
		},
		"02_CROSS_sum_recuo": {
			style: "_option37"
		},
		"02_CROSS_sum_secao_analise": {
			style: "_option37"
		},
		"02_CROSS_sum_titulo_finais_p1": {
			style: "_option37"
		},
		"02_CROSS_sum_parte_LM": {
			style: "_option38"
		},
		"02_CROSS_sum_cap_titulo_p1_LM": {
			style: "_option38"
		},
		"02_CROSS_sum_cap_titulo_p2_LM": {
			style: "_option39"
		},
		"02_CROSS_sum_cap_titulo_p3_LM": {
			style: "_option39"
		},
		"02_CROSS_sum_cap_titulo_p4_LM": {
			style: "_option39"
		},
	},

	//optional, title settings
	appendTitle: {
		"titleh1": [
		],
		"titleh2": [
		],
		"titleh3": [
		],
		"titleh4": [
		],
		"titleh5": [
		],
		"titleh6": [
		]
	},

	quotes:{
		"_default":[
			"05_BOXQUOTE_terc_txt_simples",
			"05_BOXQUOTE_terc_txt_destaque",
		],
		"_option1":[
			"05_BOXQUOTE_terc_txt_explorar",
		],
		"_option2":[
			"09_QUOTE_terc_txt_retomar",
			"09_QUOTE_terc_txt_poesia_retomar",
			"09_QUOTELIST_terc_txt_numerado_retomar",
			"09_QUOTELISTBULL_terc_bullet_l1_retomar",
			"04_QUOTE_terc_subtitulo",
			"04_QUOTE_terc_txt",
			"04_QUOTE_terc_txt_poesia",
			"04_QUOTE_terc_chamada",
			"04_QUOTELIST_terc_txt_numerado",
			"04_QUOTELISTBULL_terc_bullet_l1",
			"11_QUOTE_BODY_web_jornal",
		],
		"_option3":[
			"04_QUOTE_terc_subtitulo_LM",
			"04_QUOTE_terc_txt_LM",
			"04_QUOTE_terc_txt_sem_recuo_LM",
			"04_QUOTE_terc_txt_resposta_LM",
			"04_QUOTE_terc_txt_com_recuo_LM",
		],
	},

	//Optional digital component style definitions 
	digitalComponentStyles: {
		"Footnote": {
			"styles": {
				"style": "_footnote"
			}
		},
		"Option1": {
			"styles": {
				"style": "_option1"
			}
		},
		"Option2": {
			"styles": {
				"style": "_option2"
			}
		},
		"Option3": {
			"styles": {
				"style": "_option3"
			}
		},
		"Option4": {
			"styles": {
				"style": "_option4"
			}
		},
		"Option5": {
			"styles": {
				"style": "_option5"
			}
		},
		"Option6": {
			"styles": {
				"style": "_option6"
			}
		},
		"Option7": {
			"styles": {
				"style": "_option7"
			}
		},
		"Option8": {
			"styles": {
				"style": "_option8"
			}
		},
		"Option9": {
			"styles": {
				"style": "_option9"
			}
		},
		"Option10": {
			"styles": {
				"style": "_option10"
			}
		},
		"Option11": {
			"styles": {
				"style": "_option11"
			}
		},
		"Option12": {
			"styles": {
				"style": "_option12"
			}
		},
		"Option13": {
			"styles": {
				"style": "_option13"
			}
		},
		"Option14": {
			"styles": {
				"style": "_option14"
			}
		},
		"Option15": {
			"styles": {
				"style": "_option15"
			}
		},
		"Option16": {
			"styles": {
				"style": "_option16"
			}
		},
		"Option17": {
			"styles": {
				"style": "_option17"
			}
		},
		"Option18": {
			"styles": {
				"style": "_option18"
			}
		},
		"Option19": {
			"styles": {
				"style": "_option19"
			}
		},
		"Option20": {
			"styles": {
				"style": "_option20"
			}
		},
		"Option21": {
			"styles": {
				"style": "_option21"
			}
		},
		"Option22": {
			"styles": {
				"style": "_option22"
			}
		},
		"Option23": {
			"styles": {
				"style": "_option23"
			}
		},
		"Option24": {
			"styles": {
				"style": "_option24"
			}
		},
		"Option25": {
			"styles": {
				"style": "_option25"
			}
		},
		"Option26": {
			"styles": {
				"style": "_option26"
			}
		},
		"Option27": {
			"styles": {
				"style": "_option27"
			}
		},
		"Option28": {
			"styles": {
				"style": "_option28"
			}
		},
		"Option29": {
			"styles": {
				"style": "_option29"
			}
		},
		"Option30": {
			"styles": {
				"style": "_option30"
			}
		},
		"Option31": {
			"styles": {
				"style": "_option31"
			}
		},
		"Option32": {
			"styles": {
				"style": "_option32"
			}
		},
		"Option33": {
			"styles": {
				"style": "_option33"
			}
		},
		"Option34": {
			"styles": {
				"style": "_option34"
			}
		},
		"Option35": {
			"styles": {
				"style": "_option35"
			}
		},
		"Option36": {
			"styles": {
				"style": "_option36"
			}
		},
		"Option37": {
			"styles": {
				"style": "_option37"
			}
		},
		"Option38": {
			"styles": {
				"style": "_option38"
			}
		},
		"Option39": {
			"styles": {
				"style": "_option39"
			}
		},
		"Option40": {
			"styles": {
				"style": "_option40"
			}
		},
		"Option41": {
			"styles": {
				"style": "_option41"
			}
		},
		"Option42": {
			"styles": {
				"style": "_option42"
			}
		},
		"Option43": {
			"styles": {
				"style": "_option43"
			}
		},
		"Option44": {
			"styles": {
				"style": "_option44"
			}
		},
		"Option45": {
			"styles": {
				"style": "_option45"
			}
		},
		"Option46": {
			"styles": {
				"style": "_option46"
			}
		},
		"Option47": {
			"styles": {
				"style": "_option47"
			}
		},
		"Option48": {
			"styles": {
				"style": "_option48"
			}
		},
		"Option49": {
			"styles": {
				"style": "_option49"
			}
		},
		"Option50": {
			"styles": {
				"style": "_option50"
			}
		},
		"Option51": {
			"styles": {
				"style": "_option51"
			}
		},
		"Option52": {
			"styles": {
				"style": "_option52"
			}
		},
		"Option53": {
			"styles": {
				"style": "_option53"
			}
		},
		"Option54": {
			"styles": {
				"style": "_option54"
			}
		},
		"Option55": {
			"styles": {
				"style": "_option55"
			}
		},
		"Option56": {
			"styles": {
				"style": "_option56"
			}
		},
		"Option57": {
			"styles": {
				"style": "_option57"
			}
		},
		"Option58": {
			"styles": {
				"style": "_option58"
			}
		},
		"Option59": {
			"styles": {
				"style": "_option59"
			}
		},
		"Option60": {
			"styles": {
				"style": "_option60"
			}
		},
		"Option61": {
			"styles": {
				"style": "_option61"
			}
		},
		"Option62": {
			"styles": {
				"style": "_option62"
			}
		},
		"Option63": {
			"styles": {
				"style": "_option63"
			}
		},
		"Option64": {
			"styles": {
				"style": "_option64"
			}
		},
		"Option65": {
			"styles": {
				"style": "_option65"
			}
		},
		"Option66": {
			"styles": {
				"style": "_option66"
			}
		},
		"Option67": {
			"styles": {
				"style": "_option67"
			}
		},
		"Option68": {
			"styles": {
				"style": "_option68"
			}
		},
		"Option69": {
			"styles": {
				"style": "_option69"
			}
		},
		"Option70": {
			"styles": {
				"style": "_option70"
			}
		},
		"Option71": {
			"styles": {
				"style": "_option71"
			}
		},
		"Option72": {
			"styles": {
				"style": "_option72"
			}
		},
		"Option73": {
			"styles": {
				"style": "_option73"
			}
		},
		"Option74": {
			"styles": {
				"style": "_option74"
			}
		},
		"Option75": {
			"styles": {
				"style": "_option75"
			}
		},
		"Option76": {
			"styles": {
				"style": "_option76"
			}
		},
		"Option77": {
			"styles": {
				"style": "_option77"
			}
		},
		"Option78": {
			"styles": {
				"style": "_option78"
			}
		},
		"Option79": {
			"styles": {
				"style": "_option79"
			}
		},
		"Option80": {
			"styles": {
				"style": "_option80"
			}
		},
		"Option81": {
			"styles": {
				"style": "_option81"
			}
		},
		"Option82": {
			"styles": {
				"style": "_option82"
			}
		},
		"Option83": {
			"styles": {
				"style": "_option83"
			}
		},
		"Option84": {
			"styles": {
				"style": "_option84"
			}
		},
		"Option85": {
			"styles": {
				"style": "_option85"
			}
		},
		"Option86": {
			"styles": {
				"style": "_option86"
			}
		},
		"Option87": {
			"styles": {
				"style": "_option87"
			}
		},
		"Option88": {
			"styles": {
				"style": "_option88"
			}
		},
		"Option89": {
			"styles": {
				"style": "_option89"
			}
		},
		"Option90": {
			"styles": {
				"style": "_option90"
			}
		},
		"Option91": {
			"styles": {
				"style": "_option91"
			}
		},
		"Option92": {
			"styles": {
				"style": "_option92"
			}
		},
		"Option93": {
			"styles": {
				"style": "_option93"
			}
		},
		"Option94": {
			"styles": {
				"style": "_option94"
			}
		},
		"Option95": {
			"styles": {
				"style": "_option95"
			}
		},
		"Option96": {
			"styles": {
				"style": "_option96"
			}
		},
		"Option97": {
			"styles": {
				"style": "_option97"
			}
		},
		"Option98": {
			"styles": {
				"style": "_option98"
			}
		},
		"Option99": {
			"styles": {
				"style": "_option99"
			}
		},
		"Option100": {
			"styles": {
				"style": "_option100"
			}
		},
	},

	imageComponent: {
		//Base json of the image component
		definition: {
			"content": {
				"image": {
					"id": "",
					"focuspoint": {
						"x": 0.5,
						"y": 0.5
					},
					"cropper": false
				},
				"caption": [],
				"picture credit": []
			},
			"id": "",
			"identifier": "image",
			"styles": {
				"fitting": "_fit-frame-height-to-content"
			}
		},

		//List of the text filters of the image component as configured in textFilterList
		textFilters: [
			"image.caption"
		]
	},
	
	ptdimageComponent: {
		definition: {
			"content": {
				"ptdimage": {
					"id": "",
					"focuspoint": {
						"x": 0.5,
						"y": 0.5
					},
					"cropper": false
				},
				"caption": [],
				"picture credit": []
			},
			"id": "",
			"identifier": "ptdimage",
			"styles": {
				"ptdimage-fitting": "_fitting",
				"ptdimage-style": ""
			},
			"inlineStyles": {
				"width": ""
			}
		},
		//List of the text filters of the image component as configured in textFilterList
		textFilters: [
			"image.caption"
		]
	},

	mathComponent: {
		definition: {
			"content": {
				"mathml": {
					"options": {
						"mathML": ""
					}
				}
			},
			"id": "",
			"data": {
				"mathml-html-data": ""
			},
			"identifier": "mathml",
			"styles": {}
		}
	},

	//collapsiblebox
	collapsible: {
		"00_COLLAPBODY_abc_atv_adaptada": {
			definition: {
				"content": {
					"headerwithline": [
						{
							"insert": "Atividade adaptada"
						}
					]
				},
				"id": "",
				"identifier": "collapsiblebox",
				"styles": {},
				"containers": {
					"main": []
				}
			}
		},
		"00_COLLAPBODY_bullet_atv_adaptada": {
			definition: {
				"content": {
					"headerwithline": [
						{
							"insert": "Atividade adaptada"
						}
					]
				},
				"id": "",
				"identifier": "collapsiblebox",
				"styles": {},
				"containers": {
					"main": []
				}
			}
		},
		"00_COLLAPBODY_enunciado_atv_adaptada": {
			definition: {
				"content": {
					"headerwithline": [
						{
							"insert": "Atividade adaptada"
						}
					]
				},
				"id": "",
				"identifier": "collapsiblebox",
				"styles": {},
				"containers": {
					"main": []
				}
			}
		},
		"04_BODY_resposta": {
			definition: {
				"content": {
					"headerwithline": [
						{
              				"insert": "Orienta\u00E7\u00E3o para o professor"
						}
					]
				},
				"id": "",
				"identifier": "collapsiblebox",
				"styles": {},
				"containers": {
					"main": []
				}
			}
		},
		"00_COLLAPBODY_transcricao": {
			definition: {
				"content": {
					"headerwithline": [
						{
              				"insert": "Transcri\u00E7\u00E3o"
						}
					]
				},
				"id": "",
				"identifier": "collapsiblebox",
				"styles": {},
				"containers": {
					"main": []
				}
			}
		},
	},

	//Icon and Image Header definitions
	header: {
		"03_TITLEWICONH3_cap_titulo_abre_LM": { //Paragraph style name
			definition: {
				"content": {
					"imageicon": {
						"id": "",
						"focuspoint": {
							"x": 0.5,
							"y": 0.5
						},
						"cropper": false
					},
					"titlewih3": [		//title with icon example
					],
				},
				"id": "",
				"identifier": "titlewithiconh3",
				"styles": {},
				"inlineStyles": {
				}
			}
		},
		"04_TITLEWICONH3_cap_p1_LM": { //Paragraph style name
			definition: {
				"content": {
					"imageicon": {
						"id": "",
						"focuspoint": {
							"x": 0.5,
							"y": 0.5
						},
						"cropper": false
					},
					"titlewih3": [		//title with icon example
					],
				},
				"id": "",
				"identifier": "titlewithiconh3",
				"styles": {},
				"inlineStyles": {
				}
			}
		},
		"04_TITLEWICONH2_cap_p1_LM": { //Paragraph style name
			definition: {
				"content": {
					"imageicon": {
						"id": "",
						"focuspoint": {
							"x": 0.5,
							"y": 0.5
						},
						"cropper": false
					},
					"titlewih2": [		//title with icon example
					],
				},
				"id": "",
				"identifier": "titlewithiconh2",
				"styles": {},
				"inlineStyles": {
				}
			}
		},
		"05_BOXBODYWICON_boxe_vozes_marcador": { //Paragraph style name
			definition: {
				"content": {
					"imageicon": {
						"id": "",
						"focuspoint": {
							"x": 0.5,
							"y": 0.5
						},
						"cropper": false
					},
					"titlewi": [		//title with icon example
					],
				},
				"id": "",
				"identifier": "titlewithicon",
				"styles": {},
				"inlineStyles": {
				}
			}
		},
		"04_BODYWICON_cap_titulo_p1_LM": { //Paragraph style name
			definition: {
				"content": {
					"imageicon": {
						"id": "",
						"focuspoint": {
							"x": 0.5,
							"y": 0.5
						},
						"cropper": false
					},
					"titlewi": [		//title with icon example
					],
				},
				"id": "",
				"identifier": "titlewithicon",
				"styles": {},
				"inlineStyles": {
				}
			}
		},
		"05_BOXBODYWICON_boxe_retomar_marcador": { //Paragraph style name
			definition: {
				"content": {
					"imageicon": {
						"id": "",
						"focuspoint": {
							"x": 0.5,
							"y": 0.5
						},
						"cropper": false
					},
					"titlewi": [		//title with icon example
					],
				},
				"id": "",
				"identifier": "titlewithicon",
				"styles": {},
				"inlineStyles": {
				}
			}
		},
		"06_BODYWICON_secao_marcador_ativ_resolvidas": { //Paragraph style name
			definition: {
				"content": {
					"imageicon": {
						"id": "",
						"focuspoint": {
							"x": 0.5,
							"y": 0.5
						},
						"cropper": false
					},
					"titlewi": [		//title with icon example
					],
				},
				"id": "",
				"identifier": "titlewithicon",
				"styles": {},
				"inlineStyles": {
				}
			}
		},
		"06_BODYWICON_secao_marcador_ativ": { //Paragraph style name
			definition: {
				"content": {
					"imageicon": {
						"id": "",
						"focuspoint": {
							"x": 0.5,
							"y": 0.5
						},
						"cropper": false
					},
					"titlewi": [		//title with icon example
					],
				},
				"id": "",
				"identifier": "titlewithicon",
				"styles": {},
				"inlineStyles": {
				}
			}
		},
		"06_TITLEWICONH3_secao_analise": { //Paragraph style name
			definition: {
				"content": {
					"titlewih3": [		//title with icon example
					],
					"imageicon": {
						"id": "",
						"focuspoint": {
							"x": 0.5,
							"y": 0.5
						},
						"cropper": false
					}
				},
				"id": "",
				"identifier": "titlewithiconh3",
				"styles": {},
				"inlineStyles": {
				}
			}
		},
		"06_TITLEWICONH3_secao_ativ_finais": { //Paragraph style name
			definition: {
				"content": {
					"titlewih3": [		//title with icon example
					],
					"imageicon": {
						"id": "",
						"focuspoint": {
							"x": 0.5,
							"y": 0.5
						},
						"cropper": false
					}
				},
				"id": "",
				"identifier": "titlewithiconh3",
				"styles": {},
				"inlineStyles": {
				}
			}
		},
		"": { //Paragraph style name
			definition: {
				"content": {
					"imageicon": {
						"id": "",
						"focuspoint": {
							"x": 0.5,
							"y": 0.5
						},
						"cropper": false
					}
				},
				"id": "doc-1g5k3djco0",
				"identifier": "titlewithimage",
				"styles": {},
				"containers": {
					"main": []
				},
				"inlineStyles": {
				}
			},
			contentType: "titleh1"
		},
		"": { //Paragraph style name
			definition: {
				"content": {
					"imageicon": {
						"id": "",
						"focuspoint": {
							"x": 0.5,
							"y": 0.5
						},
						"cropper": false
					}
				},
				"id": "doc-1g5k3djco0",
				"identifier": "titlewithimage",
				"styles": {},
				"containers": {
					"main": []
				},
				"inlineStyles": {
				}
			},
			contentType: "titleh1"
		},
		"": { //Paragraph style name
			definition: {
				"content": {
					"imageicon": {
						"id": "",
						"focuspoint": {
							"x": 0.5,
							"y": 0.5
						},
						"cropper": false
					}
				},
				"id": "doc-1g5k3djco0",
				"identifier": "titlewithimage",
				"styles": {},
				"containers": {
					"main": []
				},
				"inlineStyles": {
				}
			},
			contentType: "titleh1"
		}
	},

	//Place components in a container based on their paragraph style
	containers: {
		"": { //Paragraph style
			definition: { // Container definition 
				"content": {},
				"id": "",
				"identifier": "bulleted-list", //bulleted-list, lowerletters-list, upperletters-list, upperroman-list, numbered-list
				"styles": {},
				"containers": {
					"main": []
				}
			},
			containerName: "main", //Container field in the container definition
		},
		"": { //Paragraph style
			definition: { // Container definition 
				"content": {},
				"id": "",
				"identifier": "bulleted-list", //bulleted-list, lowerletters-list, upperletters-list, upperroman-list, numbered-list
				"styles": {},
				"containers": {
					"main": []
				}
			},
			containerName: "main", //Container field in the container definition
		},
		"": { //Paragraph style
			definition: { // Container definition 
				"content": {},
				"id": "",
				"identifier": "bulleted-list",
				"styles": {},
				"containers": {
					"main": []
				}
			},
			containerName: "main", //Container field in the container definition
		},
		"": { //Paragraph style
			definition: { // Container definition 
				"content": {},
				"id": "",
				"identifier": "bulleted-list",
				"styles": {},
				"containers": {
					"main": []
				}
			},
			containerName: "main", //Container field in the container definition
		},
		"": { //Paragraph style
			definition: { // Container definition 
				"content": {},
				"id": "",
				"identifier": "bulleted-list",
				"styles": {},
				"containers": {
					"main": []
				}
			},
			containerName: "main", //Container field in the container definition
		},
		"": { //Paragraph style
			definition: { // Container definition 
				"content": {},
				"id": "",
				"identifier": "lowerletters-list",
				"styles": {},
				"containers": {
					"main": []
				}
			},
			containerName: "main", //Container field in the container definition
		},
		"": { //Paragraph style
			definition: { // Container definition 
				"content": {},
				"id": "",
				"identifier": "lowerletters-list",
				"styles": {},
				"containers": {
					"main": []
				}
			},
			containerName: "main", //Container field in the container definition
		},
		"": { //Paragraph style
			definition: { // Container definition 
				"content": {},
				"id": "",
				"identifier": "bulleted-list",
				"styles": {},
				"containers": {
					"main": []
				}
			},
			containerName: "main", //Container field in the container definition
		},
		"": { //Paragraph style
			definition: { // Container definition 
				"content": {},
				"id": "",
				"identifier": "bulleted-list",
				"styles": {},
				"containers": {
					"main": []
				}
			},
			containerName: "main", //Container field in the container definition
		},
		"": { //Paragraph style
			definition: { // Container definition 
				"content": {},
				"id": "",
				"identifier": "bulleted-list",
				"styles": {},
				"containers": {
					"main": []
				}
			},
			containerName: "main", //Container field in the container definition
		},
		"": { //Paragraph style
			definition: { // Container definition 
				"content": {},
				"id": "",
				"identifier": "bulleted-list",
				"styles": {},
				"containers": {
					"main": []
				}
			},
			containerName: "main", //Container field in the container definition
		},
		"": { //Paragraph style
			definition: { // Container definition 
				"content": {},
				"id": "",
				"identifier": "lowerletters-list",
				"styles": {},
				"containers": {
					"main": []
				}
			},
			containerName: "main", //Container field in the container definition
		},
		"": { //Paragraph style
			definition: { // Container definition 
				"content": {},
				"id": "",
				"identifier": "lowerletters-list",
				"styles": {},
				"containers": {
					"main": []
				}
			},
			containerName: "main", //Container field in the container definition
		},
		"": { //Paragraph style
			definition: { // Container definition 
				"content": {},
				"id": "",
				"identifier": "lowerletters-list",
				"styles": {},
				"containers": {
					"main": []
				}
			},
			containerName: "main", //Container field in the container definition
		},
		"": { //Paragraph style
			definition: { // Container definition 
				"content": {},
				"id": "",
				"identifier": "lowerletters-list",
				"styles": {},
				"containers": {
					"main": []
				}
			},
			containerName: "main", //Container field in the container definition
		},
		"": { //Paragraph style
			definition: { // Container definition 
				"content": {},
				"id": "",
				"identifier": "lowerletters-list",
				"styles": {},
				"containers": {
					"main": []
				}
			},
			containerName: "main", //Container field in the container definition
		},
		"": { //Paragraph style
			definition: { // Container definition 
				"content": {},
				"id": "",
				"identifier": "lowerletters-list",
				"styles": {},
				"containers": {
					"main": []
				}
			},
			containerName: "main", //Container field in the container definition
		},
		"": { //Paragraph style
			definition: { // Container definition 
				"content": {},
				"id": "",
				"identifier": "lowerletters-list",
				"styles": {},
				"containers": {
					"main": []
				}
			},
			containerName: "main", //Container field in the container definition
		},
		"": { //Paragraph style
			definition: { // Container definition 
				"content": {},
				"id": "",
				"identifier": "bulleted-list",
				"styles": {},
				"containers": {
					"main": []
				}
			},
			containerName: "main", //Container field in the container definition
		},
		"": { //Paragraph style
			definition: { // Container definition 
				"content": {},
				"id": "",
				"identifier": "lowerletters-list",
				"styles": {},
				"containers": {
					"main": []
				}
			},
			containerName: "main", //Container field in the container definition
		},
		"": { //Paragraph style
			definition: { // Container definition 
				"content": {},
				"id": "",
				"identifier": "lowerletters-list",
				"styles": {},
				"containers": {
					"main": []
				}
			},
			containerName: "main", //Container field in the container definition
		},
		"": { //Paragraph style
			definition: { // Container definition 
				"content": {},
				"id": "",
				"identifier": "bulleted-list",
				"styles": {},
				"containers": {
					"main": []
				}
			},
			containerName: "main", //Container field in the container definition
		},
		"": { //Paragraph style
			definition: { // Container definition 
				"content": {},
				"id": "",
				"identifier": "lowerletters-list",
				"styles": {},
				"containers": {
					"main": []
				}
			},
			containerName: "main", //Container field in the container definition
		},
		"": { //Paragraph style
			definition: { // Container definition 
				"content": {},
				"id": "",
				"identifier": "bulleted-list",
				"styles": {},
				"containers": {
					"main": []
				}
			},
			containerName: "main", //Container field in the container definition
		},
		"": { //Paragraph style
			definition: { // Container definition 
				"content": {},
				"id": "",
				"identifier": "bulleted-list",
				"styles": {},
				"containers": {
					"main": []
				}
			},
			containerName: "main", //Container field in the container definition
		},
		"": { //Paragraph style
			definition: { // Container definition 
				"content": {},
				"id": "",
				"identifier": "bulleted-list",
				"styles": {},
				"containers": {
					"main": []
				}
			},
			containerName: "main", //Container field in the container definition
		},
		"": { //Paragraph style
			definition: { // Container definition 
				"content": {},
				"id": "",
				"identifier": "lowerletters-list",
				"styles": {},
				"containers": {
					"main": []
				}
			},
			containerName: "main", //Container field in the container definition
		},
		"": { //Paragraph style
			definition: { // Container definition 
				"content": {},
				"id": "",
				"identifier": "numbered-list",
				"styles": {},
				"containers": {
					"main": []
				}
			},
			containerName: "main", //Container field in the container definition
		}
	},

	// The 'styles' section provides the export details about what styling should result in bold and italic
	// overrides in the output.
	styles: {
		// Mark character styles as bold or italic. Matching is on full character style name. Most commonly used.
		character: {
			"Bold": { bold: true },
			"Bold Italic": { bold: true, italic: true },
			"Italic": { italic: true },
			"Subscript": { subscript: true },
			"Superscript": { superscript: true },
			"Underline": { underline: true },
			"Strikethrough": { strikethrough: true },
			"Uppercase": { uppercase: true },
			"Lowercase": { lowercase: true },
			"Titlecase": { titlecase: true },
			"00_hyperlink": { characterstyle: "cs-00_hyperlink" },
			"00_indent_level_1_bold_texto_geral": { characterstyle: "cs-00_indent_level_1_bold_texto_geral" },
			"00_indent_level_1_exerc_num_cor3": { characterstyle: "cs-00_indent_level_1_exerc_num_cor3" },
			"00_indent_level_1_num_abre_unidade": { characterstyle: "cs-00_indent_level_1_num_abre_unidade" },
			"00_indent_level_1_num_exerc_boxe_lateral": { characterstyle: "cs-00_indent_level_1_num_exerc_boxe_lateral" },
			"00_indent_level_1_num_exerc_cor2": { characterstyle: "cs-00_indent_level_1_num_exerc_cor2" },
			"00_indent_level_2_exerc_abc": { characterstyle: "cs-00_indent_level_2_exerc_abc" },
			"00-ponto_invisivel": { characterstyle: "cs-00-ponto_invisivel" },
			"00_sobrescrito": { characterstyle: "cs-00_sobrescrito" },
			"00_sobrescrito_bold": { characterstyle: "cs-00_sobrescrito_bold" },
			"00_sobrescrito_bold_italico": { characterstyle: "cs-00_sobrescrito_bold_italico" },
			"00_sobrescrito_italico": { characterstyle: "cs-00_sobrescrito_italico" },
			"00_subscrito": { characterstyle: "cs-00_subscrito" },
			"00_subscrito_bold": { characterstyle: "cs-00_subscrito_bold" },
			"00_subscrito_bold_italico": { characterstyle: "cs-00_subscrito_bold_italico" },
			"00_subscrito_italico": { characterstyle: "cs-00_subscrito_italico" },
			"00-acessibilidade-abreviatura": { characterstyle: "cs-00-acessibilidade-abreviatura" },
			"00-acessibilidade-abreviatura-bold": { characterstyle: "cs-00-acessibilidade-abreviatura-bold" },
			"00-acessibilidade-abreviatura-bold-italic": { characterstyle: "cs-00-acessibilidade-abreviatura-bold-italic" },
			"00-acessibilidade-abreviatura-italic": { characterstyle: "cs-00-acessibilidade-abreviatura-italic" },
			"00-acessibilidade-fonetica": { characterstyle: "cs-00-acessibilidade-fonetica" },
			"00-acessibilidade-fonetica-bold": { characterstyle: "cs-00-acessibilidade-fonetica-bold" },
			"00-acessibilidade-fonetica-bold-italic": { characterstyle: "cs-00-acessibilidade-fonetica-bold-italic" },
			"00-acessibilidade-fonetica-italic": { characterstyle: "cs-00-acessibilidade-fonetica-italic" },
			"00-acessibilidade-monetario": { characterstyle: "cs-00-acessibilidade-monetario" },
			"00-acessibilidade-monetario-bold": { characterstyle: "cs-00-acessibilidade-monetario-bold" },
			"00-acessibilidade-monetario-bold-italic": { characterstyle: "cs-00-acessibilidade-monetario-bold-italic" },
			"00-acessibilidade-monetario-italic": { characterstyle: "cs-00-acessibilidade-monetario-italic" },
			"00-acessibilidade-pagina": { characterstyle: "cs-00-acessibilidade-pagina" },
			"00-acessibilidade-romano": { characterstyle: "cs-00-acessibilidade-romano" },
			"00-acessibilidade-romano-bold": { characterstyle: "cs-00-acessibilidade-romano-bold" },
			"00-acessibilidade-romano-bold-italic": { characterstyle: "cs-00-acessibilidade-romano-bold-italic" },
			"00-acessibilidade-romano-italic": { characterstyle: "cs-00-acessibilidade-romano-italic" },
			"00-acessibilidade-siglas": { characterstyle: "cs-00-acessibilidade-siglas" },
			"00-acessibilidade-siglas-bold": { characterstyle: "cs-00-acessibilidade-siglas-bold" },
			"00-acessibilidade-siglas-bold-italic": { characterstyle: "cs-00-acessibilidade-siglas-bold-italic" },
			"00-acessibilidade-siglas-italic": { characterstyle: "cs-00-acessibilidade-siglas-italic" },
			"00-acessibilidade-simbolos": { characterstyle: "cs-00-acessibilidade-simbolos" },
			"00-lang-espanhol": { characterstyle: "cs-00-lang-espanhol" },
			"00-lang-espanhol-bold": { characterstyle: "cs-00-lang-espanhol-bold" },
			"00-lang-espanhol-bold-italico": { characterstyle: "cs-00-lang-espanhol-bold-italico" },
			"00-lang-espanhol-italico": { characterstyle: "cs-00-lang-espanhol-italico" },
			"00-lang-frances": { characterstyle: "cs-00-lang-frances" },
			"00-lang-frances-bold": { characterstyle: "cs-00-lang-frances-bold" },
			"00-lang-frances-bold-italico": { characterstyle: "cs-00-lang-frances-bold-italico" },
			"00-lang-frances-italico": { characterstyle: "cs-00-lang-frances-italico" },
			"00-lang-ingles": { characterstyle: "cs-00-lang-ingles" },
			"00-lang-ingles-bold": { characterstyle: "cs-00-lang-ingles-bold" },
			"00-lang-ingles-bold-italico": { characterstyle: "cs-00-lang-ingles-bold-italico" },
			"00-lang-ingles-italico": { characterstyle: "cs-00-lang-ingles-italico" },
			"00-lang-latim": { characterstyle: "cs-00-lang-latim" },
			"00-lang-latim-bold": { characterstyle: "cs-00-lang-latim-bold" },
			"00-lang-latim-bold-italico": { characterstyle: "cs-00-lang-latim-bold-italico" },
			"00-lang-latim-italico": { characterstyle: "cs-00-lang-latim-italico" },
			"00-lang-russo": { characterstyle: "cs-00-lang-russo" },
			"00-lang-russo-bold": { characterstyle: "cs-00-lang-russo-bold" },
			"00-lang-russo-bold-italico": { characterstyle: "cs-00-lang-russo-bold-italico" },
			"00-lang-russo-italico": { characterstyle: "cs-00-lang-russo-italico" },
			"01_italico_texto_geral": { characterstyle: "cs-01_italico_texto_geral" },
			"02_bold_texto_geral": { characterstyle: "cs-02_bold_texto_geral" },
			"04_italico_texto_terceiro": { characterstyle: "cs-04_italico_texto_terceiro" },
			"09_destaque_verbo": { characterstyle: "cs-09_destaque_verbo" },
			"19_sumario_destaque_peso_2": { characterstyle: "cs-19_sumario_destaque_peso_2" },
			"23_sumario_secao": { characterstyle: "cs-23_sumario_secao" },
			"36_italico_genero_jornal": { characterstyle: "cs-36_italico_genero_jornal" },
			"38_bold_italico_genero_jornal": { characterstyle: "cs-38_bold_italico_genero_jornal" },
			"41_destaque_glossario_jornal": { characterstyle: "cs-41_destaque_glossario_jornal" },
			"50_destaque_exemplo_obs": { characterstyle: "cs-50_destaque_exemplo_obs" },
			"51_Icone_texto_italico": { characterstyle: "cs-51_Icone_texto_italico" },
			"59_Italic_titulo": { characterstyle: "cs-59_Italic_titulo" },
			"60_sublinhado": { characterstyle: "cs-60_sublinhado" },
			"61_sublinhado_resposta": { characterstyle: "cs-61_sublinhado_resposta" },
			"00_ordinal_bold_italico": { characterstyle: "cs-00_ordinal_bold_italico" },
			"00_ordinal_italico": { characterstyle: "cs-00_ordinal_italico" },
			"00_glifo": { characterstyle: "cs-00_glifo" },
			"00_ordinal": { characterstyle: "cs-00_ordinal" },
			"00_ordinal_bold": { characterstyle: "cs-00_ordinal_bold" },
			"62_cifrao_titulo_peso_1": { characterstyle: "cs-62_cifrao_titulo_peso_1" },
			"63_cifrao_titulo_peso_2": { characterstyle: "cs-63_cifrao_titulo_peso_2" },
			"64_cifrao_titulo_peso_3": { characterstyle: "cs-64_cifrao_titulo_peso_3" },
			"65_cifrao_titulo_boxe": { characterstyle: "cs-65_cifrao_titulo_boxe" },
			"00_marcador_capitulo": { characterstyle: "cs-00_marcador_capitulo" },
			"00_capitulo_numero": { characterstyle: "cs-00_capitulo_numero" },
			"00_highlight_sumario": { characterstyle: "cs-00_highlight_sumario" },
			"00_unidade_marcador": { characterstyle: "cs-03_unidade_numero" },
			"03_unidade_numero": { characterstyle: "cs-03_unidade_numero" },
			"20_sumario_destaque_topico": { characterstyle: "cs-20_sumario_destaque_topico" },
			"00_bullet_exercicio": { characterstyle: "cs-00_bullet_exercicio" },
			"00_bullet_resolucao": { characterstyle: "cs-00_bullet_resolucao" },
			"00_destaque_exerc_abc": { characterstyle: "cs-00_destaque_exerc_abc" },
			"00_destaque_exerc_secao_cor_1": { characterstyle: "cs-00_destaque_exerc_secao_cor_1" },
			"00_destaque_exerc_secao_cor_2": { characterstyle: "cs-00_destaque_exerc_secao_cor_2" },
			"00_destaque_exerc_secao_cor_3": { characterstyle: "cs-00_destaque_exerc_secao_cor_3" },
			"00_indent_level_1_abre_unidade_bullet": { characterstyle: "cs-00_indent_level_1_abre_unidade_bullet" },
			"00_indent_level_1_bullet_exercicio": { characterstyle: "cs-00_indent_level_1_bullet_exercicio" },
			"00_indent_level_1_bullet_nesta_unidade": { characterstyle: "cs-00_indent_level_1_bullet_nesta_unidade" },
			"00_indent_level_1_bullet_resolucao": { characterstyle: "cs-00_indent_level_1_bullet_resolucao" },
			"00_indent_level_1_bullet_tabela_texto": { characterstyle: "cs-00_indent_level_1_bullet_tabela_texto" },
			"00_indent_level_1_bullet_texto_geral": { characterstyle: "cs-00_indent_level_1_bullet_texto_geral" },
			"00_indent_level_1_bullet_txt_terc": { characterstyle: "cs-00_indent_level_1_bullet_txt_terc" },
			"00_indent_level_1_exerc_secao_cor1": { characterstyle: "cs-00_indent_level_1_exerc_secao_cor1" },
			"00_indent_level_2_bold_texto_geral": { characterstyle: "cs-00_indent_level_2_bold_texto_geral" },
			"00_indent_level_2_bullet_exercicio": { characterstyle: "cs-00_indent_level_2_bullet_exercicio" },
			"00_indent_level_3_bullet_exercicio": { characterstyle: "cs-00_indent_level_3_bullet_exercicio" },
			"07_destaque_glossario": { characterstyle: "cs-07_destaque_glossario" },
			"22_sumario_topico": { characterstyle: "cs-22_sumario_topico" },
			"03_bold_italico_texto_geral": { characterstyle: "cs-03_bold_italico_texto_geral" },
			"16_sumario_pontilhado": { characterstyle: "cs-16_sumario_pontilhado" },
			"18_Resposta": { characterstyle: "cs-18_Resposta" },
			"00_indent_level_1_bold_texto_terceiro": { characterstyle: "cs-00_indent_level_1_bold_texto_terceiro" },
			"05_bold_texto_terceiro": { characterstyle: "cs-05_bold_texto_terceiro" },
			"37_bold_genero_jornal": { characterstyle: "cs-37_bold_genero_jornal" },
			"40_destaque_glossario_terceiro": { characterstyle: "cs-40_destaque_glossario_terceiro" },
			"06_bold_italico_texto_terceiro": { characterstyle: "cs-06_bold_italico_texto_terceiro" },
			"11_mat_stix": { characterstyle: "cs-11_mat_stix" },
			"67_mat_stix_sobrescrito": { characterstyle: "cs-67_mat_stix_sobrescrito" },
			"69_mat_stix_subscrito": { characterstyle: "cs-69_mat_stix_subscrito" },
			"19_sumario_destaque_peso_2": { characterstyle: "cs-19_sumario_destaque_peso_2" },
			"00-lang-alemao": { characterstyle: "cs-00-lang-alemao" },
			"00-lang-alemao-italico": { characterstyle: "cs-00-lang-alemao-italico" },
			"00-lang-alemao-bold": { characterstyle: "cs-00-lang-alemao-bold" },
			"00-lang-alemao-bold-italico": { characterstyle: "cs-00-lang-alemao-bold-italico" },
			"00-lang-italiano": { characterstyle: "cs-00-lang-italiano" },
			"00-lang-italiano-italico": { characterstyle: "cs-00-lang-italiano-italico" },
			"00-lang-italiano-bold": { characterstyle: "cs-00-lang-italiano-bold" },
			"00-lang-italiano-bold-italico": { characterstyle: "cs-00-lang-italiano-bold-italico" },
			"00-lang-arabe": { characterstyle: "cs-00-lang-arabe" },
			"00-lang-arabe-italico": { characterstyle: "cs-00-lang-arabe-italico" },
			"00-lang-arabe-bold": { characterstyle: "cs-00-lang-arabe-bold" },
			"00-lang-arabe-bold-italico": { characterstyle: "cs-00-lang-arabe-bold-italico" },
			"00_sumario_destaque_OED": { characterstyle: "cs-00_sumario_destaque_OED" },
			"00_sumario_destaque_OED_italico": { characterstyle: "cs-00_sumario_destaque_OED_italico" },
			"18_sumario_pontilhado": { characterstyle: "cs-18_sumario_pontilhado" },
			"18_sumario_destaque_pontilhado": { characterstyle: "cs-18_sumario_destaque_pontilhado" },
			"00-sumario-id": { characterstyle: "cs-00-sumario-id" },
			"07_destaque_glossario-italico": { characterstyle: "cs-07_destaque_glossario-italico" },
			"00_destaque_numero_nota_rodape": { characterstyle: "cs-00_destaque_numero_nota_rodape" },
			"00_palavra_sem_automacao": { characterstyle: "cs-00_palavra_sem_automacao" },
			"00_palavra_sem_automacao_italico": { characterstyle: "cs-00_palavra_sem_automacao_italico" },
			"00_palavra_sem_automacao_terceiro": { characterstyle: "cs-00_palavra_sem_automacao_terceiro" },
			"40_destaque_glossario_body": { characterstyle: "cs-40_destaque_glossario_body" },
			//add 6 new character styles for Roman List
			"00_indent_level_1_lower_roman": { characterstyle: "cs-00_indent_level_1_lower_roman" },
			"00_indent_level_2_lower_roman": { characterstyle: "cs-00_indent_level_2_lower_roman" },
			"00_indent_level_3_lower_roman": { characterstyle: "cs-00_indent_level_3_lower_roman" },
			"00_indent_level_1_upper_roman": { characterstyle: "cs-00_indent_level_1_upper_roman" },
			"00_indent_level_2_upper_roman": { characterstyle: "cs-00_indent_level_2_upper_roman" },
			"00_indent_level_3_upper_roman": { characterstyle: "cs-00_indent_level_3_upper_roman" },
			"2_extrabold_texto_geral": { characterstyle: "cs-2_extrabold_texto_geral" },
			//add new character styles for Livro
			"00_indent_level_1_num_black_txt_geral_LM": { characterstyle: "cs-00_indent_level_1_num_black_txt_geral_LM" },
			"00_indent_level_1_bold_texto_geral_LM": { characterstyle: "cs-00_indent_level_1_bold_texto_geral_LM" },
			"00_indent_level_1_bold_texto_terceiro_LM": { characterstyle: "cs-00_indent_level_1_bold_texto_terceiro_LM" },
			"00_indent_level_1_bullet_box_objetivos_LM": { characterstyle: "cs-00_indent_level_1_bullet_box_objetivos_LM" },
			"00_indent_level_1_bullet_exerc_LM": { characterstyle: "cs-00_indent_level_1_bullet_exerc_LM" },
			"00_indent_level_1_bullet_tabela_texto_LM": { characterstyle: "cs-00_indent_level_1_bullet_tabela_texto_LM" },
			"00_indent_level_1_bullet_texto_geral_LM": { characterstyle: "cs-00_indent_level_1_bullet_texto_geral_LM" },
			"00_indent_level_1_exerc_secao_cor_1_LM": { characterstyle: "cs-00_indent_level_1_exerc_secao_cor_1_LM" },
			"00_indent_level_2_bold_texto_geral_LM": { characterstyle: "cs-00_indent_level_2_bold_texto_geral_LM" },
			"00_indent_level_2_bullet_texto_geral_LM": { characterstyle: "cs-00_indent_level_2_bullet_texto_geral_LM" },
			"00_indent_level_2_exerc_abc_LM": { characterstyle: "cs-00_indent_level_2_exerc_abc_LM" },
			"00_indent_level_2_resposta_abc_LM": { characterstyle: "cs-00_indent_level_2_resposta_abc_LM" },
			"00_indent_level_3_bullet_exercicio_LM": { characterstyle: "cs-00_indent_level_3_bullet_exercicio_LM" },
			"00_bullet_box_objetivos_LM": { characterstyle: "cs-00_bullet_box_objetivos_LM" },
			"00_bullet_box_para_ampliar_LM": { characterstyle: "cs-00_bullet_box_para_ampliar_LM" },
			"00_capitulo_marcador_LM": { characterstyle: "cs-00_capitulo_marcador_LM" },
			"00_capitulo_numero_LM": { characterstyle: "cs-00_capitulo_marcador_LM" },
			"00_destaque_exerc_abc_LM": { characterstyle: "cs-00_destaque_exerc_abc_LM" },
			"00_destaque_exerc_secao_cor_2_LM": { characterstyle: "cs-00_destaque_exerc_secao_cor_2_LM" },
			"00_num_black_txt_geral_LM": { characterstyle: "cs-00_num_black_txt_geral_LM" },
			"00_resposta_abc_LM": { characterstyle: "cs-00_resposta_abc_LM" },
			"00_resposta_numero_LM": { characterstyle: "cs-00_resposta_numero_LM" },
			"00_unidade_marcador_LM": { characterstyle: "cs-00_unidade_marcador_LM" },
			"00_unidade_numero_LM": { characterstyle: "cs-00_unidade_marcador_LM" },
			"01_italico_texto_geral_LM": { characterstyle: "cs-01_italico_texto_geral_LM" },
			"02_bold_texto_geral_LM": { characterstyle: "cs-02_bold_texto_geral_LM" },
			"03_bold_italico_texto_geral_LM": { characterstyle: "cs-03_bold_italico_texto_geral_LM" },
			"04_italico_texto_terceiro_LM": { characterstyle: "cs-04_italico_texto_terceiro_LM" },
			"05_bold_texto_terceiro_LM": { characterstyle: "cs-05_bold_texto_terceiro_LM" },
			"06_bold_italico_texto_terceiro_LM": { characterstyle: "cs-06_bold_italico_texto_terceiro_LM" },
			"11_mat_stix_LM": { characterstyle: "cs-11_mat_stix_LM" },
			"12_caracter_cursivo_LM": { characterstyle: "cs-12_caracter_cursivo_LM" },
			"18_bullet_numerado_LM": { characterstyle: "cs-18_bullet_numerado_LM" },
			"18_sumario_pontilhado_LM": { characterstyle: "cs-18_sumario_pontilhado_LM" },
			"20_bullet_tabela_LM": { characterstyle: "cs-20_bullet_tabela_LM" },
			"22_nota_de_rodape_LM": { characterstyle: "cs-22_nota_de_rodape_LM" },
			"23_competencia_geral_cor_LM": { characterstyle: "cs-23_competencia_geral_cor_LM" },
			"23_texto_bullet_geral_LM": { characterstyle: "cs-23_texto_bullet_geral_LM" },
			"24_competencia_especifica_LM": { characterstyle: "cs-24_competencia_especifica_LM" },
			"25_habilidades_LM": { characterstyle: "cs-25_habilidades_LM" },
			"35_infra_regular_LM": { characterstyle: "cs-35_infra_regular_LM" },
			"36_italico_genero_jornal_LM": { characterstyle: "cs-36_italico_genero_jornal_LM" },
			"37_bold_genero_jornal_LM": { characterstyle: "cs-37_bold_genero_jornal_LM" },
			"37_competencia_geral_destaque_LM": { characterstyle: "cs-37_competencia_geral_destaque_LM" },
			"38_bold_italico_genero_jornal_LM": { characterstyle: "cs-38_bold_italico_genero_jornal_LM" },
			"38_habilidade_destaque_LM": { characterstyle: "cs-38_habilidade_destaque_LM" },
			"39_competencia_especifica_destaque_LM": { characterstyle: "cs-39_competencia_especifica_destaque_LM" },
			"40_bold_genero_jornal_LM": { characterstyle: "cs-40_bold_genero_jornal_LM" },
			"40_destaque_tct_LM": { characterstyle: "cs-40_destaque_tct_LM" },
			"59_italic_titulo_LM": { characterstyle: "cs-59_italic_titulo_LM" },
			"60_sublinhado_LM": { characterstyle: "cs-60_sublinhado_LM" },
			"66_mat_stix_sobrescrito_LM": { characterstyle: "cs-66_mat_stix_sobrescrito_LM" },
			"68_mat_stix_subscrito_LM": { characterstyle: "cs-68_mat_stix_subscrito_LM" },
			"71_titulo_unidade_sum_LM": { characterstyle: "cs-71_titulo_unidade_sum_LM" },
		},
	
		// Mark use of certain font styles as bold or italic in the output. Be aware that this will match for all
		// font families used with the specified font style
		font: {
		},
		// Mark entire paragraphs as bold or italic. Not commonly used.
		paragraph: {
		}
	},

	// The 'output' section defines how bold and italic overrides will be output to Ptd. In addition it offers
	// the opportunity to remove and/or replace characters in the output. Html special characters will automatically be
	// escaped in the output.
	output: {
		htmlTags: {
			bold: {
				tag: "b"
			},
			italic: {
				tag: "i"
			},
			superscript: {
				tag: "sup"
			},
			subscript: {
				tag: "sub"
			},
			uppercase: {
				tag: "up"
			}
		},
		htmlEncode: [
		]
	},

	// Using the 'charConvert' section certain characters can be replaced by other characters 
	charConvert: [
		//Thin space to space
		['\u2009', ' ']
	],

	// The directory used as base directory for logging
	exportDirectory: '~/Desktop/ptd-indesign-logs',

	// Logging settings. Log files will be put in the document's output directory.
	logging: {
		level: 'INFO',
		wipe: true
	},

	//Content Station URL relative to index.php, default assumes that Content Station is installed in the same folder as index.php
	contentStationURL: "../app/",

	//If set to true, each set of grouped frames on a layout is added as a Container component.
	//Each frame of the group will be a separate component in the Container.
	//Note: The default Container component is used; custom Container components are not supported.
	createContainerForGroup: true,

	//If set to true, images will be scaled by percentage in conversion, respecting the scaling (percentage) of frame width and print page width
	//Else set image width to 100% in conversion, so that the image is sized by CSS styling or scaled to fit full width of digital article
	scalePTDImages: true
};