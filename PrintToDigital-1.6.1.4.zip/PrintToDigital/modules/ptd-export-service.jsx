﻿/**
 * @description Ptd export service - exports InDesign article with content
 *
 * @copyright WoodWing Software B.V. All rights reserved.
 */

if (forceInit || typeof $.global.PtdExportService === 'undefined') {

    #include '_.jsx'

    #include 'err.jsx'

    #include 'config-service.jsx'

    #include 'component-lookup.jsx'

    #include 'logging.jsx'

    #include 'json2.js'

    var PtdExportService = function(Err, ConfigService, JSON, _) {
        'use strict';
        var _config = ConfigService.getConfig();

        /**
         *
         * @throws ArticleDoesNotExistError
         */
        function exportArticle(path) {
            log.info('=> ptd-export-service.exportArticle');

            //Check if the layout is stored in Enteprise
            if (!app.activeDocument.entMetaData.has("Core_ID")) {
                alert("Salve primeiro o Layout no Studio Server, o artigo criado será armazenado na mesma Marca e Dossiê");
                return;
            }

            //Get the Core ID, Brand ID of the Layout
            var layoutID = app.activeDocument.entMetaData.get("Core_ID");
            var brand = null;

            layoutInfo = getObject(layoutID);
            brand = layoutInfo.result.Objects[0].MetaData.BasicMetaData.Publication;
            issueId = layoutInfo.result.Objects[0].Targets[0].Issue.Id;
            issueName = layoutInfo.result.Objects[0].Targets[0].Issue.Name;
            pubChannelId = layoutInfo.result.Objects[0].Targets[0].PubChannel.Id;
            pubChannelName = layoutInfo.result.Objects[0].Targets[0].PubChannel.Name;

            //Select the article template to use
            templateList = getTemplateList(brand.Id);
            var template = selectArticleTemplate(templateList);

            //Check if the user selected a template
            if (!template) {
                return;
            }

            var articles = app.activeDocument.articles;
            if (articles.length) {
                for (var i = 0; i < articles.length; i++) {
                    //Get article info
                    var temp = articles[i];

                    var source = new ArticleWrapper(articles[i].name);
                    var articleInfo = source.getArticleInfo(false, articles[i].name);
                    articleInfo.componentCount = articleInfo.components.length;
                    //An source wrapper to handle article
                    var articleJson = source.createPtdArticle(articleInfo);
                    //log.info(JSON.stringify(articleJson));
                    //Upload to studio server
                    var result = source.uploadArticleToEnterprise(articleJson, articleInfo, layoutID, template);
                    //update publish in
                    var newId = result.result.Objects[0].MetaData.BasicMetaData.ID;
                    var update = source.UpdatePublishedIn(newId);
                    if (result && result.error) {
                        alert("Export failed\n" + result.error.message + "\n" + result.error.data.detail);
                    } else if (result) {
                        var layoutID = app.activeDocument.entMetaData.get("Core_ID");
                        var dossierIds = app.getDossiersForItem(layoutID);
                        if (_config.contentStationURL != "" && dossierIds.length > 0) {
                            if ((articles.length == i + 1) && confirm("O artigo foi criado com sucesso\n\n Deseja abrir o Dossiê?")) {
                                //Woodwing EOS url is different from default, manually set for Moderna.
                                var csUrl = app.entSession.activeUrl.replace("index.php", "");
                                //fix for EOS customers...
                                if (csUrl.endsWith("/server/")) {
                                    csUrl = csUrl.slice(0, -7);
                                }
                                csUrl += _config.contentStationURL;
                                if (csUrl.slice(-1) != "/") {
                                    csUrl += "/";
                                }
                                _gotoLink(csUrl + "#/dossier/?dossierId=" + dossierIds[0]);
                            }
                        } else {
                            alert("O artigo foi criado com sucesso");
                        }
                    }
                }
                log.info('<= ptd-export-service.exportArticle');
            } else {
                throw new Err.ArticleDoesNotExistError("O artigo não foi encontrado. \nEsperado, mas encontrado " + articles.length + " artigos. Consulte o painel Artigos do InDesign", $.fileName, $.line);
            }
        }

        function _gotoLink(url) {
            url = url || "http://woodwing.com";

            if (File.fs == "Macintosh") {
                var body = 'tell application "Finder"\ropen location "' + url + '"\rend tell';
                app.doScript(body, ScriptLanguage.APPLESCRIPT_LANGUAGE);
            } else {
                var body = 'dim objShell\rset objShell = CreateObject("Shell.Application")\rstr = "' + url + '"\robjShell.ShellExecute str, "", "", "open", 1 '
                app.doScript(body, ScriptLanguage.VISUAL_BASIC);
            }
        }

        function ArticleWrapper(articleName) {
            log.info('=> ptd-export-service.ArticleWrapper({})', articleName);

            var oldPagNums = [];
            var footnotes = [];
            var footnoteNumber = 1;

            var sourceArticle = function() {
                var articles = _.filter(_('articles'), function(article) {
                    return article.name === articleName;
                });
                return _(articles[0]);
            }();
            var textStyles = new ComponentLookup(_config.textFilterList, "textFilterList");
            try {
                if (_config.appendTitle) {
                    var appendTitle = new ComponentLookup(_config.appendTitle, "appendTitle");
                }
            } catch (error) {}

            log.info('<= ptd-export-service.ArticleWrapper');


            /**
             * Get the sourceArticle
             * @returns {*}
             */
            function getArticle() {
                return sourceArticle;
            }

            /**
             * Deletes the sourceArticle
             */
            function deleteArticle() {
                log.info('=> ptd-export-service.ArticleWrapper.deleteArticle');
                if (sourceArticle) {
                    sourceArticle.delete();
                    sourceArticle = null;
                }
                log.info('<= ptd-export-service.ArticleWrapper.deleteArticle');
            }

            /**
             * Get article info from the source article
             * @returns {Object}
             */

            function getArticleInfo(includeInDesignImages, articleName) {
                var skippedParagraphStyles = [];

                var articleInfo = {
                    metadata: {
                        created: new Date(),
                        took: "?",
                        title: File.prototype.basename(articleName),
                        script: "v" + _config.version,
                        InDesign: "v" + app.version
                    },
                    components: [],
                    graphicsPathToName: {},
                    graphicsNameToPath: {},
                    styles: _config.styles,
                    output: {
                        htmlTags: _config.output.htmlTags,
                        htmlEncode: _ensureStylesHtmlEncode(_config.output),
                        cleanHyphenation: _config.output.cleanHyphenation
                    }
                };

                log.info('=> ptd-export-service.ArticleWrapper.getArticleInfo');

                var traverse = function(items, prefix, parentGroupId) {
                    prefix = prefix || '';
                    parentGroupId = parentGroupId || '';
                    var nth = 0;
                    _.each(items, function(amValue, amKey) {

                        var pageItem = amValue;

                        if (_typeof(pageItem, "ArticleMember") || _typeof(pageItem, "ArticleChild")) {
                            pageItem = amValue.itemRef;
                        }
                        var curN = nth++;
                        log.info('===== [' + prefix + curN + ']' + pageItem + '===== ');

                        if (_typeof(pageItem, "Group")) {
                            // group
                            var groupId = parentGroupId;
                            if (groupId == '') {
                                groupId = 'group_' + curN;
                            }
                            traverse(_(pageItem)._('articleChildren'), '' + curN + '.', groupId)
                        } else if (_typeof(pageItem, "TextFrame")) {
                            // text frame
                            _idStory(pageItem.parentStory, articleInfo, parentGroupId, skippedParagraphStyles);
                        } else if (_(pageItem)._('graphics').size() > 0) {
                            if (pageItem.graphics[0].itemLink == null) {
                                alert("Inline Graphic descobriu que não é uma imagem.")
                            } else {
                                _idGraphicInline(pageItem.graphics[0], articleInfo, includeInDesignImages, parentGroupId, false, null);
                            }
                        } else if (_config.exportDPSContent && _(pageItem)._('pageItems').size() > 0) {
                            // may be a (graphic) frame containing DPS items
                            var groupId = parentGroupId;
                            if (groupId == '') {
                                groupId = 'group_' + curN;
                            }
                            traverse(_(pageItem)._('articleChildren'), '' + curN + '.', groupId)
                        } else {
                            log.info("[{}] {} (UNSUPPORTED)", amKey, pageItem);
                            _debugID(pageItem);
                        }
                        log.info('================================= ');
                    });
                };

                traverse(sourceArticle.articleMembers());

                articleInfo.metadata.took = Math.round((new Date() - articleInfo.metadata.created) / 1000);
                log.info('<= ptd-export-service.ArticleWrapper.getArticleInfo #components:[{}] #graphics:[{}]', articleInfo.components.length, articleInfo.graphicsPathToName.keys().length);


                //Show an alert for the paragraphs that are excluded
                if (skippedParagraphStyles.length > 0) {
                    var alertMsg = "Os parágrafos com os estilos a seguir foram excluídos porque seu estilo de parágrafo não foi configurado no ptd-config.jsx";
                    for (var i = 0; i < skippedParagraphStyles.length; i++) {
                        alertMsg = alertMsg + "\n - " + skippedParagraphStyles[i];
                    }
                    alert(alertMsg);
                }
                return articleInfo;
            }

            /**
             * Create an article digital article from the given article info
             * @param {} articleInfo 
             */
            function createPtdArticle(articleInfo) {
                log.info('=> ptd-export-service.ArticleWrapper.createPtdArticle START');
                var ptdArticle = {
                    "data": {
                        "content": []
                    },
                    "version": "2.1"
                };
                var containers = {};
                var currentStyledBox;
                var currentSummaryBox;
                var previousPtdImage = null;
                var previousPtdComponent = null;
                var prevGroup = "";
                var curGroup = "";

                //Loop our found components, creating the digital article
                _.each(articleInfo.components, function(component) {
                    log.info('=> ptd-export-service.ArticleWrapper.createPtdArticle Component:{}', component.type);
                    log.info('=> ptd-export-service.ArticleWrapper.createPtdArticle Component:{}', component.identifier);
                    var ptdComponent = null;

                    //In this first section, we create ptdComponents first to add later.
                    //If it is a paragraph type
                    if (component.type === "paragraph" && component.identifier) {
                        //All text fields expect image text fields
                        if (!isImageTextField(component)) {
                            ptdComponent = {
                                "content": {},
                                "id": "",
                                "identifier": "",
                                "styles": {}
                            };
                            ptdComponent.id = "doc-indd-" + ptdArticle.data.content.length;
                            _set(ptdComponent.content, component.field, getInserts(component));
                            ptdComponent.identifier = component.identifier;

                            //captions
                        } else if (previousPtdComponent && (previousPtdComponent.identifier === "image" || previousPtdComponent.identifier === "ptdimage")) {
                            if (typeof previousPtdComponent.content[component.field] === 'undefined') {
                                log.info('<= ptd-export-service.createPtdArticle field ' + component.field + ' not found');
                            } else {
                                var inserts = getInserts(component);
                                if (previousPtdComponent.content[component.field].length > 0) {
                                    var softBreak = {
                                        "insert": "\n"
                                    }
                                    inserts.unshift(softBreak);
                                }
                                //Add all the text inserts
                                _.each(inserts, function(insert) {
                                    previousPtdComponent.content[component.field].push(insert)
                                })
                                //set component to be visible
                                previousPtdComponent.styles["inside-caption"] = "";
                            }
                        }
                    }
                    //if the component is a footer type.
                    else if (component.type === "footer") {
                        ptdComponent = {
                            "content": {
                                "text": [{
                                    "insert": ""
                                }]
                            },
                            "id": "",
                            "identifier": "footer",
                            "styles": {
                                "text-align": "_align-middle"
                            }
                        }
                        ptdComponent.id = "doc-indd-" + ptdArticle.data.content.length;
                        ptdComponent.content.text[0].insert = component.page;
                    }
                    //if the component is a graphical header (title)
                    else if (component.type === "graphicheader") {
                        ptdComponent = JSON.parse(JSON.stringify(_config.imageComponent.definition));
                        ptdComponent.id = "doc-indd-" + ptdArticle.data.content.length;
                        ptdComponent.content.image.id = component.id;
                        //if the component is MathML
                    } else if (component.type == "mathML") {
                        ptdComponent = JSON.parse(JSON.stringify(_config.mathComponent.definition));
                        ptdComponent.id = "doc-indd-math-" + ptdArticle.data.content.length;
                        ptdComponent.content.html = component.mathML;
                        ptdComponent.data["mathml-html-data"] = component.id;
                        //If the component is an inline image
                    } else if (component.type === "graphic") {
                        component.identifier = "ptdimage";
                        ptdComponent = JSON.parse(JSON.stringify(_config.ptdimageComponent.definition));
                        ptdComponent.id = "doc-indd-" + ptdArticle.data.content.length;
                        ptdComponent.content.ptdimage.id = component.id;
                        ptdComponent.inlineStyles.width = component.width;
                        if (component.inline) {
                            ptdComponent.styles["ptdimage-style"] = "_inline";
                        }
                        ptdComponent.styles["inside-caption"] = "_caption-none";
                    }

                    //Apply the configured digitalComponentStyle
                    if (component.digitalComponentStyle && _config.digitalComponentStyles) {
                        log.info('<= ptd-export-service.createPtdArticle apply style ' + component.digitalComponentStyle);
                        digitalComponentStyle = _config.digitalComponentStyles[component.digitalComponentStyle];
                        if (digitalComponentStyle) {
                            ptdComponent.styles = digitalComponentStyle.styles;
                            ptdComponent.inlineStyles = digitalComponentStyle.inlineStyles;
                        } else {
                            alert("Warning, the configured digitalComponentStyle \'" + component.digitalComponentStyle + "\' could not be found.");
                        }
                    }

                    //Add the component to the article
                    if (ptdComponent) {
                        var previousComponent;
                        if (ptdArticle.data.content.length > 0) {
                            previousComponent = ptdArticle.data.content[ptdArticle.data.content.length - 1];
                        }
                        ptdComponent.id = "doc-indd-" + ptdArticle.data.content.length;
                        previousPtdComponent = ptdComponent;
                        var ptdReturned = null;

                        //component is the component we are looping
                        //ptdComponent is the component we are creating
                        //previousComponent is the component in the previous article array
                        ptdReturned = processptdComponent(component, ptdComponent, previousComponent);
                        if (ptdReturned != null) {
                            ptdArticle.data.content.push(ptdReturned);
                        }
                    }
                });

                function processptdComponent(component, ptdComponent, previousComponent) {
                    if (component.text) {
                        //log.info(component.text);
                    }
                    if (_config.createContainerForGroup && component.group != "" && !component.styledbox && !component.summaryContainers && !component.collapsiblebox && (component.identifier != "quote" && component.identifier != "quotewithheader")) {
                        var temp = processContainers(component, ptdComponent, previousComponent);
                        return temp;
                    } else if (component.styledbox) {
                        var temp = processStyledBox(component, ptdComponent, previousComponent);
                        return temp;
                    } else if (component.summaryContainers) {
                        var temp = processSummaryContainers(component, ptdComponent, previousComponent);
                        return temp;
                    } else if (component.collapsiblebox || component.collapsible) {
                        processCollapsibleBoxes(component, ptdComponent, previousComponent);
                    } else if (component.header) {
                        return processTitles(component, ptdComponent, previousComponent);
                    } else if (component.appendTitle) {
                        processAppendTitle(component, ptdComponent, previousComponent);
                    } else if (component.quotes) {
                        return processQuote(component, ptdComponent, previousComponent);
                    } else if ((component.identifier == "quote" || component.identifier == "quotewithheader") && component.field == "author") {
                        processQuoteWithAuthor(component, ptdComponent, previousComponent);
                    } else if (component.identifier == "quotewithheader") {
                        return processQuoteWithHeader(component, ptdComponent, previousComponent);
                    } else if (component.identifier == "ptdimage") {
                        return processPtdImage(component, ptdComponent, previousComponent);
                    } else if (component.identifier == "subtitle") {
                        return processSubtitle(component, ptdComponent, previousComponent);
                    } else {
                        return ptdComponent;
                    }
                }

                function processSummaryContainers(component, ptdComponent, previousComponent) {
                    if (previousComponent.styles.style && previousComponent.styles.style == component.summaryContainers.style && component.group == curGroup && component.group != "") {
                        delete component.summaryContainers;
                        ptdComponent = processptdComponent(component, ptdComponent, previousComponent);
                        if (ptdComponent != null) {
                            currentSummaryBox.containers['main'].push(ptdComponent);
                        }
                    } else {
                        //fresh box, add to new container, and add
                        var container = {
                            "containers": {
                                "main": []
                            },
                            "content": {},
                            "id": "",
                            "identifier": "container",
                            "styles": {}
                        }
                        container.styles.style = component.summaryContainers.style;
                        currentSummaryBox = container;
                        container.id = "doc-indd-" + component.identifier + ptdArticle.data.content.length;

                        delete component.summaryContainers;
                        ptdComponent = processptdComponent(component, ptdComponent, previousComponent);
                        if (ptdComponent != null) {
                            currentSummaryBox.containers['main'].push(ptdComponent);
                        }
                        return container;
                    }
                }

                function processPtdImage(component, ptdComponent, previousComponent) {
                    previousPtdImage = ptdComponent;
                    return ptdComponent;
                }

                function processSubtitle(component, ptdComponent, previousComponent) {
                    ptdComponent.content.title = ptdComponent.content.text;
                    delete ptdComponent.content.text;
                    return ptdComponent;
                }

                function processQuote(component, ptdComponent, previousComponent) { //test quote again
                    previousComponent = previousComponentNotImage(ptdArticle.data.content, 1);
                    if (previousComponent.identifier == "quotewithheader" || previousComponent.identifier == "quote") {
                        delete component.quotes;
                        ptdComponent = processptdComponent(component, ptdComponent, previousComponent);
                        if (ptdComponent != null) {
                            previousComponent.containers.main.push(ptdComponent);
                        }
                    } else {
                        return makeQuoteContainer(component, ptdComponent, previousComponent);
                    }
                }

                function processQuoteWithAuthor(component, ptdComponent, previousComponent) {
                    //Add the quote author to the previous quote
                    var previousComponent = previousComponentNotImage(ptdArticle.data.content, 1);
                    previousComponent.content.author = [];
                    previousComponent.content.author = getInserts(component);
                }

                function processQuoteWithHeader(component, ptdComponent, previousComponent) {
                    ptdComponent.containers = {
                        "main": []
                    }
                    //clear out content
                    ptdComponent.content = {};
                    ptdComponent.identifier = "quotewithheader";
                    ptdComponent.content.title = [];
                    ptdComponent.content.title = getInserts(component);
                    return ptdComponent;
                }

                function previousComponentNotImage(ptdArticleContent, index) {
                    var tempArticleContent = ptdArticleContent[ptdArticleContent.length - index];
                    if (tempArticleContent.identifier == "container" && tempArticleContent.containers.main.length > 0) {
                        return previousComponentNotImage(tempArticleContent.containers.main, 1);
                    } else if (tempArticleContent.identifier != "ptdimage") {
                        return tempArticleContent;
                    } else {
                        return previousComponentNotImage(ptdArticleContent, index + 1);
                    }
                }

                function processAppendTitle(component, ptdComponent, previousComponent) {
                    if (ptdArticle.data.content.length > 0) {
                        if (previousComponent.identifier == component.identifier) {
                            previousComponent.content.text.push({
                                "insert": " "
                            });
                            previousComponent.content.text.push(getInserts(component)[0]);
                        }
                    }
                }

                function processCollapsibleBoxes(component, ptdComponent, previousComponent) {
                    var headerTitle = getHeaderTitle(component);
                    var previousComponent = ptdArticle.data.content[ptdArticle.data.content.length - 1];

                    //check if there is a previous collapsbile box
                    if ((ptdArticle.data.content.length > 0 && previousComponent.identifier == "collapsiblebox" && previousComponent.content.headerwithline[0].insert == headerTitle)) {
                        delete component.collapsiblebox;
                        delete component.collapsible;
                        ptdComponent = processptdComponent(component, ptdComponent, previousComponent)
                        if (ptdComponent != undefined)
                            previousComponent.containers.main.push(ptdComponent);
                    } else { //new collapsible box
                        var newBox = JSON.parse(JSON.stringify(component.collapsiblebox.definition));
                        newBox.id = "doc-indd-" + component.identifier + ptdArticle.data.content.length;
                        delete component.collapsiblebox;
                        delete component.collapsible;
                        ptdComponent = processptdComponent(component, ptdComponent, previousComponent)
                        newBox.containers.main.push(ptdComponent);
                        newBox.content.headerwithline[0].insert = headerTitle;
                        ptdArticle.data.content.push(newBox);
                    }
                }

                /*function processCollapsibleBoxes(component, ptdComponent, previousComponent) {
                    var headerTitle = getHeaderTitle(component);
                    var previousComponent = ptdArticle.data.content[ptdArticle.data.content.length - 1];

                    //check if there is a previous collapsbile box
                    if ((ptdArticle.data.content.length > 0 && previousComponent.identifier == "collapsiblebox" && previousComponent.content.headerwithline[0].insert == headerTitle)) {
                        prevGroup = curGroup;
                        curGroup = component.group;

                        //STYLED BOXES
                        if (component.styledbox) {
                            if (previousComponent.containers && previousComponent.containers.main[previousComponent.containers.main.length - 1].identifier == "container") {
                                previousComponent.containers.main[previousComponent.containers.main.length - 1] = styledBoxInCollapsible(component, ptdComponent, previousComponent.containers.main[previousComponent.containers.main.length - 1]);
                            } else {
                                previousComponent.containers.main.push(styledBoxInCollapsible(component, ptdComponent, null));
                            }
                        }
                        //CONTAINERS
                        else if (_config.createContainerForGroup && component.group != "") {
                            container = makeContainer(component);
                            container.containers['main'].push(ptdComponent);
                            if (component.group != prevGroup)
                                previousComponent.containers.main.push(container);
                        }
                        //OTHER
                        else {
                            previousComponent.containers.main.push(ptdComponent);
                        }

                    } else { //new collapsible box
                        var newBox = JSON.parse(JSON.stringify(component.collapsiblebox.definition));
                        var newList;
                        newBox.id = "doc-indd-" + component.identifier + ptdArticle.data.content.length;
                        //if it's a list-item
                        if ((component.identifier == "list-item" || component.container) && !component.styledbox) {
                            newList = JSON.parse(JSON.stringify(component.container.definition));
                            newList.id = "doc-indd-" + component.identifier + ptdArticle.data.content.length;
                            if (newList.identifier == "numbered-list" || newList.identifier == "lowerletters-list" || newList.identifier == "upperletters-list" || newList.identifier == "upperroman-list") {
                                newList.data.start = component.start;
                            }
                            listItem = createListItem(ptdComponent);
                            newList.containers[component.container.containerName].push(listItem);
                            newBox.containers.main.push(newList);
                        } else if (component.styledbox) {
                            newBox.containers.main.push(styledBoxInCollapsible(component, ptdComponent, null));
                        } else if (_config.createContainerForGroup && component.group != "") {
                            container = makeContainer(component);
                            container.containers['main'].push(ptdComponent);
                            newBox.containers.main.push(container);
                        } else {
                            newBox.containers.main.push(ptdComponent);
                        }
                        newBox.content.headerwithline[0].insert = headerTitle;
                        curGroup = component.group;
                        ptdArticle.data.content.push(newBox);
                    }
                }*/

                function processStyledBox(component, ptdComponent, previousComponent) {
                    if (previousComponent.styles.style && previousComponent.styles.style == component.styledbox.style && previousComponent.containers) {
                        delete component.styledbox;
                        ptdComponent = processptdComponent(component, ptdComponent, previousComponent);
                        if (ptdComponent != null) {
                            if (ptdComponent.identifier == "ptdimage") {
                                currentStyledBox.styles["container-inline"] = "_inline";
                            }
                            currentStyledBox.containers['main'].push(ptdComponent);
                        }
                    } else {
                        //fresh box, add to new container, and add
                        makeStyledBox(component);
                        delete component.styledbox;
                        ptdComponent = processptdComponent(component, ptdComponent, previousComponent);
                        if (ptdComponent != null) {
                            if (ptdComponent.identifier == "ptdimage") {
                                currentStyledBox.styles["container-inline"] = "_inline";
                            }
                            currentStyledBox.containers['main'].push(ptdComponent);
                        }
                        return container;
                    }
                }

                function processContainers(component, ptdComponent, previousComponent) {
                    var container = containers[component.group];
                    if (!container) {
                        //create a new container and add it to the story
                        container = makeContainer(component);
                        curGroup = component.group;
                        component.group = '';
                        ptdComponent = processptdComponent(component, ptdComponent, previousComponent)
                        if (ptdComponent != null) {
                            if (ptdComponent.identifier == "ptdimage") {
                                container.styles["container-inline"] = "_inline";
                            }
                            container.containers['main'].push(ptdComponent);
                        }
                        return container;
                    } else {
                        component.group = '';
                        ptdComponent = processptdComponent(component, ptdComponent, previousComponent)
                        if (ptdComponent != null) {
                            if (ptdComponent.identifier == "ptdimage") {
                                container.styles["container-inline"] = "_inline";
                            }
                            container.containers['main'].push(ptdComponent);
                        }
                    }
                }

                function processTitles(component, ptdComponent, previousComponent) {
                    if (component.identifier == "titlewi" || component.identifier == "titlewih1" || component.identifier == "titlewih2" || component.identifier == "titlewih3" || component.identifier == "titlewih4" || component.identifier == "titlewih5" || component.identifier == "titlewih6" || component.identifier == "titlewithicon" || component.identifier == "titlewithiconh1" || component.identifier == "titlewithiconh2" || component.identifier == "titlewithiconh3" || component.identifier == "titlewithiconh4" || component.identifier == "titlewithiconh5" || component.identifier == "titlewithiconh6") {
                        var header = processTitleWithImage(component, ptdComponent, previousComponent);
                        return header;
                    } else if (component.identifier == "titlewithimage") {
                        //Add the component inside an existing header, come back to this
                        if (ptdArticle.data.content[ptdArticle.data.content.length - 1].identifier == "titlewithimage") {
                            ptdComponent.identifier = component.header.contentType;
                            ptdArticle.data.content[ptdArticle.data.content.length - 1].containers.main.push(ptdComponent);
                            return null;
                        } else {
                            //Create a new header and add it to the story
                            var header = JSON.parse(JSON.stringify(component.header.definition));
                            header.id = "doc-indd-" + component.identifier + ptdArticle.data.content.length;
                            ptdComponent.identifier = component.header.contentType;
                            header.containers.main.push(ptdComponent);
                            //insert image from before
                            header.content.imageicon = component.image;
                            if (ptdComponent.styles.style) {
                                header.styles.style = ptdComponent.styles.style;
                            }
                            return header;
                        }
                    } else if (component.identifier == "titlewithimagebackground") {
                        var header = JSON.parse(JSON.stringify(component.header.definition));
                        header.id = "doc-indd-" + component.identifier + ptdArticle.data.content.length;
                        header.content.title = ptdComponent.content.text;
                        //insert image from before
                        if (ptdArticle.data.content.length > 0) {
                            header.content.image = component.image;
                        }
                        if (ptdComponent.styles.style) {
                            header.styles.style = ptdComponent.styles.style;
                        }
                        return header;
                    }
                }

                function getHeaderTitle(component) {
                    return component.collapsiblebox.definition.content.headerwithline[0].insert;
                }

                function makeContainer(component) {
                    if (component.group != "") {
                        var container = containers[component.group];
                    }
                    if (!container) {
                        container = {
                            "containers": {
                                "main": []
                            },
                            "content": {},
                            "id": "",
                            "identifier": "container",
                            "styles": {}
                        }
                    }
                    container.id = "doc-indd-" + component.identifier + ptdArticle.data.content.length;
                    if (component.inline) {
                        container.styles["container-inline"] = "_inline";
                    };
                    if (component.group != "") {
                        containers[component.group] = container;
                    }

                    return container;
                }

                function makeStyledBox(component) {
                    container = {
                        "containers": {
                            "main": []
                        },
                        "content": {},
                        "id": "",
                        "identifier": "container",
                        "styles": {}
                    }
                    container.styles.style = component.styledbox.style;
                    currentStyledBox = container;

                    container.id = "doc-indd-" + component.identifier + ptdArticle.data.content.length;
                    return container;
                }

                function processTitleWithImage(component, ptdComponent, previousComponent) {
                    var header = JSON.parse(JSON.stringify(component.header.definition));
                    header.id = "doc-indd-" + component.identifier + ptdArticle.data.content.length;

                    header.content[header.content.titlewi ? "titlewi" : "titlewih" + applyRegexToText(component.identifier, "\\d(?=\\D*$)")] = ptdComponent.content.text;
                    header.content.imageicon = component.image;

                    if (ptdComponent.styles.style) {
                        header.styles.style = ptdComponent.styles.style;
                    }
                    return header;
                }

                function makeQuoteContainer(component, ptdComponent, previousComponent) {
                    //create container-like section
                    var quote = {
                        "containers": {
                            "main": []
                        },
                        "content": {},
                        "id": "",
                        "identifier": "quote",
                        "styles": {}
                    };
                    if ("style" in component && component.style) {
                        var quoteOption = returnKeyIfInObjectArrayExists(_config.quotes, component.style);
                        if (quoteOption != null && quoteOption != '_default') {
                            quote.styles.style = quoteOption;
                        }
                    }
                    //add content to container
                    delete component.quotes;
                    ptdComponent = processptdComponent(component, ptdComponent, previousComponent)
                    quote.containers.main.push(ptdComponent);
                    return quote;
                }

                log.info('=> ptd-export-service.ArticleWrapper.createPtdArticle END');

                return ptdArticle;
            }


            /**
             * Check if the component is an image field instead of a regular text field
             * @param {} component 
             */
            function isImageTextField(component) {
                //Check if the image cmoponent is configured 
                if (!_config.imageComponent && !_config.imageComponent.textFilters) {
                    return false;
                }

                //Walk through the textFilters of the image component 
                for (i = 0; i < _config.imageComponent.textFilters.length; i++) {
                    if (_config.imageComponent.textFilters[i] === component.textFilter) {
                        return true;
                    }
                }

                return false;
            }

            /**
             * Get the insert text structure of the component
             */
            function getInserts(component) {
                var inserts = [];
                _.each(component.ranges, function(range) {
                    var insert = {
                        "insert": ""
                    }

                    //Check for character style format
                    if (range.tags.bold || range.tags.italic || range.tags.superscript || range.tags.subscript || range.hyperlinkURL || range.tags.underline ||
                        range.tags.strikethrough || range.tags.uppercase || range.tags.lowercase || range.tags.titlecase || range.color || range.tags.characterstyle) {
                        _set(insert, "attributes", {});
                        if (range.tags.bold)
                            insert.attributes.bold = true;
                        if (range.tags.italic)
                            insert.attributes.italic = true;
                        if (range.tags.superscript)
                            insert.attributes.super = true;
                        if (range.tags.subscript)
                            insert.attributes.sub = true;
                        if (range.hyperlinkURL)
                            insert.attributes.href = range.hyperlinkURL;
                        if (range.tags.underline)
                            insert.attributes.underline = true;
                        if (range.tags.strikethrough)
                            insert.attributes.strike = true;
                        if (range.tags.uppercase)
                            insert.attributes["text-transform"] = "uppercase";
                        if (range.tags.lowercase)
                            insert.attributes["text-transform"] = "lowercase";
                        if (range.tags.titlecase)
                            insert.attributes["text-transform"] = "capitalize";
                        if (range.color)
                            insert.attributes.color = range.color;
                        if (range.tags.characterstyle) {
                            insert.attributes["character-style"] = range.tags.characterstyle;
                        }
                    }

                    //Set the content of the insert
                    insert.insert = convertCharacters(range.contents);
                    inserts.push(insert);
                });

                return inserts;
            }

            /**
             * Replace characters that are not supported by the digital editor
             * @param {*} text 
             * @returns 
             */
            function convertCharacters(text) {
                //log.info('=> ptd-export-service.convertCharacters()');
                //Remove tab
                text = text.split('\t').join(' ');
                //Replace characters from the charConvert section
                pairs = _config.charConvert;
                if (pairs) {
                    //log.info('=> ptd-export-service.convertCharacters(charConvert.len:{})', pairs.length);
                    _.each(pairs, function(pair) {
                        text = text.split(pair[0]).join(pair[1]);
                    });
                }

                //log.info('<= ptd-export-service.convertCharacters()');
                return text;
            }

            /**
             * Create the article in Enterprise 
             * @param {} article Article JSON
             * @param {} articleInfo  Reference to the article info
             * @param {} layoutID Reference to layout object ID
             * @param {} template Reference to user selected template
             */
            function uploadArticleToEnterprise(article, articleInfo, layoutID, template) {
                log.info('=> ptd-export-service.ArticleWrapper.uploadArticleToEnterprise START');

                //Get the Channel, Category and Status of the Layout
                var createObjectsRequest = {
                    "method": "CreateObjects",
                    "id": "1",
                    "params": [{
                        "Lock": false,
                        "Objects": [{
                            "__classname__": "Object",
                            "MetaData": {
                                "__classname__": "MetaData",
                                "BasicMetaData": {
                                    "__classname__": "BasicMetaData",
                                    "Name": articleInfo.metadata.title,
                                    "Type": "Article",
                                    "Publication": {
                                        "Id": "",
                                        "Name": "",
                                        "__classname__": "Publication"
                                    },
                                    "Category": {
                                        "Id": "",
                                        "Name": "",
                                        "__classname__": "Category"
                                    }
                                },
                                "WorkflowMetaData": {
                                    "__classname__": "WorkflowMetaData",
                                    "State": null
                                },
                                "ExtraMetaData": [{
                                        "Property": "C_CS_FILEFORMATVERSION",
                                        "Values": [
                                            "2.1"
                                        ],
                                        "__classname__": "ExtraMetaData"
                                    },
                                    {
                                        "Property": "C_PTD_ARTICLEDATA",
                                        "Values": [
                                            JSON.stringify(article)
                                        ],
                                        "__classname__": "ExtraMetaData"
                                    }, {
                                        "Property": "C_INDDID",
                                        "Values": [
                                            layoutID
                                        ],
                                        "__classname__": "ExtraMetaData"
                                    }
                                ],
                                "RightsMetaData": {
                                    "__classname__": "RightsMetaData"
                                },
                                "SourceMetaData": {
                                    "__classname__": "SourceMetaData"
                                },
                                "ContentMetaData": {
                                    "__classname__": "ContentMetaData",
                                    "Format": "application\/ww-digital+json+printtodigital" //Workaround to bypass CS Plugin article format upgrades
                                }
                            },
                            "Relations": [],
                            "Targets": []
                        }],
                        "Ticket": app.entSession.activeTicket
                    }],
                    "jsonrpc": "2.0"
                }

                //Get the selected look & feel and component set of the article template 
                templateInfo = getObject(template.id);
                for (i = 0; i < templateInfo.result.Objects[0].MetaData.ExtraMetaData.length; i++) {
                    extraMetaData = templateInfo.result.Objects[0].MetaData.ExtraMetaData[i];
                    if (extraMetaData.Property == "C_CS_STYLEID" || extraMetaData.Property == "C_CS_COMPONENTSET") {
                        createObjectsRequest.params[0].Objects[0].MetaData.ExtraMetaData.push(extraMetaData);
                    }
                }

                //Take over the brand & category of template, status is automatically set to the first status
                createObjectsRequest.params[0].Objects[0].MetaData.BasicMetaData.Publication = templateInfo.result.Objects[0].MetaData.BasicMetaData.Publication;
                createObjectsRequest.params[0].Objects[0].MetaData.BasicMetaData.Category = templateInfo.result.Objects[0].MetaData.BasicMetaData.Category;

                //Add image relations
                _.each(articleInfo.components, function(component) {
                    if (component.type === "graphic") {
                        var relation = {
                            "__classname__": "Relation",
                            "Parent": "",
                            "Child": component.id,
                            "Type": "Placed"
                        }

                        createObjectsRequest.params[0].Objects[0].Relations.push(relation);
                    }
                });

                //Add dossier relations
                var dossierIds = app.getDossiersForItem(layoutID);
                _.each(dossierIds, function(dossierId) {
                    var relation = {
                        "__classname__": "Relation",
                        "Parent": dossierId,
                        "Type": "Contained"
                    };

                    createObjectsRequest.params[0].Objects[0].Relations.push(relation);
                });

                //Add Issue Target
                var target = {
                    "__classname__": "Target",
                    "Issue": {
                        "__classname__": "Issue",
                        "Id": issueId,
                        "Name": issueName
                    },
                    "PubChannel": {
                        "__classname__": "PubChannel",
                        "Id": pubChannelId,
                        "Name": pubChannelName,
                    },
                    "Editions": []
                };
                createObjectsRequest.params[0].Objects[0].Targets.push(target);
                log.info("All " + JSON.stringify(createObjectsRequest));

                log.info('=> ptd-export-service.ArticleWrapper.uploadArticleToEnterprise END');

                //Create the article
                return JSON.parse(app.jsonRequest(getServerUrl(), JSON.stringify(createObjectsRequest)));
            }

            function UpdatePublishedIn(newId) {
                var updateObjectsRequest = {
                    "method": "SetObjectProperties",
                    "params": [{
                        "__classname__": "Object",
                        "ID": newId,
                        "MetaData": {
                            "__classname__": "MetaData",
                            "BasicMetaData": {
                                "__classname__": "BasicMetaData",
                                "ID": newId
                            },
                        },
                        "Targets": [{
                            "__classname__": "Target",
                            "Editions": [],
                            "Issue": {
                                "__classname__": "Issue",
                                "Id": issueId,
                                "Name": issueName
                            },
                            "PubChannel": {
                                "__classname__": "PubChannel",
                                "Id": pubChannelId,
                                "Name": pubChannelName
                            }
                        }],
                        "Ticket": app.entSession.activeTicket
                    }],
                    "id": 1,
                    "jsonrpc": "2.0"
                }

                return JSON.parse(app.jsonRequest(getServerUrl(), JSON.stringify(updateObjectsRequest)));
            }

            /**
             * Get article info from this story in the source article
             * @param story
             * @param articleInfo
             * @private
             */
            function _idStory(story, articleInfo, groupId, skippedParagraphStyles) {
                log.info('=> ptd-export-service.ArticleWrapper._idStory({})', story);

                _applyAll(story.paragraphs, _idParagraph, articleInfo, groupId, skippedParagraphStyles);

                log.info('<= ptd-export-service.ArticleWrapper._idStory');
            }

            /**
             * Get article info from this paragraph
             * @param idParagraph
             * @param key
             * @param articleInfo
             * @private
             */
            function _idParagraph(idParagraph, key, articleInfo, groupId, skippedParagraphStyles) {
                //if any of the textstyles have an image, they need to be grouped inline. We ignore inline bulleted images.
                if ((idParagraph.allGraphics.length > 0 && groupId == "")) {
                    groupId = "inline_group_" + key + "_" + Math.floor(Math.random() * 100000000) + 1;
                }
                try {
                    if (idParagraph.mtAllMathZones.length > 0 && groupId == "") {
                        groupId = "inline_group_" + key + "_" + Math.floor(Math.random() * 100000000) + 1;
                    }
                } catch (err) {}
                if (idParagraph.parentTextFrames.length > 0) {
                    if (idParagraph.parentTextFrames[0].parentPage) {
                        var curPage = idParagraph.parentTextFrames[0].parentPage.name;
                        if (!(oldPagNums.indexOf(curPage) > -1)) {
                            //add footer component
                            var footer = {
                                identifier: "footer",
                                type: "footer",
                                page: curPage,
                                group: "",
                                storyid: idParagraph.parentStory.id
                            }
                            _add(articleInfo.components, footer);

                            oldPagNums.push(curPage);
                        }
                    }
                }

                var component = {
                    type: "paragraph",
                    style: idParagraph.appliedParagraphStyle.name,
                    field: "text",
                    group: groupId,
                    storyid: idParagraph.parentStory.id
                };

                log.info('=> ptd-export-service.ArticleWrapper._idParagraph.contents({})', idParagraph.contents);

                // Get the name of the component and extract the field if configured, set the append setting for later usage
                var componentName = textStyles.lookup(idParagraph.appliedParagraphStyle.name);
                if (appendTitle) {
                    var appendName = appendTitle.lookup(idParagraph.appliedParagraphStyle.name);
                    if (appendName) {
                        _set(component, "appendTitle", true);
                    }
                }
                if (!componentName) {
                    log.warning("Paragraph with style '" + idParagraph.appliedParagraphStyle.name + "' is excluded because the style isn't configured in ptd-config.jsx");
                    if (skippedParagraphStyles.indexOf(idParagraph.appliedParagraphStyle.name) == -1) {
                        skippedParagraphStyles.push(idParagraph.appliedParagraphStyle.name);
                    }
                    return;
                }
                _set(component, "textFilter", componentName);

                //Check if a digitalComponentStyle is configured
                if (componentName.indexOf("#") != -1) {
                    componentField = componentName.substring(componentName.indexOf("#") + 1);
                    _set(component, "digitalComponentStyle", componentField);
                    componentName = componentName.substring(0, componentName.indexOf("#"));
                }

                //Check if a field is configured
                if (componentName.indexOf(".") != -1) {
                    componentField = componentName.substring(componentName.indexOf(".") + 1);
                    _set(component, "field", componentField);
                    componentName = componentName.substring(0, componentName.indexOf("."));
                }

                //Set the digital component name
                _set(component, "identifier", componentName);

                //create components
                _idParagraphTextRanges(idParagraph, idParagraph.textStyleRanges, articleInfo, component, groupId);

                //create footnotes if needed
                if (idParagraph == idParagraph.parentStory.paragraphs[-1]) {
                    //prepare footnotes numbers..
                    footnoteNumber = 1;

                    //loop for each footer
                    _.each(footnotes, function(footnote) {
                        //_processTextRanges(footnote.textStyleRanges);
                        component = {
                            type: "paragraph",
                            style: idParagraph.appliedParagraphStyle.name,
                            field: "text",
                            group: groupId,
                            storyid: idParagraph.parentStory.id
                        };

                        // Get the name of the component and extract the field if configured, set the append setting for later usage
                        var componentName;
                        if (footnote.textStyleRanges.length > 0) {
                            componentName = textStyles.lookup(footnote.textStyleRanges[0].appliedParagraphStyle.name);
                        }
                        if (!componentName) {
                            log.warning("Paragraph with style '" + idParagraph.appliedParagraphStyle.name + "' is excluded because the style isn't configured in ptd-config.jsx");
                            if (skippedParagraphStyles.indexOf(idParagraph.appliedParagraphStyle.name) == -1) {
                                skippedParagraphStyles.push(idParagraph.appliedParagraphStyle.name);
                            }
                            return;
                        }
                        _set(component, "textFilter", componentName);

                        //Check if a digitalComponentStyle is configured
                        if (componentName.indexOf("#") != -1) {
                            componentField = componentName.substring(componentName.indexOf("#") + 1);
                            _set(component, "digitalComponentStyle", componentField);
                            componentName = componentName.substring(0, componentName.indexOf("#"));
                        }

                        //Check if a field is configured
                        if (componentName.indexOf(".") != -1) {
                            componentField = componentName.substring(componentName.indexOf(".") + 1);
                            _set(component, "field", componentField);
                            componentName = componentName.substring(0, componentName.indexOf("."));
                        }

                        //Set the digital component name
                        _set(component, "identifier", componentName);

                        _idParagraphTextRanges(idParagraph, footnote.textStyleRanges, articleInfo, component, groupId);
                    });

                    footnotes = [];
                }

                log.info('<= ptd-export-service.ArticleWrapper._idParagraph');
            }

            /**
             * Get article info from textRanges in this paragraph
             * @param idParagraphTextRanges
             * @param textStyleRanges
             * @param articleInfo
             * @param component
             * @private
             */
            function _idParagraphTextRanges(idParagraph, textStyleRanges, articleInfo, component, groupId) {
                var textRanges = [],
                    text = "",
                    styles = articleInfo.styles,
                    allStyleTags = ["bold", "italic", "superscript", "subscript", "underline", "strikethrough", "uppercase", "lowercase", "titlecase", "characterstyle"],
                    tags = {},
                    appliedColor = '',
                    skipMathZone = false,
                    indexMathML = 1,
                    mathMLFileName,
                    paraEnd = idParagraph.characters.lastItem().index

                _processTextRanges(textStyleRanges);
                _addComponent();

                //add footnotes check
                if (idParagraph.footnotes.length > 0) {
                    //add it to the running list of footnotes
                    _.each(idParagraph.footnotes, function(footnote) {
                        footnotes.push(footnote);
                    });
                }

                component = JSON.parse(JSON.stringify(component));
                _set(component, "text", "");
                _set(component, "ranges", []);
                text = "";

                function _processTextRanges(textStyleRanges) {
                    _.each(textStyleRanges, function(textStyleRange) {
                        _processRange(textStyleRange);
                    });
                }

                //Process a TextRange to find any inline Objects
                function _processRange(textStyleRange) {
                    log.info('=> ptd-export-service.ArticleWrapper.textStyleRange({})', textStyleRange.contents);
                    //set styled box.
                    if (_config.styledBox && _config.styledBox[textStyleRanges[0].appliedParagraphStyle.name]) {
                        _set(component, "styledbox", _config.styledBox[textStyleRanges[0].appliedParagraphStyle.name]);
                    }
                    //set summary box.
                    if (_config.summaryContainers && _config.summaryContainers[textStyleRanges[0].appliedParagraphStyle.name]) {
                        _set(component, "summaryContainers", _config.summaryContainers[textStyleRanges[0].appliedParagraphStyle.name]);
                    }
                    if (typeof(textStyleRange.insertionPoints.item(0).mtIsMathZone) === 'boolean' && textStyleRange.insertionPoints.item(0).mtIsMathZone) {
                        _mathZone(textStyleRange);
                        return;
                    }

                    //not a mathZone
                    skipMathZone = false;
                    var textBuilt = "";
                    _.each(textStyleRange.characters, function(searchChar) {
                        if (searchChar.index < paraEnd + 1) {
                            if (searchChar.contents == "￼") {
                                if (searchChar.textFrames.length > 0) {
                                    _inlineTextFrame(textStyleRange, textBuilt, searchChar);
                                    textBuilt = "";
                                } else if (searchChar.allGraphics.length > 0) {
                                    _graphicsFrame(textStyleRange, textBuilt, searchChar, textStyleRanges);
                                    textBuilt = "";
                                }
                            }
                            //FOOTNOTE_SYMBOL
                            else if (String(searchChar.contents) == "FOOTNOTE_SYMBOL") {
                                var footnoteType = app.activeDocument.footnoteOptions.footnoteNumberingStyle;
                                if (String(footnoteType) == "ASTERISKS") {
                                    textBuilt += "*";
                                } else {
                                    textBuilt += footnoteNumber++;
                                }
                            } else {
                                textBuilt += searchChar.texts[0].contents; //fixes special characters
                            }
                        }
                    });
                    //add final text
                    text += textBuilt;
                    _setRanges(textStyleRange, textBuilt);
                }


                function _inlineTextFrame(textStyleRange, textBuilt, searchChar) {
                    text += textBuilt;
                    _setRanges(textStyleRange, textBuilt);
                    _processTextRanges(searchChar.textFrames[0].textStyleRanges);
                }

                function _graphicsFrame(textStyleRange, textBuilt, searchChar, textStyleRanges) {
                    //component
                    text += textBuilt;
                    _setRanges(textStyleRange, textBuilt);
                    _addComponent();

                    //clear text component
                    text = "";
                    textRanges = [];

                    //add image
                    _idGraphicInline(searchChar.allGraphics[0], articleInfo, false, groupId, true, textStyleRanges);

                    //Start a new component
                    component = JSON.parse(JSON.stringify(component));
                    _set(component, "text", "");
                    _set(component, "ranges", []);
                    _set(component, "inline", true);
                }

                function _mathZone(textStyleRange) {
                    try {
                        if (!skipMathZone) {
                            skipMathZone = true;
                            _set(component, "inline", true);
                            _addComponent();

                            var story = textStyleRange.parent;
                            mathMLFileName = app.activeDocument.entMetaData.get("Core_Name") + "_ml_" + story.id + "_" + idParagraph.index + "_" + indexMathML + ".png";

                            var mathMLLink = findLinkByName(app.activeDocument, mathMLFileName, story.id + "_" + idParagraph.index + "_" + indexMathML);

                            //if (mathMLLink != null) {
                            indexMathML++;

                            //Create the MathML component
                            var mathML = '';
                            if (_config.mockMathML) {
                                mathML = "<math xmlns = \"http://www.w3.org/1998/Math/MathML\"><mrow><msup><mi>a</mi><mn>2</mn></msup><mo>+</mo><msup><mi>b</mi><mn>2</mn></msup><mo> = </mo><msup><mi>c</mi><mn>2</mn></msup></mrow></math>";
                            } else {
                                mathML = textStyleRange.insertionPoints.item(0).mtExportMathZoneAsMathML();
                            }
                            //var mathML = "<math xmlns=\"http://www.w3.org/1998/Math/MathML\" display=\"block\"> <mi>x</mi> <mo>=</mo><mrow><mrow><mo>&#x2212;</mo><mi>b</mi><mo>&#x00B1;</mo><msqrt><msup><mi>b</mi><mn>2</mn></msup><mo>&#x2212;</mo><mn>4</mn><mi>a</mi><mi>c</mi></msqrt></mrow><mrow> <mn>2</mn><mi>a</mi> </mrow></mrow></math>";
                            mathML = mathML.substring(mathML.indexOf("<m")); //Remove XML header
                            if (mathML.indexOf("display=") == -1) {
                                mathML = mathML.substring(0, 6) + 'display="block" ' + mathML.substring(6);
                            }

                            //var mathHexColor;
                            // if (textStyleRange.appliedCharacterStyle && textStyleRange.appliedCharacterStyle.fillColor) {
                            //     var color = textStyleRange.appliedCharacterStyle.fillColor;
                            //     var workingDoc = app.activeDocument;
                            //     if (_typeof(color, "Color")) {

                            //         var scratchColor = workingDoc.colors.add({
                            //             model: color.model,
                            //             space: color.space,
                            //             colorValue: color.colorValue
                            //         });

                            //         // Now, we force adobe's internal color conversion mechanism to trigger by changing the scratchColor's color space.
                            //         scratchColor.space = ColorSpace.RGB;
                            //         var updatedValues = scratchColor.colorValue;
                            //         mathHexColor = ConvertRGBtoHex(updatedValues[0], updatedValues[1], updatedValues[2]);

                            //         workingDoc.swatches.item(scratchColor.name).remove();
                            //     }
                            // } else if (textStyleRange.fillColor) {
                            //     var color = textStyleRange.fillColor;
                            //     var workingDoc = app.activeDocument;
                            //     if (_typeof(color, "Color")) {

                            //         var scratchColor = workingDoc.colors.add({
                            //             model: color.model,
                            //             space: color.space,
                            //             colorValue: color.colorValue
                            //         });

                            //         // Now, we force adobe's internal color conversion mechanism to trigger by changing the scratchColor's color space.
                            //         scratchColor.space = ColorSpace.RGB;
                            //         var updatedValues = scratchColor.colorValue;
                            //         mathHexColor = ConvertRGBtoHex(updatedValues[0], updatedValues[1], updatedValues[2]);

                            //         workingDoc.swatches.item(scratchColor.name).remove();
                            //     }
                            // }
                            //if (mathHexColor)
                            mathML = mathML.replace(/(<m\w+)(\s*.*?>)/, '$1$2');

                            var id = 0;
                            if (mathMLLink) {
                                var scImg = mathMLLink.parent.managedImage;
                                if (scImg) {
                                    var metadata = scImg.entMetaData;
                                    id = metadata.get('Core_ID');
                                }
                            }


                            //log.info
                            var mathComponent = {
                                type: "mathML",
                                field: "text",
                                group: groupId,
                                mathML: mathML,
                                id: id,
                                inline: true
                            };

                            //set mathComponent for mathML in bulleted items
                            if (_config.containers && _config.containers[textStyleRanges[0].appliedParagraphStyle.name]) {
                                _set(mathComponent, "container", _config.containers[textStyleRanges[0].appliedParagraphStyle.name]);
                                _set(mathComponent, "appendinline", true);
                            }
                            //set if it's in a styled box or collapsible box
                            if (_config.styledBox && _config.styledBox[textStyleRanges[0].appliedParagraphStyle.name]) {
                                _set(mathComponent, "styledbox", _config.styledBox[textStyleRanges[0].appliedParagraphStyle.name]);
                            } else if (_config.collapsible && _config.collapsible[textStyleRanges[0].appliedParagraphStyle.name]) {
                                _set(mathComponent, "collapsiblebox", _config.collapsible[textStyleRanges[0].appliedParagraphStyle.name]);
                            }
                            //set summary box.
                            if (_config.summaryContainers && _config.summaryContainers[textStyleRanges[0].appliedParagraphStyle.name]) {
                                _set(mathComponent, "summaryContainers", _config.summaryContainers[textStyleRanges[0].appliedParagraphStyle.name]);
                            }


                            //add component
                            _add(articleInfo.components, mathComponent);

                            //Start a new component
                            component = JSON.parse(JSON.stringify(component));
                            _set(component, "text", "");
                            _set(component, "ranges", []);
                            text = "";
                            textRanges = [];

                            //set appendinline for the new component following mathml in bulleted items
                            if (_config.containers && _config.containers[textStyleRanges[0].appliedParagraphStyle.name]) {
                                _set(component, "appendinline", true);
                            }
                            // } else {
                            //     if (mathMLWarning) {
                            //         alert("Please run the Prepare Mathml");
                            //         mathMLWarning = false;
                            //     }
                            // }
                        }
                    } catch (error) {
                        log.info("mathzone error" + error);
                        //Start a new component
                        component = JSON.parse(JSON.stringify(component));
                        _set(component, "text", "");
                        _set(component, "ranges", []);
                        text = "";
                        textRanges = [];
                    }
                }

                //mathml helper function
                function findLinkByName(doc, filename, itemId) {
                    log.info("Finding link: " + filename);
                    var links = doc.links;
                    for (var x = 0; x < links.length; x++) {
                        if (links[x].name.indexOf("_" + itemId) > 0) {
                            log.info("Found link: " + filename);
                            return links[x];
                        }
                    }
                    log.info("Could not find: " + filename);
                    return undefined;
                }

                //helper functions
                function _addComponent() {
                    //add remaining component
                    if (component.text && component.text.length >= 1 && !(component.text.length == 1 && component.text.trim().length === 0)) { // filter empty paragraphs.
                        //Check if container is configured for the paragraph style
                        if ((_config.containers && _config.containers[textStyleRanges[0].appliedParagraphStyle.name]) || (_config.styledBox && _config.styledBox[textStyleRanges[0].appliedParagraphStyle.name])) {
                            _set(component, "container", _config.containers[textStyleRanges[0].appliedParagraphStyle.name]);
                        }
                        //set summary box.
                        if (_config.summaryContainers && _config.summaryContainers[textStyleRanges[0].appliedParagraphStyle.name]) {
                            _set(component, "summaryContainers", _config.summaryContainers[textStyleRanges[0].appliedParagraphStyle.name]);
                        }
                        if (_config.header && _config.header[textStyleRanges[0].appliedParagraphStyle.name]) {
                            _set(component, "header", _config.header[textStyleRanges[0].appliedParagraphStyle.name]);
                        } else if (_config.collapsible && _config.collapsible[textStyleRanges[0].appliedParagraphStyle.name]) {
                            _set(component, "collapsiblebox", _config.collapsible[textStyleRanges[0].appliedParagraphStyle.name]);
                        }
                        /*
                        // 2024-08-13 RJ: DISABLED FOR NEW QUOTES OPTION 
                        else if (_config.quotes && _config.quotes.indexOf(textStyleRanges[0].appliedParagraphStyle.name) !== -1) {
                            _set(component, "quotes", true);
                        }*/
                        else if (_config.quotes && valueInObjectArrayExists(_config.quotes, textStyleRanges[0].appliedParagraphStyle.name) == true) {
                            _set(component, "quotes", true);
                        }

                        //ptd image component work
                        if (articleInfo.components[articleInfo.components.length - 1].type == "graphic" && (component.identifier.indexOf("titlewi") === 0) || component.identifier.indexOf("titlewithimage") === 0 || component.identifier.indexOf("titlewithimagebackground") === 0) {
                            var tempImageInfo = articleInfo.components.pop();
                            var tempPtdComponent = JSON.parse(JSON.stringify(_config.ptdimageComponent.definition));
                            var imageInfo = tempPtdComponent.content.ptdimage;
                            imageInfo.id = tempImageInfo.id;
                            component.image = imageInfo;
                        }

                        _add(articleInfo.components, component);
                    }
                }

                function _setRanges(textStyleRange, textComplete) {
                    var charStyle = '';

                    // Remember all used styles encountered
                    if (!styles.font[textStyleRange.fontStyle]) {
                        styles.font[textStyleRange.fontStyle] = {};
                    }
                    if (textStyleRange.appliedCharacterStyle && !styles.character[textStyleRange.appliedCharacterStyle.name]) {
                        styles.character[textStyleRange.appliedCharacterStyle.name] = {};
                    }
                    if (textStyleRange.appliedParagraphStyle && !styles.paragraph[textStyleRange.appliedParagraphStyle.name]) {
                        styles.paragraph[textStyleRange.appliedParagraphStyle.name] = {};
                    }
                    // Eval tags on current textrange
                    tags = {};
                    _.each(allStyleTags, function(tag) {
                        if (_hasAppliedStyleTag(textStyleRange, styles, tag)) {
                            tags[tag] = styles.character[textStyleRange.appliedCharacterStyle.name][tag];
                        }
                    });

                    //Get the hyperlink url of the text range
                    var hyperlinkURL = "";
                    _.each(textStyleRange.findHyperlinks(), function(hyperlinkTextSource) {
                        _.each(hyperlinkTextSource.parent.hyperlinks, function(hyperlink) {
                            if (hyperlink.source == hyperlinkTextSource && hyperlink.destination && _typeof(hyperlink.destination, "HyperlinkURLDestination")) {
                                hyperlinkURL = hyperlink.destination.destinationURL;
                            }
                        });
                    });

                    //get colorstyle information
                    // if (textStyleRange.appliedCharacterStyle && textStyleRange.appliedCharacterStyle.fillColor) {
                    //     var color = textStyleRange.appliedCharacterStyle.fillColor;
                    //     var workingDoc = app.activeDocument;
                    //     if (_typeof(color, "Color")) {
                    //         var scratchColor = workingDoc.colors.add({
                    //             model: color.model,
                    //             space: color.space,
                    //             colorValue: color.colorValue
                    //         });

                    //         // Now, we force adobe's internal color conversion mechanism to trigger by changing the scratchColor's color space.
                    //         scratchColor.space = ColorSpace.RGB;
                    //         var updatedValues = scratchColor.colorValue;
                    //         appliedColor = ConvertRGBtoHex(updatedValues[0], updatedValues[1], updatedValues[2]);
                    //         workingDoc.swatches.item(scratchColor.name).remove();
                    //     }
                    // }
                    // if (textStyleRange.fillColor) {
                    //     var color = textStyleRange.fillColor;
                    //     var workingDoc = app.activeDocument;
                    //     if (_typeof(color, "Color")) {
                    //         var scratchColor = workingDoc.colors.add({
                    //             model: color.model,
                    //             space: color.space,
                    //             colorValue: color.colorValue
                    //         });

                    //         // Now, we force adobe's internal color conversion mechanism to trigger by changing the scratchColor's color space.
                    //         scratchColor.space = ColorSpace.RGB;
                    //         var updatedValues = scratchColor.colorValue;
                    //         appliedColor = ConvertRGBtoHex(updatedValues[0], updatedValues[1], updatedValues[2]);
                    //         workingDoc.swatches.item(scratchColor.name).remove();
                    //     }
                    // }

                    if (textStyleRange.appliedCharacterStyle) {
                        charStyle = textStyleRange.appliedCharacterStyle.name;
                    }
                    // remember used ranges
                    if (textRanges) {
                        textRanges.push({
                            contents: textComplete,
                            styleOverridden: textStyleRange.styleOverridden,
                            fontStyle: textStyleRange.fontStyle,
                            characterStyle: "" + charStyle,
                            paragraphStyle: "" + charStyle,
                            color: appliedColor,
                            tags: tags,
                            hyperlinkURL: hyperlinkURL
                        });
                    }

                    // And remember
                    _set(component, "text", text);
                    _set(component, "ranges", textRanges);
                    appliedColor = "";
                }

                function ConvertRGBtoHex(red, green, blue) {
                    return "#" + ColorToHex(red) + ColorToHex(green) + ColorToHex(blue);
                }

                function ColorToHex(color) {
                    var hexadecimal = color.toString(16);
                    return hexadecimal.length == 1 ? "0" + hexadecimal : hexadecimal;
                }
            }

            /**
             * Check in style config if this tag code is valid for text
             * @param idText
             * @param styles
             * @param tagCode
             * @returns {boolean}
             * @private
             */
            function _hasAppliedStyleTag(idText, styles, tagCode) {
                if (styles.font[idText.fontStyle][tagCode])
                    return styles.font[idText.fontStyle][tagCode]
                if (idText.appliedCharacterStyle) {
                    if (styles.character[idText.appliedCharacterStyle.name][tagCode])
                        return styles.character[idText.appliedCharacterStyle.name][tagCode]
                }
                if (styles.paragraph[idText.appliedParagraphStyle.name][tagCode])
                    return styles.paragraph[idText.appliedParagraphStyle.name][tagCode]
            }

            /**
             * Get graphic article info from this frame, for Inline Images
             * @param graphic
             * @param articleInfo
             * @private
             */
            function _idGraphicInline(graphic, articleInfo, includeInDesignImages, groupId, inlineBool, textStyleRanges) {
                log.info('<= check graphic page');

                if (graphic.parentPage) {
                    var curPage = graphic.parentPage.name;
                    log.info(curPage);
                    if (!(oldPagNums.indexOf(curPage) > -1)) {
                        //add footer component
                        var footer = {
                            type: "footer",
                            page: curPage,
                            group: ""
                        }
                        _add(articleInfo.components, footer);

                        oldPagNums.push(curPage);
                    }
                } else {
                    //move it to the page
                    var spread;
                    if (_typeof(graphic.parent.parent, "Spread")) {
                        spread = graphic.parent.parent;
                    } else if (_typeof(graphic.parent.parent, "Character")) {
                        if (_typeof(graphic.parent.parent.parentTextFrames[0].parent, "Spread")) {
                            spread = graphic.parent.parent.parentTextFrames[0].parent;
                        }
                    }

                    // Get the bounds of the graphic
                    var gb = graphic.geometricBounds;
                    var left = gb[1];
                    var right = gb[3];

                    // Determine the nearest page based on the horizontal position of the graphic
                    var nearestPage = null;
                    var minDistance = Infinity;

                    // Iterate through the pages of the spread to find the nearest one
                    for (var i = 0; i < spread.pages.length; i++) {
                        var page = spread.pages[i];
                        var pageBounds = page.bounds;
                        var leftPageBound = pageBounds[1];
                        var rightPageBound = pageBounds[3];

                        // Calculate the distance from the graphic to the center of the page
                        var pageCenter = (leftPageBound + rightPageBound) / 2;
                        var graphicCenter = (left + right) / 2;
                        var distance = Math.abs(graphicCenter - pageCenter);

                        if (distance < minDistance) {
                            minDistance = distance;
                            nearestPage = page;
                        }
                    }

                    var curPage = nearestPage.name;
                    if (!(oldPagNums.indexOf(curPage) > -1)) {
                        //add footer component
                        var footer = {
                            type: "footer",
                            page: curPage,
                            group: ""
                        }
                        _add(articleInfo.components, footer);

                        oldPagNums.push(curPage);
                    }
                }

                var graphicFilePath = graphic.itemLink.filePath
                var graphicFile = new File(graphicFilePath);
                // Smart Connection DB images do have an empty filePath (CS6) or contain the object id (CC)
                // For that situation, dream up the correct path by using the document's path, which gives the
                // SmartConnection.noindex folder, combined with the Enterprise ID from the metadata and name from
                // the link.

                if (!graphicFilePath || !graphicFile.exists) {
                    log.info('graphic file path [{}] is empty or does not exist [{}]', graphicFilePath, graphicFile.exists);
                    log.info('Checking whether this is an Enterprise DB image');
                    // Smart Connection DB images have a valid managedImage
                    var scImg = graphic.managedImage;
                    if (scImg) {
                        var metadata = scImg.entMetaData;
                        var id = metadata.get('Core_ID');
                        var name = graphic.itemLink.name;

                        // Get the (expected) image folder by adding the id of the image to the
                        // document's parent location
                        var imgFolder = new File(id).at(new File(app.activeDocument.filePath).parent);
                        // The image is (expected to be) in the image folder with the link's name
                        graphicFile = new File(name).at(imgFolder);
                        graphicFilePath = graphicFile.fullName;
                        log.info('Constructed SC path for link [{}] : [{}]', name, graphicFilePath);
                    }
                }


                var fileURI = graphicFile.absoluteURI;
                var fileName = graphic.itemLink.name;
                // Check if tshe path was used before. In that case use that filename
                if (fileURI in articleInfo.graphicsPathToName) {
                    fileName = articleInfo.graphicsPathToName[fileURI];
                    log.info('Existing path, reusing fileName:[{}]', fileName);
                } else {
                    var orgFileName = fileName;
                    var increment = 1;
                    log.info('New fileName:[{}]', fileName);
                    while (fileName in articleInfo.graphicsNameToPath) {
                        var idx = fileName.lastIndexOf('.');
                        if (idx === -1)
                            idx = fileName.length;
                        fileName = orgFileName.slice(0, idx) + '-' + increment++ + orgFileName.slice(idx)
                        log.info('Filename already in use, retry with:[{}]', fileName);
                    }
                }

                articleInfo.graphicsPathToName[fileURI] = fileName;
                articleInfo.graphicsNameToPath[fileName] = fileURI;
                if (id || includeInDesignImages) {
                    var width = "100%";
                    //size the PTD image component
                    var frameLength;
                    if (inlineBool == true) {
                        if (_typeof(graphic.parent.parent, "Group")) {
                            frameLength = 1;
                        } else {
                            frameLength = graphic.parent.parent.parentTextFrames.length;
                        }
                    }
                    if (inlineBool == false || (frameLength > 0 && inlineBool)) {
                        if (_config.scalePTDImages) {
                            var frame_width = graphic.parent.visibleBounds[3] - graphic.parent.visibleBounds[1];
                            var page_width;
                            try {
                                page_width = graphic.parentPage.bounds[3] - graphic.parentPage.bounds[1];
                            } catch (err) {
                                page_width = app.activeDocument.pages.item(0).bounds[3] - app.activeDocument.pages.item(0).bounds[1];
                            }

                            width = Math.floor((frame_width / page_width * 100) * 100) / 100;
                            if (width > 100) {
                                width = 100;
                            }
                            width += '%';
                        }
                        var Imgcomponent = {
                            type: "graphic",
                            fileName: fileName,
                            id: id,
                            group: groupId,
                            width: width,
                            inline: true
                        }

                        if (_config.styledBox && textStyleRanges != null && _config.styledBox[textStyleRanges[0].appliedParagraphStyle.name]) {
                            _set(Imgcomponent, "styledbox", _config.styledBox[textStyleRanges[0].appliedParagraphStyle.name]);
                        } else if (_config.collapsible && inlineBool == true && _config.collapsible[textStyleRanges[0].appliedParagraphStyle.name]) {
                            _set(Imgcomponent, "collapsiblebox", _config.collapsible[textStyleRanges[0].appliedParagraphStyle.name]);
                        }
                        //set summary box.
                        if (_config.summaryContainers && textStyleRanges != null && _config.summaryContainers[textStyleRanges[0].appliedParagraphStyle.name]) {
                            _set(Imgcomponent, "summaryContainers", _config.summaryContainers[textStyleRanges[0].appliedParagraphStyle.name]);
                        }
                        if (_config.quotes && textStyleRanges != null && valueInObjectArrayExists(_config.quotes, textStyleRanges[0].appliedParagraphStyle.name)) {
                            _set(Imgcomponent, "quotes", true);
                        }
                        _add(articleInfo.components, Imgcomponent);
                    } else {
                        log.info("skipping offset image");
                    }
                } else {
                    //alert("Image \"" + fileName + "\" is excluded because it is not stored in Enterprise.\nHint: Please use \"Smart Connection->Create Image\" to store the image in Enterprise");
                }
                log.info('<= ptd-export-service.ArticleWrapper._idGraphic');
            }

            ////////////////////////// HELPERS //////////////////////////////

            function getDims(obj, visibleBounds) {


                var boxLimits = BoundingBoxLimits[
                    (visibleBounds) ?
                    'OUTER_STROKE_BOUNDS' :
                    'GEOMETRIC_PATH_BOUNDS'
                ];

                var getCoords = function(cornerPt) {
                    return this.resolve([cornerPt, boxLimits],
                        CoordinateSpaces.innerCoordinates)[0];
                }

                // get [left,top, right,bottom] inner coordinates
                var coords = getCoords.call(obj, AnchorPoint.topLeftAnchor).
                concat(getCoords.call(obj, AnchorPoint.bottomRightAnchor));

                // calculate the width and the height
                var sa = obj.shearAngle;
                var w = coords[2] - coords[0];
                var h = (coords[3] - coords[1]) / Math.cos(sa * Math.PI / 180);
                return [w, h];
            }

            /**
             * Returns string for opening an html tag.
             * @param styles
             * @param tagCode
             * @returns {string}
             * @private
             */


            function _openHtmlTag(output, tagCode) {
                var tag = output.htmlTags[tagCode] || {
                    tag: tagCode
                };
                var result = "<" + tag.tag;
                if (tag.classes) result += " class=\"" + tag.classes + "\"";
                return result + ">";
            }

            /**
             * Returns string for closing and html tag
             * @param output
             * @param tagCode
             * @returns {string}
             * @private
             */
            function _closeHtmlTag(output, tagCode) {
                var tag = output.htmlTags[tagCode] || {
                    tag: tagCode
                };
                return "</" + tag.tag + ">";
            }

            /**
             * Returns htmlEncodes and ensure mandatory converts are in there.
             * Does not overwrites existing configurations.
             * @param styles
             * @returns {[*]}
             * @private
             */
            function _ensureStylesHtmlEncode(output) {
                var pairs = [].concat(output.htmlEncode);
                // Info about Special characters
                // http://www.indiscripts.com/blog/public/data/idcs4-special-characters/en_InDesignCS4-CS5-SpecialChars.pdf

                log.debug('=> ptd-export-service._ensureStylesHtmlEncode');

                // Add mandatory converts in front
                addFront(['<', '&lt;']);
                addFront(['>', '&gt;']);
                addFront(['&', '&amp;']);

                // add end
                addEnd(['\"', '&quot;']);
                addEnd(['\n', '<br/>']);
                addEnd(['\r', '']);

                // put in front of pairs, if not already one in there.
                function addFront(pair) {
                    if (!_.some(pairs, function(p) {
                            return p[0] === pair[0]
                        })) {
                        pairs.unshift(pair);
                    }
                }
                // add at end of pairs, if not already one in there.
                function addEnd(pair) {
                    if (!_.some(pairs, function(p) {
                            return p[0] === pair[0]
                        })) {
                        pairs.push(pair);
                    }
                }

                log.info('<= ptd-export-service._ensureStylesHtmlEncode()');
                return pairs;
            }

            /**
             * Convert/encode characters in contents.
             * @param styles containing config of encoding
             * @param contents
             * @returns {string}
             * @private
             */
            function _encodeHtml(output, contents) {
                var str = contents,
                    pairs = output.htmlEncode;
                log.info('=> ptd-export-service._encodeHtml(htmlEncode.len:{})', pairs.length);
                _.each(pairs, function(pair) {
                    str = str.split(pair[0]).join(pair[1]);
                });
                log.info('<= ptd-export-service._encodeHtml()');
                return str;
            }

            /**
             * Check type of InDesign object
             * @param obj
             * @param type
             * @returns {boolean}
             * @private
             */
            function _typeof(obj, type) {
                if (("" + obj) === "[object " + type + "]") return true;
                return false;
            }

            /**
             * Log all properties of object.
             * @param obj
             * @private
             */
            function _debugID(obj) {
                if (obj.properties) {
                    _.each(obj.properties, function(propValue, propKey) {
                        if (typeof propValue === "function") {
                            log.debug("   {}: (function)", propKey);
                        } else log.debug("   {}: {}", propKey, propValue);
                    });
                } else {
                    _.each(obj, function(propValue, propKey) {
                        if (typeof propValue === "function") {
                            log.debug("   {}: (function)", propKey);
                        } else log.debug("   {}: {}", propKey, propValue);
                    });
                }
            }

            /**
             * Set an value on an container object.
             * @param container
             * @param key
             * @param value
             * @returns {boolean}
             * @private
             */
            function _set(container, key, value) {
                if (value) {
                    log.debug('=> ptd-export-service._set({},{})', key, value);
                    if (typeof container === "object") {
                        if (!key) {
                            throw new Err.ArgumentError("Argument key is not set.", $.fileName, $.line);
                        }
                        container[key] = value;
                    } else {
                        throw new Err.ArgumentError("Unsupported container type.", $.fileName, $.line);
                    }
                    log.debug('<= ptd-export-service._set');
                    return true;
                }
                return false;
            }

            /**
             * Add an value to an container array
             * @param container
             * @param value
             * @returns {boolean}
             * @private
             */
            function _add(container, value) {
                if (value) {
                    log.debug('=> ptd-export-service._add({})', value || "(null)");
                    if (container && container instanceof Array) {
                        container.push(value);
                    } else {
                        throw new Err.ArgumentError("Unsupported container type.", $.fileName, $.line);
                    }
                    log.debug('<= ptd-export-service._add');
                    return true;
                }
                return false;
            }

            /**
             * Apply callback for all elements in array and return array of results.
             * return [callback(value,index,arg1,arg2),...]
             * @param elements array
             * @param callback function(value,index,arg1,arg2)
             * @param arg1 optional argument for callback
             * @param arg2 optional argument for callback
             * @param arg3 optional argument for callback 
             * @returns {Array}
             * @private
             */
            function _applyAll(elements, callback, arg1, arg2, arg3) {
                var results = [],
                    self = this;
                if (elements && elements.length) {
                    log.debug('=> ptd-export-service._applyAll({},{})', arg1, arg2, arg3);
                    _.each(elements, function(value, key) {
                        _add(results, callback(value, key, arg1, arg2, arg3));
                    });
                    log.debug('<= ptd-export-service._applyAll()');
                }
                return results.length ? results : null;
            }

            //helper function to find value in object/array
            function valueInObjectArrayExists(object, searchValue) {
                log.info("valueInObjectArrayExists");
                var found = false;
                _.each(object.keys(), function(key) {
                    log.info("search " + searchValue + " under " + key);
                    if (object[key].indexOf(searchValue) !== -1) {
                        found = true;
                    }
                });
                return found;
            }

            function returnKeyIfInObjectArrayExists(object, searchValue) {
                log.info("returnKeyIfInObjectArrayExists");
                var foundKey = null;
                _.each(object.keys(), function(key) {
                    log.info("search " + searchValue + " under " + key);
                    if (object[key].indexOf(searchValue) !== -1) {
                        foundKey = key;
                    }
                });
                log.info("returning key: " + foundKey);
                return foundKey;
            }

            return { // API
                article: getArticle,
                cleanup: deleteArticle,
                getArticleInfo: getArticleInfo,
                createPtdArticle: createPtdArticle,
                UpdatePublishedIn: UpdatePublishedIn,
                uploadArticleToEnterprise: uploadArticleToEnterprise

            };
        }

        function updateAssetMetadata(assetId, studioID) {
            var metadata = {
                sceId: studioID
            };
            var r = [
                ["id", assetId, "String"],
                ["metadata", JSON.stringify(metadata), "String"]
            ];
            try {
                var response = app.elvisPostRequest("/update", r);
                var asset = JSON.parse(response);
                if (asset) {} else {
                    alert("Asset failed to update in Asset Server.");
                    return false;
                }
            } catch (e) {
                var error = e;
            }
            return true;
        }

        function FolderWrapper(path) {
            var tempFolder;

            log.info('=> ptd-export-service.FolderWrapper({})', path);
            if (!path) {
                path = Folder.temp + "/ptd-indesign-export";
                log.info('Using path: {}', path);
            }

            log.info('<= ptd-export-service.FolderWrapper');

            /**
             * Delete the folder
             */
            function deleteFolder() {
                log.info('=> ptd-export-service.FolderWrapper.deleteFolder');
                if (tempFolder) {
                    tempFolder.remove();
                    tempFolder = null;
                    log.info("Deleted temp folder '{}'.", path);
                }
                log.info('<= ptd-export-service.FolderWrapper.deleteFolder');
            }

            /**
             * Concatenate filename to path of folder.
             * @param filename
             * @returns {*}
             */
            function fullPath(filename) {
                if (!filename) return path;
                return path + "/" + filename;
            }

            return {
                cleanup: deleteFolder,
                path: fullPath
            };
        }

        function FileWrapper(path, encoding, newFile) {
            var _create = newFile === undefined || newFile,
                _encoding = encoding || 'UTF-8';

            log.info('=> ptd-export-service.FileWrapper({},{},{})', path, _encoding, _create);

            log.info('<= ptd-export-service.FileWrapper');

            /**
             * Write a line of text to file.
             * Arguments are formated, writeln("just like {}, {}, {}.","1","2",3)
             * @param txt
             */
            function writeln(txt) {
                var args = Array.prototype.slice.call(arguments);
                var template = args.shift();
                var message = template.format.apply(template, args);

                var file = new File(path);
                log.info('=> ptd-export-service.FileWrapper.writeln({})', path);
                try {
                    file.encoding = _encoding;
                    if (file.open(_create ? "w" : "a")) {
                        _create = false;
                        file.writeln(message);
                        file.close();
                    } else throw "Failed to open file.";
                } catch (error) {
                    throw new Err.FileWriteError(Err.wrap("Failed to write to file '" + path + "'. Error: ", error), $.fileName, $.line);
                }
                //else log.info("Save JSON file '{}'.",path);
                log.info('<= ptd-export-service.FileWrapper.writeln');
            }

            /**
             * Write an object as json to file.
             * @param obj
             * @param postfix text added add end of json text.
             */
            function writeJSON(obj, postfix) {
                var txt,
                    file = new File(path);
                log.info('=> ptd-export-service.FileWrapper.writeJSON({})', obj);
                try {
                    //txt = JSON.stringify(obj);
                    txt = JSON.stringify(obj, null, '\t');
                } catch (error) {
                    throw new Err.FileWriteError(Err.wrap("Failed to stringify to JSON file '" + path + "'. Error: ", +error), $.fileName, $.line);
                }
                try {
                    file.encoding = _encoding;
                    if (file.open(_create ? "w" : "a")) {
                        _create = false;
                        file.writeln(txt + (postfix || ""));
                        file.close();
                    } else throw "Failed to open file.";
                } catch (error) {

                    throw new Err.FileWriteError(Err.wrap("Failed to write to JSON file '" + path + "'. Error: ", +error), $.fileName, $.line);
                }
                log.info('<= ptd-export-service.FileWrapper.writeJSON');
            }

            /**
             * Copies graphics (images, etc..) from articleInfo.graphicsPathToName.keys to the same folder where this file is placed into.
             * @param articleInfo
             */
            function copyGraphics(articleInfo) {
                log.info('=> ptd-export-service.FileWrapper.copyGraphics({})', articleInfo);
                _.each(articleInfo.graphicsPathToName.keys(), function(uri) {
                    var graphicFileFrom = new File(uri);
                    if (!graphicFileFrom.exists) {
                        log.error('graphic file does not exist: [{}]', uri);
                    }
                    var graphicFileTo = new File(articleInfo.graphicsPathToName[uri]).at(new File(path).parent);
                    log.info('Copy [{}] to [{}]', graphicFileFrom, graphicFileTo);
                    graphicFileFrom.copy(graphicFileTo);
                });
                log.info('<= ptd-export-service.FileWrapper.copyGraphics');
            }

            return { // API
                writeln: writeln,
                writeJSON: writeJSON,
                copyGraphics: copyGraphics
            };
        }

        function createDestinationFolder(baseFolderPath) {
            var folder = Folder(baseFolderPath);
            if (!folder.exists) {
                folder.create();
            }
        }

        /**
         * Get a list of templates (id, name)
         * @param {*} brandId Optional filter to filter on brand id
         */
        function getTemplateList(brandId) {
            var queryObjectsRequest = {
                "method": "QueryObjects",
                "id": "1",
                "params": [{
                    "Params": [{
                            "Property": "Type",
                            "Value": "ArticleTemplate",
                            "Operation": "=",
                            "__classname__": "QueryParam"
                        },
                        {
                            "Property": "Format",
                            "Value": "application\/ww-digitmpl+json",
                            "Operation": "=",
                            "__classname__": "QueryParam"
                        }
                    ],
                    "FirstEntry": 1,
                    "RequestProps": [
                        "ID",
                        "Name",
                        "Type",
                        "Format"
                    ],
                    "Order": [{
                        "__classname__": "QueryOrder",
                        "Property": "Name",
                        "Direction": true
                    }],
                    "Ticket": app.entSession.activeTicket
                }],
                "jsonrpc": "2.0"
            }

            //Add brand filter when needed 
            if (brandId) {
                queryObjectsRequest.params[0].Params.push({
                    "Property": "PublicationId",
                    "Value": brandId,
                    "Operation": "=",
                    "__classname__": "QueryParam"
                });
            }

            var response = JSON.parse(app.jsonRequest(getServerUrl(), JSON.stringify(queryObjectsRequest)));

            //Process the result
            var templates = [];
            for (i = 0; i < response.result.Rows.length; i++) {
                var template = {
                    id: response.result.Rows[i][0],
                    name: response.result.Rows[i][1]
                };
                templates.push(template);
            }

            //Fallback to the templates of all brands if no template were found
            if (templates.length == 0 && brandId) {
                return getTemplateList();
            }

            return templates;
        }

        /**
         * Show a dialog to the user to select the template to be used 
         * @param {*} templateList List of available templates (id,name)
         */
        function selectArticleTemplate(templateList) {
            var selectedTemplate = null;
            var templateNames = [];

            for (i = 0; i < templateList.length; i++) {
                templateNames.push(templateList[i].name);
            }

            myDlg = new Window('dialog', 'Info');
            myDlg.orientation = 'column';
            myDlg.alignment = 'left';

            //Add label
            myDlg.LblGroup = myDlg.add('group');
            myDlg.LblGroup.orientation = 'row';
            myDlg.LblGroup.alignment = 'left';
            myDlg.LblGroup.add('statictext', undefined, "Choose a template:");


            //add drop-down
            myDlg.DDgroup = myDlg.add('group');
            myDlg.DDgroup.orientation = 'row';
            myDlg.DDgroup.alignment = 'left';

            myDlg.DDgroup.DD = myDlg.DDgroup.add('dropdownlist', undefined, undefined, {
                items: templateNames
            })
            myDlg.DDgroup.DD.selection = 0;
            myDlg.DDgroup.DD.minimumSize.width = 400;

            var currentPath = File($.fileName).path.slice(0, -7);
            var configFile = new File(Folder.myDocuments + "/WoodWingStudio.noindex/InDesign/selected-ptd.txt");
            configFile.encoding = 'UTF-8';
            configFile.open('r');
            var newConfig = configFile.read();
            var configFileCheck = new File(currentPath + "/" + newConfig);
            if (!configFileCheck.exists) {
                throw new Error("The selected config file does not exist. Please select a new one.");
            }

            //Add label
            myDlg.LblGroup = myDlg.add('group');
            myDlg.LblGroup.orientation = 'row';
            myDlg.LblGroup.alignment = 'left';
            myDlg.LblGroup.add('statictext', undefined, "Selected config file: " + newConfig);

            //Cancel button
            myDlg.btnGroup = myDlg.add('group');
            myDlg.btnGroup.orientation = 'row';
            myDlg.btnGroup.alignment = 'right';

            myDlg.cancelBtn = myDlg.btnGroup.add('button', undefined, 'Cancel');
            myDlg.cancelBtn.onClick = function() {
                this.parent.close();
            }

            //Ok Button
            myDlg.okBtn = myDlg.btnGroup.add('button', undefined, 'OK');
            myDlg.okBtn.onClick = function() {
                selectedTemplate = templateList[Number(myDlg.DDgroup.DD.selection)];
                this.parent.close();
            }

            myDlg.center();
            myDlg.show();

            return selectedTemplate;
        }

        /**
         * Compose the url of the server including the JSON protocol 
         */
        function getServerUrl() {
            var serverUrl = app.entSession.activeUrl;

            if (serverUrl.indexOf("?") == -1) {
                serverUrl += "?protocol=JSON";
            } else {
                serverUrl += "&protocol=JSON";
            }

            return serverUrl;
        }

        // Function to apply regex to text in InDesign
        function applyRegexToText(text, pattern) {
            var regex = new RegExp(pattern);
            var match = regex.exec(text);

            if (match) {
                return match[0];
            } else {
                return "No match found";
            }
        }

        //
        function removeObjectFromArray(array, objectToRemove) {
            for (var i = array.length - 1; i >= 0; i--) {
                if (array[i] === objectToRemove) {
                    array.splice(i, 1);
                    return true; // Object was found and removed
                }
            }
            return false; // Object was not found in the array
        }

        /**
         * Returns the GetObjects JSON of a the given ID
         * @param objectID 
         */
        function getObject(objectID) {
            var getObjectsRequest = {
                "method": "GetObjects",
                "id": "1",
                "params": [{
                    "IDs": [
                        objectID
                    ],
                    "Lock": false,
                    "Rendition": "none",
                    "Areas": [
                        "Workflow"
                    ],
                    "Ticket": app.entSession.activeTicket
                }],
                "jsonrpc": "2.0"
            }

            return JSON.parse(app.jsonRequest(getServerUrl(), JSON.stringify(getObjectsRequest)));
        }

        // Public API
        return {
            exportArticle: exportArticle
        }
    }(Err, ConfigService, JSON, _);
}