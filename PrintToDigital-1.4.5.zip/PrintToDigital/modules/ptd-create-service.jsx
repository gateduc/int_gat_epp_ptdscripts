﻿/**
 * @description Ptd create service - creates InDesign article with content
 *
 * @copyright WoodWing Software B.V. All rights reserved.
 */

if(forceInit || typeof $.global.PtdCreateService === 'undefined') {

#include '_.jsx'
#include 'err.jsx'
#include 'config-service.jsx'
#include 'component-lookup.jsx'
#include 'json2.js'
#include "logging.jsx"

var PtdCreateService = function(Err, ConfigService, ComponentLookup, JSON, _) {
	'use strict';

	var _config = ConfigService.getConfig(),
		textComponentLookup=new ComponentLookup(_config.textFilterList,"textFilterList");

	var defaultFilters = {
		paragraphStyleName : function(s) {
			var needsExport = _(s)._('paragraphs').some(function(p){
				return textComponentLookup.lookup(p.appliedParagraphStyle.name);
			});
			return needsExport;
		}
	};

	/**
	 * Lookup text frames that according to the config need to be added to the article and add them
	 * @param ptdArticle
	 * @private
	 */
	function _addTextFrames(ptdArticle){
		// Check the configuration
		if(typeof _config.textFilter !== 'string') {
			throw new Err.ConfigurationError('No textFilter', $.fileName, $.line);
		}
		if(!_config.textFilterList instanceof Object) {
			throw new Err.ConfigurationError('No textFilterList', $.fileName, $.line);
		}

		// Get and check the filter function
		var filterFn = defaultFilters[_config.textFilter];
		if(typeof filterFn !== 'function') {
			throw new Err.ConfigurationError('Invalid textFilter', $.fileName, $.line);
		}

		// Use the filter function to filter the list of stories
		var stories = _('stories')._(filterFn);
		log.info('Found {} stories. Goint to add first frames to the article', stories.size());

		// Add the first frame of resulting list of stories to the article
		stories.each(function(s){	
			
			
			
				ptdArticle.articleMembers.add(s.textContainers[0]);
			            	
		})
	}

	/**
	 * Lookup images that according to and add them to the article
	 * @param ptdArticle
	 * @private
	 */
	function _addGraphics(ptdArticle){
		// Use the filter function to filter the list of text frames
		var graphics = _('allGraphics');
		log.info('Found {} graphics. Adding to the article', graphics.size());

		// Add the resulting list of graphics to the article
		graphics.each(function(img){
			ptdArticle.articleMembers.add(img);
		})
	}

	/**
	 * Creates and populates an 'ptd-export' article in the front document
	 * @throws ArticleExistsError
	 */
	function createArticle() {
		log.info('=> ptd-create-service.createArticle' );
		var doc = app.activeDocument;
		var myRegularExpression = /.indd/gi
		var name = doc.name.replace(myRegularExpression, "");

		// Check if an article was created before		
		ptdArticle = doc.articles.item(name);
		if (ptdArticle != null) {
			throw new Err.ArticleExistsError(null, $.fileName, $.line);
		}

		// Create a new article
		log.info('Adding article');
		ptdArticle = _('articles').add(name);

		_addTextFrames(ptdArticle);
		_addGraphics(ptdArticle);

		log.info('<= ptd-create-service.createArticle' );
	}

	// Public API
	return {
		createArticle: createArticle
	}
}(Err, ConfigService, ComponentLookup, JSON, _);

}
