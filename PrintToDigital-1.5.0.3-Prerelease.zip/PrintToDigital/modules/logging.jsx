/**
 * @description Entry point for export of the InDesign article for use in Ptd
 *
 * @copyright WoodWing Software B.V. All rights reserved.
 */


if(forceInit || typeof $.global.log === 'undefined') {

	#include "_.jsx"

	log = {
		path:'~/Desktop',
		name: 'ptd.log',
		file: null,
		level: 4,
		SEVERITY: ["NOTSET", "CRITICAL", "ERROR", "WARNING", "INFO", "DEBUG"],

		writeln: function (severity, message) {
			if (this.file) {
				this.file.encoding = 'UTF-8';
				this.file.open("a");
				this.file.writeln('' + new Date().toLocaleString() + ' :: ' + this.SEVERITY[severity] + '\t' + message);
				this.file.close();
			}
		},

		// basic logger
		_log : function (severity, args) {
			var template = args.shift();
			// Replace undefined arguments with '*undefined*' to distinguish from ''
			_.each(args, function(replacement, i){
				if(typeof replacement === 'undefined') {
					args[i] = '*undefined*';
				}
			});
			// Only format when
			var message = template.contains('{}') ? template.format.apply(template, args) : template;
			this.writeln(severity, message);
		},

		/**
		 * @desc log a debug message
		 * @param {String} message The log message
		 * @param {String|Object} [replacements] Can take any number of replacements, to be passed along to str.format()
		 */
		debug : function () {
			if(5 > this.level)
				return;
			var args = Array.prototype.slice.call(arguments);
			this._log(5, args);
		},
		/**
		 * @desc log an info message
		 * @param {String} message The log message
		 * @param {String|Object} [replacements] Can take any number of replacements, to be passed along to str.format()
		 */
		info : function () {
			if(4 > this.level)
				return;
			var args = Array.prototype.slice.call(arguments);
			this._log(4, args);
		},
		/**
		 * @desc log a warning
		 * @param {String} message The log message
		 * @param {String|Object} [replacements] Can take any number of replacements, to be passed along to str.format()
		 */
		warning : function () {
			if(3 > this.level)
				return;
			var args = Array.prototype.slice.call(arguments);
			this._log(3, args);
		},
		/**
		 * @desc log an error
		 * @param {String} message The log message
		 * @param {String|Object} [replacements] Can take any number of replacements, to be passed along to str.format()
		 */
		error : function () {
			if(2 > this.level)
				return;
			var args = Array.prototype.slice.call(arguments);
			this._log(2, args);
		},
		/**
		 * @desc log a critical error
		 * @param {String} message The log message
		 * @param {String|Object} [replacements] Can take any number of replacements, to be passed along to str.format()
		 */
		critical : function () {
			if(1 > this.level)
				return;
			var args = Array.prototype.slice.call(arguments);
			this._log(1, args);
		},



		init : function(config,logFolder,logFilename) {

			this.path = logFolder?logFolder:(config&&config.path?config.path:this.path);
			this.name = logFilename?logFilename:(config&&config.name?config.name:this.name);

			var folder = new Folder(this.path);
			if (!folder.exists) folder.create();

			this.file = new File(this.name).at(folder);
			if(config && config.wipe) {
				this.file.remove();
			}
			// log level can be specified both by name or directly as a level.
			var lv = 4;
			if (config && config.level && config.level.is(String)){}
			lv = this.SEVERITY.indexOf(config.level);
			this.level = lv || 4;
		}
	};
}