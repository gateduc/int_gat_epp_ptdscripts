/**
 * @description Ptd prepare service - prepares InDesign layout by converting tables and groups to images
 *
 * @copyright WoodWing Software B.V. All rights reserved.
 */

if (forceInit || typeof $.global.PtdPrepareService === 'undefined') {

    #include '_.jsx'
    #include 'err.jsx'
    #include 'config-service.jsx'
    #include 'component-lookup.jsx'
    #include 'json2.js'
    #include "logging.jsx"

    var PtdSwitchService = function (Err, ConfigService, ComponentLookup, JSON, _) {
        'use strict';

        /**
        * Convert text tables to images
        * @param doc
        * @private
        */
        function displayWindow() {
            var currentPath = File($.fileName).path.slice(0, -7);
            var myFiles = new Folder(currentPath);
            var files = myFiles.getFiles();
            var configFiles = [];

            for (var i = 0; i < files.length; i++) {
                if (files[i].name.indexOf("ptd-config") > -1) {
                    configFiles.push(files[i].name);
                }
            }


            myDlg = new Window('dialog', '');
            myDlg.orientation = 'column';
            myDlg.alignment = 'left';

            //Add label
            myDlg.LblGroup = myDlg.add('group');
            myDlg.LblGroup.orientation = 'row';
            myDlg.LblGroup.alignment = 'left';
            myDlg.LblGroup.add('statictext', undefined, "Select Config File \n");

            //add drop-down
            myDlg.DDgroup = myDlg.add('group');
            myDlg.DDgroup.orientation = 'row';
            myDlg.DDgroup.alignment = 'left';

            myDlg.DDgroup.DD = myDlg.DDgroup.add('dropdownlist', undefined, undefined, {
                items: configFiles
            })
            myDlg.DDgroup.DD.selection = 0;
            myDlg.DDgroup.DD.minimumSize.width = 400;

            //Cancel button
            myDlg.btnGroup = myDlg.add('group');
            myDlg.btnGroup.orientation = 'row';
            myDlg.btnGroup.alignment = 'right';

            myDlg.cancelBtn = myDlg.btnGroup.add('button', undefined, 'Cancel');
            myDlg.cancelBtn.onClick = function() {
                selectedValue = "close";
                myDlg.close();
            }

            //Ok Button
            myDlg.okBtn = myDlg.btnGroup.add('button', undefined, 'OK');
            myDlg.okBtn.onClick = function() {
                selectedValue = configFiles[Number(myDlg.DDgroup.DD.selection)];
                // Define the file path within the Documents folder
                var configFile = new File(Folder.myDocuments + "/WoodWingStudio.noindex/InDesign/selected-ptd.txt");
                configFile.encoding = 'UTF-8';
                var newConfig;
                configFile.open('w');
                configFile.write(selectedValue);
                configFile.close();
                myDlg.close();
            }
            myDlg.center();
            myDlg.show();
        }

        // Public API
        return {
            displayWindow: displayWindow,
        }
    }(Err, ConfigService, ComponentLookup, JSON, _);

}