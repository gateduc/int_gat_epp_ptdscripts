﻿/**
 * @description Configuration file for creation and export to Ptd
 *
 * Collection: Grandes Autores
 * Discipline: Matemática Bianchini
 * Version: v1b0
 *
 * @copyright WoodWing Software B.V. All rights reserved.
 */
 $.global.ptdConfig = {

	// Filter text based on paragraph style name. For now the only option.
	textFilter: 'paragraphStyleName',
	// Object with all digital article component types. Each type has an array of style names that will be used
	// to define the type. Style names can be either strings or regular expressions (in string form)
	// By default the text is placed in the text field of the component, to override this behavior add "." and the field name, for example subtitle.title
	// To use a specfic digitalComponentStyleOptions add a "#" and the name of the digitalComponentStyleOptions, for example title#option1_red or subtitle.title#option2_blue	

	//This is print to digital configuration script for Grandes Autores - Matemática Bianchini

	textFilterList: {
		"titleh1": [
			
		],
		"titleh1#Option1": [
			
		],
		"titleh1#Option2": [
			
		],
		"titleh1#Option3": [
		],
		"titleh2": [
		],
		"titleh2#Option1": [
		],
		"titleh2#Option2": [
		],
		"titleh2#Option3": [
		],
		"titleh3": [
		],
		"titleh4": [
		],
		"titleh4#Option1": [
		],
		"titleh4#Option2": [
		],
		"titleh5": [
		],
		"titleh5#Option1": [
			
		],
		"titleh5#Option2": [
		],
		"titleh5#Option3": [
		],
		"titleh5#Option4": [
		],
		"titleh5#Option5": [
		],
		"titleh5#Option6": [
		],
		"titleh5#Option7": [
		],
		"titleh5#Option8": [
		],
		"titleh5#Option9": [
		],
		"titleh5#Option10": [
		],
		"titleh6": [
		],
		"titleh6#Option1": [
		],
		"titleh6#Option2": [
		],
		"titleh6#Option3": [
		],
		"titleh6#Option4": [
		],
		"titleh6#Option5": [
		],
		"titleh6#Option6": [
		],
		"titleh6#Option7": [
		],
		"titleh6#Option8": [
		],
		"image.caption": [
		],
		"picturecredit": [
		],
		"body": [
		],
		"body#Option1": [
		],
		"body#Option2": [
		],
		"body#Option3": [
		],
		"body#Option4": [
		],
		"body#Option5": [
		],
		"body#Option6": [
		],
		"body#Option7": [
		],
		"body#Option8": [
		],
		"body#Option9": [
		],
		"body#Option10": [
		],
		"body#Option11": [
		],
		"body#Option12": [
		],
		"body#Option13": [
		],
		"body#Option14": [
		],
		"body#Option15": [
		],
		"body#Option16": [
		],
		"body#Option17": [
		],
		"body#Option18": [
		],
		"body#Option19": [
		],
		"body#Option20": [
		],
		"body#Option21": [
		],
		"body#Option22": [
		],
		"body#Option23": [
		],
		"body#Option24": [
		],
		"body#Option25": [
		],
		"body#Option26": [
		],
		"body#Option27": [
		],
		"body#Option28": [
		],
		"footer": [
		],
		"footer#Option1": [
		],
		"crosshead": [
		],
		"crosshead#Option1": [
		],
		"crosshead#Option2": [
		],
		"crosshead#Option3": [
		],
		"unmaptext": [
		],
		"list-item": [
		],
		"list-item#Option13": [
		],
		"list-item#Option16": [
		],
		"list-item#Option26": [
		],
		"titlewih1": [
		],
		"titlewih2": [
		],
		"titlewih3": [
		],
		"titlewih4": [
		],
		"titlewih5": [
		],
		"titlewih6": [
		],
		"titlewithimage": [
		],
		"titlewithimage#Option1": [
		]
	},

	//optional, title settings
	appendTitle: {
		"titleh1": [
		],
		"titleh2": [
		],
		"titleh3": [
		],
		"titleh4": [
		],
		"titleh5": [
		],
		"titleh6": [
		]
	},

	//Optional digital component style definitions 
	digitalComponentStyles: {
		"Option1": {
			"styles": {
				"style": "_option1"
			}
		},
		"Option2": {
			"styles": {
				"style": "_option2"
			}
		},
		"Option3": {
			"styles": {
				"style": "_option3"
			}
		},
		"Option4": {
			"styles": {
				"style": "_option4"
			}
		},
		"Option5": {
			"styles": {
				"style": "_option5"
			}
		},
		"Option6": {
			"styles": {
				"style": "_option6"
			}
		},
		"Option7": {
			"styles": {
				"style": "_option7"
			}
		},
		"Option8": {
			"styles": {
				"style": "_option8"
			}
		},
		"Option9": {
			"styles": {
				"style": "_option9"
			}
		},
		"Option10": {
			"styles": {
				"style": "_option10"
			}
		},
		"Option11": {
			"styles": {
				"style": "_option11"
			}
		},
		"Option12": {
			"styles": {
				"style": "_option12"
			}
		},
		"Option13": {
			"styles": {
				"style": "_option13"
			}
		},
		"Option14": {
			"styles": {
				"style": "_option14"
			}
		},
		"Option15": {
			"styles": {
				"style": "_option15"
			}
		},
		"Option16": {
			"styles": {
				"style": "_option16"
			}
		},
		"Option17": {
			"styles": {
				"style": "_option17"
			}
		},
		"Option18": {
			"styles": {
				"style": "_option18"
			}
		},
		"Option19": {
			"styles": {
				"style": "_option19"
			}
		},
		"Option20": {
			"styles": {
				"style": "_option20"
			}
		},
		"Option21": {
			"styles": {
				"style": "_option21"
			}
		},
		"Option22": {
			"styles": {
				"style": "_option22"
			}
		},
		"Option23": {
			"styles": {
				"style": "_option23"
			}
		},
		"Option24": {
			"styles": {
				"style": "_option24"
			}
		},
		"Option25": {
			"styles": {
				"style": "_option25"
			}
		},
		"Option26": {
			"styles": {
				"style": "_option26"
			}
		},
		"Option27": {
			"styles": {
				"style": "_option27"
			}
		},
		"Option28": {
			"styles": {
				"style": "_option28"
			}
		},
		"Option29": {
			"styles": {
				"style": "_option29"
			}
		},
		"Option30": {
			"styles": {
				"style": "_option30"
			}
		},
		"Option31": {
			"styles": {
				"style": "_option31"
			}
		},
		"Option32": {
			"styles": {
				"style": "_option32"
			}
		},
		"Option33": {
			"styles": {
				"style": "_option33"
			}
		},
		"Option34": {
			"styles": {
				"style": "_option34"
			}
		},
		"Option35": {
			"styles": {
				"style": "_option35"
			}
		},
		"Option36": {
			"styles": {
				"style": "_option36"
			}
		},
		"Option37": {
			"styles": {
				"style": "_option37"
			}
		},
		"Option38": {
			"styles": {
				"style": "_option38"
			}
		},
		"Option39": {
			"styles": {
				"style": "_option39"
			}
		},
		"Option40": {
			"styles": {
				"style": "_option40"
			}
		},
		"Option41": {
			"styles": {
				"style": "_option41"
			}
		},
		"Option42": {
			"styles": {
				"style": "_option42"
			}
		},
		"Option43": {
			"styles": {
				"style": "_option43"
			}
		},
		"Option44": {
			"styles": {
				"style": "_option44"
			}
		},
		"Option45": {
			"styles": {
				"style": "_option45"
			}
		},
		"Option46": {
			"styles": {
				"style": "_option46"
			}
		},
		"Option47": {
			"styles": {
				"style": "_option47"
			}
		},
		"Option48": {
			"styles": {
				"style": "_option48"
			}
		},
		"Option49": {
			"styles": {
				"style": "_option49"
			}
		},
		"Option50": {
			"styles": {
				"style": "_option50"
			}
		}
	},

	imageComponent: {
		//Base json of the image component
		definition: {
			"content": {
				"image": {
					"id": "",
					"focuspoint": {
						"x": 0.5,
						"y": 0.5
					},
					"cropper": false
				},
				"caption": [],
				"picture credit": []
			},
			"id": "",
			"identifier": "image",
			"styles": {
				"fitting": "_fit-frame-height-to-content"
			}
		},

		//List of the text filters of the image component as configured in textFilterList
		textFilters: [
			"image.caption"
		]
	},
	
	ptdimageComponent: {
		definition: {
			"content": {
				"ptdimage": {
					"id": "",
					"focuspoint": {
						"x": 0.5,
						"y": 0.5
					},
					"cropper": false
				},
				"caption": [],
				"picture credit": []
			},
			"id": "",
			"identifier": "ptdimage",
			"styles": {
				"ptdimage-fitting": "_fitting",
				"ptdimage-style": ""
			},
			"inlineStyles": {
				"width": ""
			}
		},
		//List of the text filters of the image component as configured in textFilterList
		textFilters: [
			"image.caption"
		]
	},

	mathComponent: {
		definition: {
			"content": {
				"mathml": {
					"options": {
						"mathML": ""
					}
				}
			},
			"id": "",
			"data": {
				"mathml-html-data": ""
			},
			"identifier": "mathml",
			"styles": {}
		}
	},

	//Icon and Image Header definitions
	header: {
		"00-fixos-peso1": { //Paragraph style name
			definition: {
				"content": {
					"titlewih3": [		//title with icon example
					],
					"imageicon": {
						"id": "",
						"focuspoint": {
							"x": 0.5,
							"y": 0.5
						},
						"cropper": false
					}
				},
				"id": "",
				"identifier": "titlewithiconh3",
				"styles": {},
				"inlineStyles": {
				}
			}
		},
		"00-fixos-peso2": { //Paragraph style name
			definition: {
				"content": {
					"titlewih3": [		//title with icon example
					],
					"imageicon": {
						"id": "",
						"focuspoint": {
							"x": 0.5,
							"y": 0.5
						},
						"cropper": false
					}
				},
				"id": "",
				"identifier": "titlewithiconh3",
				"styles": {},
				"inlineStyles": {
				}
			}
		},
		"04-capitulo": { //Paragraph style name
			definition: {
				"content": {
					"imageicon": {
						"id": "",
						"focuspoint": {
							"x": 0.5,
							"y": 0.5
						},
						"cropper": false
					}
				},
				"id": "doc-1g5k3djco0",
				"identifier": "titlewithimage",
				"styles": {},
				"containers": {
					"main": []
				},
				"inlineStyles": {
				}
			},
			contentType: "titleh1"
		},
		"04-capitulo-numero": { //Paragraph style name
			definition: {
				"content": {
					"imageicon": {
						"id": "",
						"focuspoint": {
							"x": 0.5,
							"y": 0.5
						},
						"cropper": false
					}
				},
				"id": "doc-1g5k3djco0",
				"identifier": "titlewithimage",
				"styles": {},
				"containers": {
					"main": []
				},
				"inlineStyles": {
				}
			},
			contentType: "titleh1"
		},
		"04-capitulo-titulo": { //Paragraph style name
			definition: {
				"content": {
					"imageicon": {
						"id": "",
						"focuspoint": {
							"x": 0.5,
							"y": 0.5
						},
						"cropper": false
					}
				},
				"id": "doc-1g5k3djco0",
				"identifier": "titlewithimage",
				"styles": {},
				"containers": {
					"main": []
				},
				"inlineStyles": {
				}
			},
			contentType: "titleh1"
		}
	},

	//Place components in a container based on their paragraph style
	containers: {
		"05-geral-texto-bullet": { //Paragraph style
			definition: { // Container definition 
				"content": {},
				"id": "",
				"identifier": "bulleted-list", //bulleted-list, lowerletters-list, upperletters-list, upperroman-list, numbered-list
				"styles": {},
				"containers": {
					"main": []
				}
			},
			containerName: "main", //Container field in the container definition
		},
		"06-box-Observacao-bullet-seta": { //Paragraph style
			definition: { // Container definition 
				"content": {},
				"id": "",
				"identifier": "bulleted-list", //bulleted-list, lowerletters-list, upperletters-list, upperroman-list, numbered-list
				"styles": {},
				"containers": {
					"main": []
				}
			},
			containerName: "main", //Container field in the container definition
		},
		"10-secao-Diversificando-texto-bullet": { //Paragraph style
			definition: { // Container definition 
				"content": {},
				"id": "",
				"identifier": "bulleted-list",
				"styles": {},
				"containers": {
					"main": []
				}
			},
			containerName: "main", //Container field in the container definition
		},
		"10-secao-Trabalhando-texto-bullet": { //Paragraph style
			definition: { // Container definition 
				"content": {},
				"id": "",
				"identifier": "bulleted-list",
				"styles": {},
				"containers": {
					"main": []
				}
			},
			containerName: "main", //Container field in the container definition
		},
		"05-geral-bullets_MP": { //Paragraph style
			definition: { // Container definition 
				"content": {},
				"id": "",
				"identifier": "bulleted-list",
				"styles": {},
				"containers": {
					"main": []
				}
			},
			containerName: "main", //Container field in the container definition
		},
		"06-box-Observacao-alternativas": { //Paragraph style
			definition: { // Container definition 
				"content": {},
				"id": "",
				"identifier": "lowerletters-list",
				"styles": {},
				"containers": {
					"main": []
				}
			},
			containerName: "main", //Container field in the container definition
		},
		"10-secao-ParaSaber-item": { //Paragraph style
			definition: { // Container definition 
				"content": {},
				"id": "",
				"identifier": "lowerletters-list",
				"styles": {},
				"containers": {
					"main": []
				}
			},
			containerName: "main", //Container field in the container definition
		},
		"05-geral-3os-texto-bullet_G_MP": { //Paragraph style
			definition: { // Container definition 
				"content": {},
				"id": "",
				"identifier": "bulleted-list",
				"styles": {},
				"containers": {
					"main": []
				}
			},
			containerName: "main", //Container field in the container definition
		},
		"05-geral-texto-bullet 1": { //Paragraph style
			definition: { // Container definition 
				"content": {},
				"id": "",
				"identifier": "bulleted-list",
				"styles": {},
				"containers": {
					"main": []
				}
			},
			containerName: "main", //Container field in the container definition
		},
		"05-geral-texto-bullet 2": { //Paragraph style
			definition: { // Container definition 
				"content": {},
				"id": "",
				"identifier": "bulleted-list",
				"styles": {},
				"containers": {
					"main": []
				}
			},
			containerName: "main", //Container field in the container definition
		},
		"05-geral-texto-bullet_G_MP": { //Paragraph style
			definition: { // Container definition 
				"content": {},
				"id": "",
				"identifier": "bulleted-list",
				"styles": {},
				"containers": {
					"main": []
				}
			},
			containerName: "main", //Container field in the container definition
		},
		"10-secao-Aval-atividade-a)": { //Paragraph style
			definition: { // Container definition 
				"content": {},
				"id": "",
				"identifier": "lowerletters-list",
				"styles": {},
				"containers": {
					"main": []
				}
			},
			containerName: "main", //Container field in the container definition
		},
		"06-box-atividae-texto-a)": { //Paragraph style
			definition: { // Container definition 
				"content": {},
				"id": "",
				"identifier": "lowerletters-list",
				"styles": {},
				"containers": {
					"main": []
				}
			},
			containerName: "main", //Container field in the container definition
		},
		"09-atividade-1_a)": { //Paragraph style
			definition: { // Container definition 
				"content": {},
				"id": "",
				"identifier": "lowerletters-list",
				"styles": {},
				"containers": {
					"main": []
				}
			},
			containerName: "main", //Container field in the container definition
		},
		"10-secao-Aval-atividade-1_a)": { //Paragraph style
			definition: { // Container definition 
				"content": {},
				"id": "",
				"identifier": "lowerletters-list",
				"styles": {},
				"containers": {
					"main": []
				}
			},
			containerName: "main", //Container field in the container definition
		},
		"10-secao-Diversificando-atividade-1_a)": { //Paragraph style
			definition: { // Container definition 
				"content": {},
				"id": "",
				"identifier": "lowerletters-list",
				"styles": {},
				"containers": {
					"main": []
				}
			},
			containerName: "main", //Container field in the container definition
		},
		"10-secao-Trabalhando-atividade-1_a)": { //Paragraph style
			definition: { // Container definition 
				"content": {},
				"id": "",
				"identifier": "lowerletters-list",
				"styles": {},
				"containers": {
					"main": []
				}
			},
			containerName: "main", //Container field in the container definition
		},
		"09-atividade-1_a_G_MP": { //Paragraph style
			definition: { // Container definition 
				"content": {},
				"id": "",
				"identifier": "lowerletters-list",
				"styles": {},
				"containers": {
					"main": []
				}
			},
			containerName: "main", //Container field in the container definition
		},
		"05-geral-bullets": { //Paragraph style
			definition: { // Container definition 
				"content": {},
				"id": "",
				"identifier": "bulleted-list",
				"styles": {},
				"containers": {
					"main": []
				}
			},
			containerName: "main", //Container field in the container definition
		},
		"05-geral-texto-1": { //Paragraph style
			definition: { // Container definition 
				"content": {},
				"id": "",
				"identifier": "lowerletters-list",
				"styles": {},
				"containers": {
					"main": []
				}
			},
			containerName: "main", //Container field in the container definition
		},
		"05-geral-texto-1_MP": { //Paragraph style
			definition: { // Container definition 
				"content": {},
				"id": "",
				"identifier": "lowerletters-list",
				"styles": {},
				"containers": {
					"main": []
				}
			},
			containerName: "main", //Container field in the container definition
		},
		"10-secao-Diversificando-exercicio-bullet": { //Paragraph style
			definition: { // Container definition 
				"content": {},
				"id": "",
				"identifier": "bulleted-list",
				"styles": {},
				"containers": {
					"main": []
				}
			},
			containerName: "main", //Container field in the container definition
		},
		"09-atividade-1_a)_G_MP": { //Paragraph style
			definition: { // Container definition 
				"content": {},
				"id": "",
				"identifier": "lowerletters-list",
				"styles": {},
				"containers": {
					"main": []
				}
			},
			containerName: "main", //Container field in the container definition
		},
		"09-atividade-bullet_G_MP": { //Paragraph style
			definition: { // Container definition 
				"content": {},
				"id": "",
				"identifier": "bulleted-list",
				"styles": {},
				"containers": {
					"main": []
				}
			},
			containerName: "main", //Container field in the container definition
		},
		"09-atividade-bullet_a)_G_MP": { //Paragraph style
			definition: { // Container definition 
				"content": {},
				"id": "",
				"identifier": "bulleted-list",
				"styles": {},
				"containers": {
					"main": []
				}
			},
			containerName: "main", //Container field in the container definition
		},
		"09-atividade-bullet_cont_G_MP": { //Paragraph style
			definition: { // Container definition 
				"content": {},
				"id": "",
				"identifier": "bulleted-list",
				"styles": {},
				"containers": {
					"main": []
				}
			},
			containerName: "main", //Container field in the container definition
		},
		"06-box-atividade-texto-a)": { //Paragraph style
			definition: { // Container definition 
				"content": {},
				"id": "",
				"identifier": "lowerletters-list",
				"styles": {},
				"containers": {
					"main": []
				}
			},
			containerName: "main", //Container field in the container definition
		},
		"09-atividade-1_romanos": { //Paragraph style
			definition: { // Container definition 
				"content": {},
				"id": "",
				"identifier": "numbered-list",
				"styles": {},
				"containers": {
					"main": []
				}
			},
			containerName: "main", //Container field in the container definition
		}
	},

	// The 'styles' section provides the export details about what styling should result in bold and italic
	// overrides in the output.
	styles: {
		// Mark character styles as bold or italic. Matching is on full character style name. Most commonly used.
		character: {
			"Bold": { bold: true },
			"Bold Italic": { bold: true, italic: true },
			"Italic": { italic: true },
			"Subscript": { subscript: true },
			"Superscript": { superscript: true },
			"Underline": { underline: true },
			"Strikethrough": { strikethrough: true },
			"Uppercase": { uppercase: true },
			"Lowercase": { lowercase: true },
			"Titlecase": { titlecase: true },
			"00-fixo-resposta-bold": { characterstyle: "cs-00-fixo-resposta-bold" },
			"00-fixo-resposta-italic": { characterstyle: "cs-00-fixo-resposta-italic" },
			"00-mathematical-pi-1": { characterstyle: "cs-00-mathematical-pi-1" },
			"00-mathematical-pi-4": { characterstyle: "cs-00-mathematical-pi-4" },
			"00-mathematical-pi-6": { characterstyle: "cs-00-mathematical-pi-6" },
			"00-myriad-bold": { characterstyle: "cs-00-myriad-bold" },
			"00-myriad-italic": { characterstyle: "cs-00-myriad-italic" },
			"00-sobrescrito-sublinhado": { characterstyle: "cs-00-sobrescrito-sublinhado" },
			"00-symbol":{characterstyle:"cs-00-symbol"},
            "00-texto-bco":{characterstyle:"cs-00-texto-bco"},
            "05-cota-bold-bco":{characterstyle:"cs-05-cota-bold-bco"},
            "05-geral-3os-bold":{characterstyle:"cs-05-geral-3os-bold"},
            "05-geral-3os-italic":{characterstyle:"cs-05-geral-3os-italic"},
            "05-geral-glossario-destaque":{characterstyle:"cs-05-geral-glossario-destaque"},
            "05-geral-glossario-destaque-3os":{characterstyle:"cs-05-geral-glossario-destaque-3os"},
            "05-geral-glossario-peso":{characterstyle:"cs-05-geral-glossario-peso"},
            "05-geral-texto-bold":{characterstyle:"cs-05-geral-texto-bold"},
            "05-geral-texto-bold-italic":{characterstyle:"cs-05-geral-texto-bold-italic"},
            "05-geral-texto-italic":{characterstyle:"cs-05-geral-texto-italic"},
            "06-box-Observacao-seta":{characterstyle:"cs-06-box-Observacao-seta"},
            "09-atividade-alternativa":{characterstyle:"cs-09-atividade-alternativa"},
            "09-atividade-bold":{characterstyle:"cs-09-atividade-bold"},
            "09-atividade-bold-italico":{characterstyle:"cs-09-atividade-bold-italico"},
            "09-atividade-Complementar-comando-numero":{characterstyle:"cs-09-atividade-Complementar-comando-numero"},
            "09-atividade-italic":{characterstyle:"cs-09-atividade-italic"},
            "09-atividade-Para-Saber-comando-numero":{characterstyle:"cs-09-atividade-Para-Saber-comando-numero"},
            "09-atividade-Proposto-comando-numero":{characterstyle:"cs-09-atividade-Proposto-comando-numero"},
            "10-secao-comando-numero":{characterstyle:"cs-10-secao-comando-numero"},
            "10-secao-Diversificando-comando-numero":{characterstyle:"cs-10-secao-Diversificando-comando-numero"},
            "10-secao-Trabalhando-comando-numero":{characterstyle:"cs-10-secao-Trabalhando-comando-numero"},
            "05-geral-bullet_MP":{characterstyle:"cs-05-geral-bullet_MP"},
            "bold-italic_MP":{characterstyle:"cs-bold-italic_MP"},
            "bold_MP":{characterstyle:"cs-bold_MP"},
            "italic_MP":{characterstyle:"cs-italic_MP"},
            "05-3os-bold_MP":{characterstyle:"cs-05-3os-bold_MP"},
            "05-3os-italic_MP":{characterstyle:"cs-05-3os-italic_MP"},
            "05-geral-peso2-bullet_MP":{characterstyle:"cs-05-geral-peso2-bullet_MP"},
            "05-peso3-1pg_MP":{characterstyle:"cs-05-peso3-1pg_MP"},
            "medium_MP":{characterstyle:"cs-medium_MP"},
            "ordinal_MP":{characterstyle:"cs-ordinal_MP"},
            "sobrescrito_MP":{characterstyle:"cs-sobrescrito_MP"},
            "symbol_MP":{characterstyle:"cs-symbol_MP"},
			"txt_C100":{characterstyle:"cs-txt_C100"},
			"00-sobrescrito":{characterstyle:"cs-00-sobrescrito"},
			"00-subscrito":{characterstyle:"cs-00-subscrito"},
			"00-fixo-resposta-bold-italic":{characterstyle:"cs-00-fixo-resposta-bold-italic"},
			"00-roboto-bold-italic":{characterstyle:"cs-00-roboto-bold-italic"},
			"05-geral-3os-bold-italic":{characterstyle:"cs-05-geral-3os-bold-italic"},
			"06-box-Pense-Mais-atividade-comando-numero":{characterstyle:"cs-06-box-Pense-Mais-atividade-comando-numero"},
			"00-mathematical-pi-3":{characterstyle:"cs-00-mathematical-pi-3"},
			"00-mathematical-pi-5":{characterstyle:"cs-00-mathematical-pi-5"},
			"00-fixos-balao-italic":{characterstyle:"cs-00-fixos-balao-italic"},
			"00-fixos-balao-bold":{characterstyle:"cs-00-fixos-balao-bold"},
			"00-fixos-balao-bold-italic":{characterstyle:"cs-00-fixos-balao-bold-italic"},
			"00-mathematical-pi-2":{characterstyle:"cs-00-mathematical-pi-2"},
			"00-Beaba Moderna Regular":{characterstyle:"cs-00-Beaba-Moderna-Regular"},
			"CIFRAO_ROBOTO_BOLD":{characterstyle:"cs-CIFRAO_ROBOTO_BOLD"},
			"CIFRAO_ROBOTO":{characterstyle:"cs-CIFRAO_ROBOTO"},
			"CIFRAO Roboto_MP":{characterstyle:"cs-CIFRAO_Roboto_MP"},
			"00-mathematical-pi-1_MP":{characterstyle:"cs-00-mathematical-pi-1_MP"},
			"00-sobrescrito-sublinhado_MP":{characterstyle:"cs-00-sobrescrito-sublinhado_MP"},
			"00-Mathematical Pi 1":{characterstyle:"cs-00-Mathematical-Pi-1"},
			"00-bold":{characterstyle:"cs-00-bold"},
			"00-italic":{characterstyle:"cs-00-italic"},
			"02-sumario-pagina":{characterstyle:"cs-02-sumario-pagina"},
			"02-sumario-pagina-secao":{characterstyle:"cs-02-sumario-pagina-secao"},
			"02-sumario-pontilhado":{characterstyle:"cs-02-sumario-pontilhado"},
			"02-sumario-secao-nome":{characterstyle:"cs-02-sumario-secao-nome"},
			"00-Acessibilidade-Siglas":{characterstyle:"cs-00-Acessibilidade-Siglas"},
			"00-Acessibilidade-Siglas-Bold":{characterstyle:"cs-00-Acessibilidade-Siglas-Bold"},
			"00-Acessibilidade-Siglas-Bold-Italic":{characterstyle:"cs-00-Acessibilidade-Siglas-Bold-Italic"},
			"00-Acessibilidade-Siglas-Italic":{characterstyle:"cs-00-Acessibilidade-Siglas-Italic"},
			"00-Acessibilidade-Fonetica":{characterstyle:"cs-00-Acessibilidade-Fonetica"},
			"00-Acessibilidade-Fonetica-Bold":{characterstyle:"cs-00-Acessibilidade-Fonetica-Bold"},
			"00-Acessibilidade-Fonetica-Bold-Italic":{characterstyle:"cs-00-Acessibilidade-Fonetica-Bold-Italic"},
			"00-Acessibilidade-Fonetica-Italic":{characterstyle:"cs-00-Acessibilidade-Fonetica-Italic"},
			"00-Acessibilidade-Idioma":{characterstyle:"cs-00-Acessibilidade-Idioma"},
			"00-Acessibilidade-Idioma-Bold":{characterstyle:"cs-00-Acessibilidade-Idioma-Bold"},
			"00-Acessibilidade-Idioma-Bold-Italic":{characterstyle:"cs-00-Acessibilidade-Idioma-Bold-Italic"},
			"00-Acessibilidade-Idioma-Italic":{characterstyle:"cs-00-Acessibilidade-Idioma-Italic"},
			"Math_Variable":{characterstyle:"cs-Math_Variable"},
			"00-Emmascript":{characterstyle:"cs-00-Emmascript"},
			"05-geral-texto-bold-C100":{characterstyle:"cs-05-geral-texto-bold-C100"},
			"05-geral-texto-C100":{characterstyle:"cs-05-geral-texto-C100"},
			"05-geral-texto-bold-italico-C100":{characterstyle:"cs-05-geral-texto-bold-italico-C100"},
			"Caflisch Script Pro":{characterstyle:"cs-Caflisch-Script-Pro"},
			"Emmascript MVB Std":{characterstyle:"cs-Emmascript-MVB-Std"},
			"00-bold-italic":{characterstyle:"cs-00-bold-italic"},
			"16-resposta-comando-1":{characterstyle:"cs-16-resposta-comando-1"},
			"16-sigla-destaque":{characterstyle:"cs-16-sigla-destaque"},
			"00-ponto_invisivel_MP":{characterstyle:"cs-00-ponto_invisivel_MP"},
			"00-sobrescrito_MP":{characterstyle:"cs-00-sobrescrito_MP"},
			"05-geral-3os-texto":{characterstyle:"cs-05-geral-3os-texto"},
			"CIFRAO Roboto":{characterstyle:"cs-CIFRAO-Roboto"},
			"bold italic_MP":{characterstyle:"cs-bold_italic_MP"},
			"00-subscrito-italic_MP":{characterstyle:"cs-00-subscrito-italic_MP"},
			"bold":{characterstyle:"cs-bold"},
			"CIFRAO Asap":{characterstyle:"cs-CIFRAO_Asap"},
			"fonte-bold":{characterstyle:"cs-fonte-bold"},
			"00-STIX":{characterstyle:"cs-00-STIX"},
			"STIX general":{characterstyle:"cs-STIX-general"},
			"STIX general bold":{characterstyle:"cs-STIX-general-bold"},
			"STIX general bold C100":{characterstyle:"cs-STIX-general-bold-C100"},
			"STIX general C100":{characterstyle:"cs-STIX-general-C100"},
			"STIX general italic":{characterstyle:"cs-STIX-general-italic"},
			"lacuna bolinha":{characterstyle:"cs-lacuna-bolinha"},
			"Lacuna_quadrada":{characterstyle:"cs-Lacuna_quadrada"},
			"05-geral-bullet-U_MP":{characterstyle:"cs-05-geral-bullet-U_MP"},
			"bold-italic-U_MP":{characterstyle:"cs-bold-italic-U_MP"},
			"bold-U_MP":{characterstyle:"cs-bold-U_MP"},
			"italic-U_MP":{characterstyle:"cs-italic-U_MP"}
		},
	
		// Mark use of certain font styles as bold or italic in the output. Be aware that this will match for all
		// font families used with the specified font style
		font: {
		},
		// Mark entire paragraphs as bold or italic. Not commonly used.
		paragraph: {
		}
	},

	// The 'output' section defines how bold and italic overrides will be output to Ptd. In addition it offers
	// the opportunity to remove and/or replace characters in the output. Html special characters will automatically be
	// escaped in the output.
	output: {
		htmlTags: {
			bold: {
				tag: "b"
			},
			italic: {
				tag: "i"
			},
			superscript: {
				tag: "sup"
			},
			subscript: {
				tag: "sub"
			},
			uppercase: {
				tag: "up"
			}
		},
		htmlEncode: [
		]
	},

	// Using the 'charConvert' section certain characters can be replaced by other characters 
	charConvert: [
		//Thin space to space
		['\u2009', ' ']
	],

	// The directory used as base directory for logging
	exportDirectory: '~/Desktop/ptd-indesign-logs',

	// Logging settings. Log files will be put in the document's output directory.
	logging: {
		level: 'INFO',
		wipe: true
	},

	//Content Station URL relative to index.php, default assumes that Content Station is installed in the same folder as index.php
	contentStationURL: "../app/",

	//If set to true, each set of grouped frames on a layout is added as a Container component.
	//Each frame of the group will be a separate component in the Container.
	//Note: The default Container component is used; custom Container components are not supported.
	createContainerForGroup: true,

	//If set to true, images will be scaled by percentage in conversion, respecting the scaling (percentage) of frame width and print page width
	//Else set image width to 100% in conversion, so that the image is sized by CSS styling or scaled to fit full width of digital article
	scalePTDImages: true
};